package com.opslab.util.image;

import java.util.Random;

public final class ImageCaptcha {
    private static int width =200;
    private static int height= 40;
    public static  String CHAR    = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";

    public static String getCHAR() {
        return CHAR;
    }

    public static void setCHAR(String CHAR) {
        ImageCaptcha.CHAR = CHAR;
    }

    public static int getWidth() {
        return width;
    }

    public static void setWidth(int width) {
        ImageCaptcha.width = width;
    }

    public static int getHeight() {
        return height;
    }

    public static void setHeight(int height) {
        ImageCaptcha.height = height;
    }

    private static String randomStr(int len){
        StringBuffer sb     = new StringBuffer();
        Random random = new Random();
        for (int i = 0; i < len; i++) {
            sb.append(CHAR.charAt(random.nextInt(CHAR.length())));
        }
        return sb.toString();

    }

    public static String pngCaptcha(int strlen,String file){
        String random = randomStr(strlen);
        if(CaptchaUtil.pngCaptcha(random,width,height,file)){
            return random;
        }
        return "";
    }

    public static String gifCaptch(int strlen,String file){
        String random = randomStr(strlen);
        if(CaptchaUtil.gifCaptcha(random,width,height,file)){
            return random;
        }
        return "";
    }
}
