package info.monitorenter.io;

import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;

public class LimitedInputStream extends FilterInputStream {

  protected int m_amountOfBytesReadable;

  public LimitedInputStream(final InputStream in, final int limit) {
    super(in);
    this.m_amountOfBytesReadable = limit;
  }

  @Override
  public int available() throws IOException {
    int result;
    
    if (this.m_amountOfBytesReadable == 0) {
      result = 0; } else {
      result = super.available();
      if (this.m_amountOfBytesReadable < result) {
        result = this.m_amountOfBytesReadable;
      }
    }
    return result;
  }

  @Override
  public int read() throws IOException {

    int result;
    if (this.m_amountOfBytesReadable == 0) {
      result = -1; } else {
      result = super.read();
      if (result >= 0) {
        this.m_amountOfBytesReadable--;
      }
    }
    return result;
  }

  @Override
  public int read(final byte b[], final int off, final int len) throws IOException {

    int result;
    int bytesToRead = len;
    if (this.m_amountOfBytesReadable == 0) {
      result = -1; } else{
      if (this.m_amountOfBytesReadable < len) {
        bytesToRead = this.m_amountOfBytesReadable; }
      result = super.read(b, off, bytesToRead);
      if (result > 0) {
        this.m_amountOfBytesReadable -= result;
      }
    }
    return result;
  }

  @Override
  public long skip(final long howManyBytes) throws IOException {

    long result;
    long bytesToSkip = howManyBytes;
    if (this.m_amountOfBytesReadable == 0) {
      result = 0; } else {
      if (this.m_amountOfBytesReadable < howManyBytes) {
        bytesToSkip = this.m_amountOfBytesReadable;
      }
      result = super.skip(howManyBytes);
      this.m_amountOfBytesReadable -= result;
    }
    return result;
  }

}