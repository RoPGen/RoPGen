package com.seafile.seadroid2.avatar;

import org.json.JSONException;
import org.json.JSONObject;

import com.google.common.base.Objects;

import android.util.Log;

public class Avatar {
    private static final String DEBUG_TAG = "Avatar";
    
    private String signature; private String url;
    private long mtime;
    static Avatar fromJson(JSONObject obj) {
        Avatar avatar = new Avatar();
        try {
            avatar.url = obj.getString("url");
            avatar.mtime = obj.getLong("mtime");
            return avatar;
        } catch (JSONException e) {
            Log.d(DEBUG_TAG, e.getMessage());
            return null;
        }
    }
    
    @Override
    public int hashCode() {
        return Objects.hashCode(url, mtime);
    }
    
    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public long getMtime() {
        return mtime;
    }

    public void setMtime(long mtime) {
        this.mtime = mtime;
    }

    public String getSignature() {
        return signature;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }
    
    @Override
    public String toString() {
        return Objects.toStringHelper(this)
                .add("signature", signature)
                .add("url", url)
                .add("mtime", mtime)
                .toString();
    }
}
