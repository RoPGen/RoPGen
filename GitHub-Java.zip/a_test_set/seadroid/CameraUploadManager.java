package com.seafile.seadroid2.cameraupload;

import java.util.List;

import com.seafile.seadroid2.ConcurrentAsyncTask;
import com.seafile.seadroid2.SeafException;
import com.seafile.seadroid2.account.Account;
import com.seafile.seadroid2.data.DataManager;
import com.seafile.seadroid2.data.SeafCachedPhoto;
import com.seafile.seadroid2.data.SeafDirent;
import com.seafile.seadroid2.data.SeafRepo;
import com.seafile.seadroid2.util.Utils;

public class CameraUploadManager {
    private CameraUploadDBHelper dbHelper;
    private DataManager mDataManager;
    private Account account;

    public CameraUploadManager(Account act) {
        account = act;
        dbHelper = CameraUploadDBHelper.getCameraUploadDBHelper();
        mDataManager = new DataManager(act);
    }

    public SeafCachedPhoto getCachedPhoto(String repoName, String repoID,
            String path) {
        SeafCachedPhoto cp = dbHelper.getPhotoCacheItem(repoID, path);
        return cp;
    }

    public SeafCachedPhoto getCachedPhoto(String repoName, String repoID,
            String dir, String path) {
        String validPath = Utils.pathJoin(dir, path);
        return getCachedPhoto(repoName, repoID, validPath);
    }

    public void addCachedPhoto(String repoName, String repoID, String path) {
        SeafCachedPhoto item = new SeafCachedPhoto();
        item.repoName = repoName;
        item.repoID = repoID;
        item.path = path;
        item.accountSignature = account.getSignature();
        dbHelper.savePhotoCacheItem(item);
    }

    public int removeCachedPhoto(SeafCachedPhoto cp) {
        return dbHelper.removePhotoCacheItem(cp);
    }

    public void onPhotoUploadSuccess(final String repoName, final String repoID, final String path) {
        ConcurrentAsyncTask.execute(new Runnable() {
            @Override
            public void run() {
                addCachedPhoto(repoName, repoID, path);
            }
        });
    }

    public Boolean isRemoteCameraUploadRepoValid(String repoID, String parentDir) throws SeafException {
        List<SeafRepo> list = mDataManager.getReposFromServer();
        if (list != null) {
            for (SeafRepo seafRepo : list) {
                if (seafRepo.id.equals(repoID)) {
                    return true;
                }
            }
        }

        return  false;
    }

    public void validateRemoteCameraUploadsDir(String repoID, String parentDir, String dirName) throws SeafException {
        List<SeafDirent> list = mDataManager.getDirentsFromServer(repoID, parentDir);

        for (SeafDirent seafDirent : list) {
            if (seafDirent.name.equals(CameraUploadService.CAMERA_UPLOAD_REMOTE_DIR)) {
                return;
            }
        }

       mDataManager.createNewDir(repoID, parentDir, dirName);
    }
}
