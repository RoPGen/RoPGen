package org.chacha.client.command.auth;

import java.io.IOException;

import org.chacha.client.command.JsonConvert;
import org.chacha.client.command.Request;
import org.chacha.util.JsonPojoMapper;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;

public class TokenLogout extends Request implements JsonConvert{
    private static final String CMDTOKEN="logout";
    private TokenBody body;
    
    
    public TokenLogout() {
        super.setOpt(CMDTOKEN);
    }

    public TokenLogout(TokenBody body) {
        super.setOpt(CMDTOKEN);
        this.body = body;
    }

    public TokenBody getBody() {
        return body;
    }

    public void setBody(TokenBody body) {
        this.body = body;
    }

    @Override
    public String toJson() throws JsonMappingException,
            JsonGenerationException, IOException {
        return JsonPojoMapper.toJson(this,true);
    }

    @Override
    public void fromJson(String json) throws JsonMappingException,
            JsonGenerationException, IOException {
        TokenLogout tl=(TokenLogout)JsonPojoMapper.fromJson(json, TokenLogout.class);
        this.setOpt(tl.getOpt());
        this.setBody(tl.getBody());
        
    }
    public static void main(String[] args){
        TokenLogout login=new TokenLogout();
        TokenBody body=new TokenBody("f706c0e77064d8c127ea45397d72778942685880218da7e8e005137104b65df8");
        login.setBody(body);
        String json="";
        try{
            json=login.toJson();
            System.out.println(json);
        }catch(Exception e){
            e.printStackTrace();
        }
        TokenLogout r=new TokenLogout();
        try {
            r.fromJson(json);
            System.out.println(r.getBody().getTicket());
        } catch (JsonMappingException e) {
            e.printStackTrace();
        } catch (JsonGenerationException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
