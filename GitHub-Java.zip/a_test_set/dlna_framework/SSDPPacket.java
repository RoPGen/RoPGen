package org.cybergarage.upnp.ssdp;

import java.net.*;

import org.cybergarage.http.*;

import org.cybergarage.upnp.device.*;

public class SSDPPacket 
{
    public SSDPPacket(byte[] buf, int length)
    {
        dgmPacket = new DatagramPacket(buf, length);
    }

    private DatagramPacket dgmPacket = null;

    public DatagramPacket getDatagramPacket()
    {
        return dgmPacket;
    }

    private String localAddr = "";
    
    public void setLocalAddress(String addr)
    {
        localAddr = addr;
    }
    
    public String getLocalAddress()
    {
        return localAddr;
    }

    
    private long timeStamp;
    
    public void setTimeStamp(long value)
    {
        timeStamp = value;
    }
        
    public long getTimeStamp()
    {
        return timeStamp;
    }

    public InetAddress getRemoteInetAddress()
    {
        return getDatagramPacket().getAddress();
    }
    
    public String getRemoteAddress()
    {
        return getDatagramPacket().getAddress().getHostAddress();
    }

    public int getRemotePort()
    {
        return getDatagramPacket().getPort();
    }
    
    public byte[] packetBytes = null;
    
    public byte[] getData()
    {
        if (packetBytes != null)
            return packetBytes;
        
        DatagramPacket packet = getDatagramPacket();
        int packetLen = packet.getLength();
        String packetData = new String(packet.getData(), 0, packetLen);
        packetBytes = packetData.getBytes();
        
        return packetBytes;
    }

    public String getHost()
    {
        return HTTPHeader.getValue(getData(), HTTP.HOST);
    }

    public String getCacheControl()
    {
        return HTTPHeader.getValue(getData(), HTTP.CACHE_CONTROL);
    }
    
    public String getLocation()
    {
        return HTTPHeader.getValue(getData(), HTTP.LOCATION);
    }

    public String getMAN()
    {
        return HTTPHeader.getValue(getData(), HTTP.MAN);
    }

    public String getST()
    {
        return HTTPHeader.getValue(getData(), HTTP.ST);
    }

    public String getNT()
    {
        return HTTPHeader.getValue(getData(), HTTP.NT);
    }

    public String getNTS()
    {
        return HTTPHeader.getValue(getData(), HTTP.NTS);
    }

    public String getServer()
    {
        return HTTPHeader.getValue(getData(), HTTP.SERVER);
    }

    public String getUSN()
    {
        return HTTPHeader.getValue(getData(), HTTP.USN);
    }

    public int getMX()
    {
        return HTTPHeader.getIntegerValue(getData(), HTTP.MX);
    }

    public InetAddress getHostInetAddress()
    {
        String addrStr = "127.0.0.1";
        String host = getHost();
        int canmaIdx = host.lastIndexOf(":");
        if (0 <= canmaIdx) {
            addrStr = host.substring(0, canmaIdx);
            if (addrStr.charAt(0) == '[')
                addrStr = addrStr.substring(1, addrStr.length());
            if (addrStr.charAt(addrStr.length()-1) == ']')
                addrStr = addrStr.substring(0, addrStr.length()-1);
        }
        InetSocketAddress isockaddr = new InetSocketAddress(addrStr, 0);
        return isockaddr.getAddress();
    }
    
    public boolean isRootDevice()
    {
        if (NT.isRootDevice(getNT()) == true)
            return true;
        if (ST.isRootDevice(getST()) == true)
            return true;
        return USN.isRootDevice(getUSN());
    }

    public boolean isDiscover()
    {
        return MAN.isDiscover(getMAN());
    }
    
    public boolean isAlive()
    {
        return NTS.isAlive(getNTS());
    }

    public boolean isByeBye()
    {
        return NTS.isByeBye(getNTS());
    }

    public int getLeaseTime()
    {
        return SSDP.getLeaseTime(getCacheControl());
    }

    public String toString()
    {
        return new String(getData());
    }
}

