package com.lz.center;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.ServletContext;
import java.util.HashMap;
import java.util.Map;
public class ContextParamHolder
{
    private static final Logger              log                      = LoggerFactory.getLogger(ContextParamHolder.class);
    public static final String              WEB_SOCKET_PORT_KEY      = "web_socket_port";
private static final Map<String, String> contextParamMap          = new HashMap<>();
    public static void init(ServletContext servletContext)
    {
        contextParamMap.put(WEB_SOCKET_PORT_KEY, servletContext.getInitParameter(WEB_SOCKET_PORT_KEY));
for (Map.Entry<String, String> each : contextParamMap.entrySet())
        {
            log.info("添加ContentParam key={} limit={}", each.getKey(), each.getValue());
        }
    }
    public static Integer getInt(String key)
    {
        String value = getString(key);
        if (null == value)
        {
            return null;
        }
        else
        {
            return Integer.valueOf(getString(key));
        }
    }
    public static String getString(String key)
    {
        return contextParamMap.get(key);
    }
}
