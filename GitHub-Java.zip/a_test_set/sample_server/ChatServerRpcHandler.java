package com.lz.game.rpc;
import com.lz.game.rpc.core.RpcPacketHandler;
public abstract class ChatServerRpcHandler extends RpcPacketHandler
{
    
    
    public abstract void AuthReq(ChatServerRpc.AuthReq req);
    
    
    
    public abstract ChatServerRpc.AddSysNoticeResp AddSysNoticeReq(ChatServerRpc.AddSysNoticeReq req);
    
    
    
    public abstract void ChatReq(ChatServerRpc.ChatReq req);
    
    
    
    public abstract void SynReq(ChatServerRpc.SynReq req);
    
    
    
    public abstract ChatServerRpc.DeleteSysNoticeResp DeleteSysNoticeReq(ChatServerRpc.DeleteSysNoticeReq req);
    
    
    
    public abstract void AddGameSysNoticeReq(ChatServerRpc.AddGameSysNoticeReq req);
    
    
    
    public abstract ChatServerRpc.GetOnlineInfoResp GetOnlineInfoReq(ChatServerRpc.GetOnlineInfoReq req);
    
    
    
    public abstract ChatServerRpc.GetOverviewResp GetOverviewReq(ChatServerRpc.GetOverviewReq req);
    
    
    
    public abstract ChatServerRpc.AddBulletinResp AddBulletinReq(ChatServerRpc.AddBulletinReq req);
    
    
    
    public abstract ChatServerRpc.DeleteBulletinResp DeleteBulletinReq(ChatServerRpc.DeleteBulletinReq req);
    
    
    
    public abstract void CreatePlayerReq(ChatServerRpc.CreatePlayerReq req);
    
    
    
    public abstract ChatServerRpc.GetRegisterInfoResp GetRegisterInfoReq(ChatServerRpc.GetRegisterInfoReq req);
    
    
    
    public abstract ChatServerRpc.GetActiveUserResp GetActiveUserReq(ChatServerRpc.GetActiveUserReq req);
    
    
    
    public abstract ChatServerRpc.UpdateSysNoticeResp UpdateSysNoticeReq(ChatServerRpc.UpdateSysNoticeReq req);
    
    
    
    public abstract ChatServerRpc.UpdateBulletinResp UpdateBulletinReq(ChatServerRpc.UpdateBulletinReq req);
    
    
}