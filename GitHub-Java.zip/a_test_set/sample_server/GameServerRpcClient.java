package com.lz.game.rpc;
import com.lz.game.rpc.core.BaseRpcClient;
import com.lz.game.rpc.core.BaseRpcConnection;
import com.lz.game.rpc.core.Rpc;
import com.lz.game.rpc.core.RpcException;
public class GameServerRpcClient extends BaseRpcClient
{
    public GameServerRpcClient(String host, int port)
    {
        super(host, port);
    }
    
    
    public final GameServerRpc.GetAllCdKeyResp getAllCdKey(GameServerRpc.GetAllCdKeyReq req)
    {
        BaseRpcConnection rpcClient = null;
        try
        {
            rpcClient = rpcClientPool.borrowRpcClient();
            Rpc.RpcPacket resp = rpcClient.sendWaitBack(newRpcPacket(req));
            GameServerRpc.GetAllCdKeyResp ret = GameServerRpc.GetAllCdKeyResp.parseFrom(resp.getContent());
            rpcClientPool.returnRpcClient(rpcClient);
            return ret;
        } catch (Exception e)
        {
            rpcClientPool.returnBrokenRpcClient(rpcClient);
            throw new RpcException(e);
        }
    }
    
    
    
    public final GameServerRpc.ContainCdKeyResp containCdKey(GameServerRpc.ContainCdKeyReq req)
    {
        BaseRpcConnection rpcClient = null;
        try
        {
            rpcClient = rpcClientPool.borrowRpcClient();
            Rpc.RpcPacket resp = rpcClient.sendWaitBack(newRpcPacket(req));
            GameServerRpc.ContainCdKeyResp ret = GameServerRpc.ContainCdKeyResp.parseFrom(resp.getContent());
            rpcClientPool.returnRpcClient(rpcClient);
            return ret;
        } catch (Exception e)
        {
            rpcClientPool.returnBrokenRpcClient(rpcClient);
            throw new RpcException(e);
        }
    }
    
    
    
    public final GameServerRpc.AddCdKeyResp addCdKey(GameServerRpc.AddCdKeyReq req)
    {
        BaseRpcConnection rpcClient = null;
        try
        {
            rpcClient = rpcClientPool.borrowRpcClient();
            Rpc.RpcPacket resp = rpcClient.sendWaitBack(newRpcPacket(req));
            GameServerRpc.AddCdKeyResp ret = GameServerRpc.AddCdKeyResp.parseFrom(resp.getContent());
            rpcClientPool.returnRpcClient(rpcClient);
            return ret;
        } catch (Exception e)
        {
            rpcClientPool.returnBrokenRpcClient(rpcClient);
            throw new RpcException(e);
        }
    }
    
    
    
    public final GameServerRpc.GetPlayerJsonDetailResp getPlayerJsonDetail(GameServerRpc.GetPlayerJsonDetailReq req)
    {
        BaseRpcConnection rpcClient = null;
        try
        {
            rpcClient = rpcClientPool.borrowRpcClient();
            Rpc.RpcPacket resp = rpcClient.sendWaitBack(newRpcPacket(req));
            GameServerRpc.GetPlayerJsonDetailResp ret = GameServerRpc.GetPlayerJsonDetailResp.parseFrom(resp.getContent());
            rpcClientPool.returnRpcClient(rpcClient);
            return ret;
        } catch (Exception e)
        {
            rpcClientPool.returnBrokenRpcClient(rpcClient);
            throw new RpcException(e);
        }
    }
    
    
    
    public final GameServerRpc.SearchPlayerResp searchPlayer(GameServerRpc.SearchPlayerReq req)
    {
        BaseRpcConnection rpcClient = null;
        try
        {
            rpcClient = rpcClientPool.borrowRpcClient();
            Rpc.RpcPacket resp = rpcClient.sendWaitBack(newRpcPacket(req));
            GameServerRpc.SearchPlayerResp ret = GameServerRpc.SearchPlayerResp.parseFrom(resp.getContent());
            rpcClientPool.returnRpcClient(rpcClient);
            return ret;
        } catch (Exception e)
        {
            rpcClientPool.returnBrokenRpcClient(rpcClient);
            throw new RpcException(e);
        }
    }
    
    
}