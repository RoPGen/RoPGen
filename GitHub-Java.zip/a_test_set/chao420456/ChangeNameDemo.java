package cn.itcast_03;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class ChangeNameDemo {
    public static void main(String[] args) throws IOException {
        File srcFolder = new File("d:\\java");

        File destFolder = new File("d:\\jad");
        if (!destFolder.exists()) {
            destFolder.mkdir();
        }

        File[] fileArray = srcFolder.listFiles();

        for (File file : fileArray) {
            String name = file.getName(); name = name.replace(".java", ".jad"); File newFile = new File(destFolder, name); copy(file, newFile);
        }
    }

    private static void copy(File file, File newFile) throws IOException {
        BufferedInputStream bis = new BufferedInputStream(new FileInputStream(
                file));
        BufferedOutputStream bos = new BufferedOutputStream(
                new FileOutputStream(newFile));

        byte[] bys = new byte[1024];
        int len = 0;
        while ((len = bis.read(bys)) != -1) {
            bos.write(bys, 0, len);
        }

        bos.close();
        bis.close();
    }
}
