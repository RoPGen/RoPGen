class MethodDemo {
    public static void main(String[] args) {
        int x = 10;
        int y = 20;

        System.out.println(sum(x,y));

        int result = sum(x,y);
        System.out.println(result);
    }

    public static int sum(int a,int b) {
        int c = a + b;
        return c;
    }
}