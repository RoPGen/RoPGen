package cn.itcast_02;

import java.io.File;
import java.io.IOException;

public class FileDemo {
    public static void main(String[] args) throws IOException {
        File file = new File("d:\\a.txt");

        System.out.println("createNewFile:" + file.createNewFile());

        File file2 = new File("d:\\demo");
        System.out.println("mkdir:" + file2.mkdir());

        File file4 = new File("d:\\aaa");
        File file5 = new File("d:\\aaa\\bbb");
        System.out.println("mkdir:" + file4.mkdir());
        System.out.println("mkdir:" + file5.mkdir());
        File file6 = new File("d:\\ccc\\dddd\\eee\\fff");
        System.out.println("mkdirs:" + file6.mkdirs());

        File file7 = new File("d:\\aaa\\bbb\\ccc.txt");
        System.out.println("mkdir:" + file7.mkdir());
    }
}
