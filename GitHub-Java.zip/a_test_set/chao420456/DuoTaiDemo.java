class Animal {
    public void eat(){}
    public void sport(){}

    

class Dog extends Animal {
    public void eat(){
        System.out.println("������");
    }

    public void sport(){
        System.out.println("���ܲ�");
    }

    public void lookDoor() {
        System.out.println("����");
    }
}

class Cat extends Animal {
    public void eat(){
        System.out.println("è����");
    }

    public void sport(){
        System.out.println("è������׽�Բ�");
    }
}

class Pig extends Animal {
    public void eat(){
        System.out.println("��������");
    }

    public void sport(){
        System.out.println("����˯��");
    }
}

class DuoTaiDemo {
    public static void main(String[] args) {
        Dog d = new Dog();
        Dog d2 = new Dog();
        Dog d3 = new Dog();

        printAnimal(d);
        printAnimal(d2);
        printAnimal(d3);
        System.out.println("-----------");

        Cat c = new Cat();
        Cat c2 = new Cat();
        Cat c3 = new Cat();

        printAnimal(c);
        printAnimal(c2);
        printAnimal(c3);
        System.out.println("-----------");

        Pig p = new Pig();
        Pig p2 = new Pig();
        Pig p3 = new Pig();

        printAnimal(p);
        printAnimal(p2);
        printAnimal(p3);

        }

    public static void printAnimal(Animal a) {  a.eat();
        a.sport();
    }
}