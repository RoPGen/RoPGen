package io.github.viscent.mtpattern.ch13.pipeline.example;

public class Config {

    public static int MAX_RECORDS_PER_FILE = 5000;

    public static int RECORD_SAVE_CHUNK_SIZE = 350;

    public static int WRITER_BUFFER_SIZE = 8192 * 10;
    
    public static int RECORD_JOIN_SIZE = 700;
