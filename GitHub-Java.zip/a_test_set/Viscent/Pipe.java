package io.github.viscent.mtpattern.ch13.pipeline;

import java.util.concurrent.TimeUnit;

public interface Pipe<IN, OUT> {
    void setNextPipe(Pipe<?, ?> nextPipe);

    void init(PipeContext pipeCtx);

    void shutdown(long timeout, TimeUnit unit);

    void process(IN input) throws InterruptedException;
}
