package com.yeshj.pacman.schedule;

import java.util.concurrent.ExecutorService;

import com.yeshj.pacman.jms.IMQReceiver;

public interface IWorkerPool extends ExecutorService{

    boolean canTakeTask(SystemInfo info);
    
    int takeNewTask(IMQReceiver receiver, IWorkerCallback callback);
}
