package org.andengine.examples.game.pong.adt;

public class PaddleUserData {
    private final int mOwnerID;
    private final int mOpponentID;

    public PaddleUserData(final int pOwnerID, final int pOpponentID) {
        this.mOwnerID = pOwnerID;
        this.mOpponentID = pOpponentID;
    }

    public int getOwnerID() {
        return this.mOwnerID;
    }

    public int getOpponentID() {
        return this.mOpponentID;
    }

    
