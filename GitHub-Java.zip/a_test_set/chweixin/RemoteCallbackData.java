package ipower.wechat.modal;

import ipower.wechat.message.Article;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
public class RemoteCallbackData implements Serializable {
    private static final long serialVersionUID = 1L;
    private String type,content;
    private List<Article> articles;
    
    public RemoteCallbackData(){
        this.setArticles(new ArrayList<Article>());
    }
    public String getType() {
        return type;
    }
    public void setType(String type) {
        this.type = type;
    }
    public String getContent() {
        return content;
    }
    public void setContent(String content) {
        this.content = content;
    }
    public List<Article> getArticles() {
        return articles;
    }
    public void setArticles(List<Article> articles) {
        this.articles = articles;
    }
}