package ipower.wechat.message;

import java.io.Serializable;

public class Video implements Serializable {
    private static final long serialVersionUID = 1L;
    private String title,mediaId,description;
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public String getMediaId() {
        return mediaId;
    }
    public void setMediaId(String mediaId) {
        this.mediaId = mediaId;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
}