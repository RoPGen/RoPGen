package com.nercis.isscp.appstore;

import org.apache.thrift.scheme.IScheme;
import org.apache.thrift.scheme.SchemeFactory;
import org.apache.thrift.scheme.StandardScheme;

import org.apache.thrift.scheme.TupleScheme;
import org.apache.thrift.protocol.TTupleProtocol;
import org.apache.thrift.EncodingUtils;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.Collections;
import java.util.BitSet;

public class UserApp implements org.apache.thrift.TBase<UserApp, UserApp._Fields>, java.io.Serializable, Cloneable, Comparable<UserApp> {
  private static final org.apache.thrift.protocol.TStruct STRUCT_DESC = new org.apache.thrift.protocol.TStruct("UserApp");

  private static final org.apache.thrift.protocol.TField APP_ID_FIELD_DESC = new org.apache.thrift.protocol.TField("app_id", org.apache.thrift.protocol.TType.STRING, (short)1);
  private static final org.apache.thrift.protocol.TField APP_NAME_FIELD_DESC = new org.apache.thrift.protocol.TField("app_name", org.apache.thrift.protocol.TType.STRING, (short)2);
  private static final org.apache.thrift.protocol.TField VERSIONCODE_FIELD_DESC = new org.apache.thrift.protocol.TField("versioncode", org.apache.thrift.protocol.TType.STRING, (short)3);
  private static final org.apache.thrift.protocol.TField URL_FIELD_DESC = new org.apache.thrift.protocol.TField("url", org.apache.thrift.protocol.TType.STRING, (short)4);
  private static final org.apache.thrift.protocol.TField APP_SIZE_FIELD_DESC = new org.apache.thrift.protocol.TField("app_size", org.apache.thrift.protocol.TType.I32, (short)5);
  private static final org.apache.thrift.protocol.TField MINSDKVERSION_FIELD_DESC = new org.apache.thrift.protocol.TField("minsdkversion", org.apache.thrift.protocol.TType.STRING, (short)6);
  private static final org.apache.thrift.protocol.TField APK_MD5_FIELD_DESC = new org.apache.thrift.protocol.TField("apk_md5", org.apache.thrift.protocol.TType.STRING, (short)7);
  private static final org.apache.thrift.protocol.TField NOTIFY_CALLBACK_URL_FIELD_DESC = new org.apache.thrift.protocol.TField("notify_callback_url", org.apache.thrift.protocol.TType.STRING, (short)8);
  private static final org.apache.thrift.protocol.TField APP_DESCRIPTION_FIELD_DESC = new org.apache.thrift.protocol.TField("app_description", org.apache.thrift.protocol.TType.STRING, (short)9);
  private static final org.apache.thrift.protocol.TField REQUEST_PURVIEWS_FIELD_DESC = new org.apache.thrift.protocol.TField("requestPurviews", org.apache.thrift.protocol.TType.LIST, (short)10);
  private static final org.apache.thrift.protocol.TField FORMAT_FIELD_DESC = new org.apache.thrift.protocol.TField("format", org.apache.thrift.protocol.TType.STRING, (short)11);

  private static final Map<Class<? extends IScheme>, SchemeFactory> schemes = new HashMap<Class<? extends IScheme>, SchemeFactory>();
  static {
    schemes.put(StandardScheme.class, new UserAppStandardSchemeFactory());
    schemes.put(TupleScheme.class, new UserAppTupleSchemeFactory());
  }

  public String app_id; public String app_name; public String versioncode; public String url; public int app_size; public String minsdkversion; public String apk_md5; public String notify_callback_url; public String app_description; public List<com.nercis.isscp.idl.permission.Permissions> requestPurviews; public String format; public enum _Fields implements org.apache.thrift.TFieldIdEnum {
    APP_ID((short)1, "app_id"),
    APP_NAME((short)2, "app_name"),
    VERSIONCODE((short)3, "versioncode"),
    URL((short)4, "url"),
    APP_SIZE((short)5, "app_size"),
    MINSDKVERSION((short)6, "minsdkversion"),
    APK_MD5((short)7, "apk_md5"),
    NOTIFY_CALLBACK_URL((short)8, "notify_callback_url"),
    APP_DESCRIPTION((short)9, "app_description"),
    REQUEST_PURVIEWS((short)10, "requestPurviews"),
    FORMAT((short)11, "format");

    private static final Map<String, _Fields> byName = new HashMap<String, _Fields>();

    static {
      for (_Fields field : EnumSet.allOf(_Fields.class)) {
        byName.put(field.getFieldName(), field);
      }
    }

    public static _Fields findByThriftId(int fieldId) {
      switch(fieldId) {
        case 1: return APP_ID;
        case 2: return APP_NAME;
        case 3: return VERSIONCODE;
        case 4: return URL;
        case 5: return APP_SIZE;
        case 6: return MINSDKVERSION;
        case 7: return APK_MD5;
        case 8: return NOTIFY_CALLBACK_URL;
        case 9: return APP_DESCRIPTION;
        case 10: return REQUEST_PURVIEWS;
        case 11: return FORMAT;
        default:
          return null;
      }
    }

    public static _Fields findByThriftIdOrThrow(int fieldId) {
      _Fields fields = findByThriftId(fieldId);
      if (fields == null) throw new IllegalArgumentException("Field " + fieldId + " doesn't exist!");
      return fields;
    }

    public static _Fields findByName(String name) {
      return byName.get(name);
    }

    private final short _thriftId;
    private final String _fieldName;

    _Fields(short thriftId, String fieldName) {
      _thriftId = thriftId;
      _fieldName = fieldName;
    }

    @Override
    public short getThriftFieldId() {
      return _thriftId;
    }

    @Override
    public String getFieldName() {
      return _fieldName;
    }
  }

  private static final int __APP_SIZE_ISSET_ID = 0;
  private byte __isset_bitfield = 0;
  public static final Map<_Fields, org.apache.thrift.meta_data.FieldMetaData> metaDataMap;
  static {
    Map<_Fields, org.apache.thrift.meta_data.FieldMetaData> tmpMap = new EnumMap<_Fields, org.apache.thrift.meta_data.FieldMetaData>(_Fields.class);
    tmpMap.put(_Fields.APP_ID, new org.apache.thrift.meta_data.FieldMetaData("app_id", org.apache.thrift.TFieldRequirementType.DEFAULT, 
        new org.apache.thrift.meta_data.FieldValueMetaData(org.apache.thrift.protocol.TType.STRING)));
    tmpMap.put(_Fields.APP_NAME, new org.apache.thrift.meta_data.FieldMetaData("app_name", org.apache.thrift.TFieldRequirementType.DEFAULT, 
        new org.apache.thrift.meta_data.FieldValueMetaData(org.apache.thrift.protocol.TType.STRING)));
    tmpMap.put(_Fields.VERSIONCODE, new org.apache.thrift.meta_data.FieldMetaData("versioncode", org.apache.thrift.TFieldRequirementType.DEFAULT, 
        new org.apache.thrift.meta_data.FieldValueMetaData(org.apache.thrift.protocol.TType.STRING)));
    tmpMap.put(_Fields.URL, new org.apache.thrift.meta_data.FieldMetaData("url", org.apache.thrift.TFieldRequirementType.DEFAULT, 
        new org.apache.thrift.meta_data.FieldValueMetaData(org.apache.thrift.protocol.TType.STRING)));
    tmpMap.put(_Fields.APP_SIZE, new org.apache.thrift.meta_data.FieldMetaData("app_size", org.apache.thrift.TFieldRequirementType.DEFAULT, 
        new org.apache.thrift.meta_data.FieldValueMetaData(org.apache.thrift.protocol.TType.I32)));
    tmpMap.put(_Fields.MINSDKVERSION, new org.apache.thrift.meta_data.FieldMetaData("minsdkversion", org.apache.thrift.TFieldRequirementType.DEFAULT, 
        new org.apache.thrift.meta_data.FieldValueMetaData(org.apache.thrift.protocol.TType.STRING)));
    tmpMap.put(_Fields.APK_MD5, new org.apache.thrift.meta_data.FieldMetaData("apk_md5", org.apache.thrift.TFieldRequirementType.DEFAULT, 
        new org.apache.thrift.meta_data.FieldValueMetaData(org.apache.thrift.protocol.TType.STRING)));
    tmpMap.put(_Fields.NOTIFY_CALLBACK_URL, new org.apache.thrift.meta_data.FieldMetaData("notify_callback_url", org.apache.thrift.TFieldRequirementType.DEFAULT, 
        new org.apache.thrift.meta_data.FieldValueMetaData(org.apache.thrift.protocol.TType.STRING)));
    tmpMap.put(_Fields.APP_DESCRIPTION, new org.apache.thrift.meta_data.FieldMetaData("app_description", org.apache.thrift.TFieldRequirementType.DEFAULT, 
        new org.apache.thrift.meta_data.FieldValueMetaData(org.apache.thrift.protocol.TType.STRING)));
    tmpMap.put(_Fields.REQUEST_PURVIEWS, new org.apache.thrift.meta_data.FieldMetaData("requestPurviews", org.apache.thrift.TFieldRequirementType.DEFAULT, 
        new org.apache.thrift.meta_data.ListMetaData(org.apache.thrift.protocol.TType.LIST, 
            new org.apache.thrift.meta_data.EnumMetaData(org.apache.thrift.protocol.TType.ENUM, com.nercis.isscp.idl.permission.Permissions.class))));
    tmpMap.put(_Fields.FORMAT, new org.apache.thrift.meta_data.FieldMetaData("format", org.apache.thrift.TFieldRequirementType.DEFAULT, 
        new org.apache.thrift.meta_data.FieldValueMetaData(org.apache.thrift.protocol.TType.STRING)));
    metaDataMap = Collections.unmodifiableMap(tmpMap);
    org.apache.thrift.meta_data.FieldMetaData.addStructMetaDataMap(UserApp.class, metaDataMap);
  }

  public UserApp() {
  }

  public UserApp(
    String app_id,
    String app_name,
    String versioncode,
    String url,
    int app_size,
    String minsdkversion,
    String apk_md5,
    String notify_callback_url,
    String app_description,
    List<com.nercis.isscp.idl.permission.Permissions> requestPurviews,
    String format)
  {
    this();
    this.app_id = app_id;
    this.app_name = app_name;
    this.versioncode = versioncode;
    this.url = url;
    this.app_size = app_size;
    setApp_sizeIsSet(true);
    this.minsdkversion = minsdkversion;
    this.apk_md5 = apk_md5;
    this.notify_callback_url = notify_callback_url;
    this.app_description = app_description;
    this.requestPurviews = requestPurviews;
    this.format = format;
  }

  public UserApp(UserApp other) {
    __isset_bitfield = other.__isset_bitfield;
    if (other.isSetApp_id()) {
      this.app_id = other.app_id;
    }
    if (other.isSetApp_name()) {
      this.app_name = other.app_name;
    }
    if (other.isSetVersioncode()) {
      this.versioncode = other.versioncode;
    }
    if (other.isSetUrl()) {
      this.url = other.url;
    }
    this.app_size = other.app_size;
    if (other.isSetMinsdkversion()) {
      this.minsdkversion = other.minsdkversion;
    }
    if (other.isSetApk_md5()) {
      this.apk_md5 = other.apk_md5;
    }
    if (other.isSetNotify_callback_url()) {
      this.notify_callback_url = other.notify_callback_url;
    }
    if (other.isSetApp_description()) {
      this.app_description = other.app_description;
    }
    if (other.isSetRequestPurviews()) {
      List<com.nercis.isscp.idl.permission.Permissions> __this__requestPurviews = new ArrayList<com.nercis.isscp.idl.permission.Permissions>(other.requestPurviews.size());
      for (com.nercis.isscp.idl.permission.Permissions other_element : other.requestPurviews) {
        __this__requestPurviews.add(other_element);
      }
      this.requestPurviews = __this__requestPurviews;
    }
    if (other.isSetFormat()) {
      this.format = other.format;
    }
  }

  @Override
public UserApp deepCopy() {
    return new UserApp(this);
  }

  @Override
  public void clear() {
    this.app_id = null;
    this.app_name = null;
    this.versioncode = null;
    this.url = null;
    setApp_sizeIsSet(false);
    this.app_size = 0;
    this.minsdkversion = null;
    this.apk_md5 = null;
    this.notify_callback_url = null;
    this.app_description = null;
    this.requestPurviews = null;
    this.format = null;
  }

  public String getApp_id() {
    return this.app_id;
  }

  public UserApp setApp_id(String app_id) {
    this.app_id = app_id;
    return this;
  }

  public void unsetApp_id() {
    this.app_id = null;
  }

  public boolean isSetApp_id() {
    return this.app_id != null;
  }

  public void setApp_idIsSet(boolean value) {
    if (!value) {
      this.app_id = null;
    }
  }

  public String getApp_name() {
    return this.app_name;
  }

  public UserApp setApp_name(String app_name) {
    this.app_name = app_name;
    return this;
  }

  public void unsetApp_name() {
    this.app_name = null;
  }

  public boolean isSetApp_name() {
    return this.app_name != null;
  }

  public void setApp_nameIsSet(boolean value) {
    if (!value) {
      this.app_name = null;
    }
  }

  public String getVersioncode() {
    return this.versioncode;
  }

  public UserApp setVersioncode(String versioncode) {
    this.versioncode = versioncode;
    return this;
  }

  public void unsetVersioncode() {
    this.versioncode = null;
  }

  public boolean isSetVersioncode() {
    return this.versioncode != null;
  }

  public void setVersioncodeIsSet(boolean value) {
    if (!value) {
      this.versioncode = null;
    }
  }

  public String getUrl() {
    return this.url;
  }

  public UserApp setUrl(String url) {
    this.url = url;
    return this;
  }

  public void unsetUrl() {
    this.url = null;
  }

  public boolean isSetUrl() {
    return this.url != null;
  }

  public void setUrlIsSet(boolean value) {
    if (!value) {
      this.url = null;
    }
  }

  public int getApp_size() {
    return this.app_size;
  }

  public UserApp setApp_size(int app_size) {
    this.app_size = app_size;
    setApp_sizeIsSet(true);
    return this;
  }

  public void unsetApp_size() {
    __isset_bitfield = EncodingUtils.clearBit(__isset_bitfield, __APP_SIZE_ISSET_ID);
  }

  public boolean isSetApp_size() {
    return EncodingUtils.testBit(__isset_bitfield, __APP_SIZE_ISSET_ID);
  }

  public void setApp_sizeIsSet(boolean value) {
    __isset_bitfield = EncodingUtils.setBit(__isset_bitfield, __APP_SIZE_ISSET_ID, value);
  }

  public String getMinsdkversion() {
    return this.minsdkversion;
  }

  public UserApp setMinsdkversion(String minsdkversion) {
    this.minsdkversion = minsdkversion;
    return this;
  }

  public void unsetMinsdkversion() {
    this.minsdkversion = null;
  }

  public boolean isSetMinsdkversion() {
    return this.minsdkversion != null;
  }

  public void setMinsdkversionIsSet(boolean value) {
    if (!value) {
      this.minsdkversion = null;
    }
  }

  public String getApk_md5() {
    return this.apk_md5;
  }

  public UserApp setApk_md5(String apk_md5) {
    this.apk_md5 = apk_md5;
    return this;
  }

  public void unsetApk_md5() {
    this.apk_md5 = null;
  }

  public boolean isSetApk_md5() {
    return this.apk_md5 != null;
  }

  public void setApk_md5IsSet(boolean value) {
    if (!value) {
      this.apk_md5 = null;
    }
  }

  public String getNotify_callback_url() {
    return this.notify_callback_url;
  }

  public UserApp setNotify_callback_url(String notify_callback_url) {
    this.notify_callback_url = notify_callback_url;
    return this;
  }

  public void unsetNotify_callback_url() {
    this.notify_callback_url = null;
  }

  public boolean isSetNotify_callback_url() {
    return this.notify_callback_url != null;
  }

  public void setNotify_callback_urlIsSet(boolean value) {
    if (!value) {
      this.notify_callback_url = null;
    }
  }

  public String getApp_description() {
    return this.app_description;
  }

  public UserApp setApp_description(String app_description) {
    this.app_description = app_description;
    return this;
  }

  public void unsetApp_description() {
    this.app_description = null;
  }

  public boolean isSetApp_description() {
    return this.app_description != null;
  }

  public void setApp_descriptionIsSet(boolean value) {
    if (!value) {
      this.app_description = null;
    }
  }

  public int getRequestPurviewsSize() {
    return (this.requestPurviews == null) ? 0 : this.requestPurviews.size();
  }

  public java.util.Iterator<com.nercis.isscp.idl.permission.Permissions> getRequestPurviewsIterator() {
    return (this.requestPurviews == null) ? null : this.requestPurviews.iterator();
  }

  public void addToRequestPurviews(com.nercis.isscp.idl.permission.Permissions elem) {
    if (this.requestPurviews == null) {
      this.requestPurviews = new ArrayList<com.nercis.isscp.idl.permission.Permissions>();
    }
    this.requestPurviews.add(elem);
  }

  public List<com.nercis.isscp.idl.permission.Permissions> getRequestPurviews() {
    return this.requestPurviews;
  }

  public UserApp setRequestPurviews(List<com.nercis.isscp.idl.permission.Permissions> requestPurviews) {
    this.requestPurviews = requestPurviews;
    return this;
  }

  public void unsetRequestPurviews() {
    this.requestPurviews = null;
  }

  public boolean isSetRequestPurviews() {
    return this.requestPurviews != null;
  }

  public void setRequestPurviewsIsSet(boolean value) {
    if (!value) {
      this.requestPurviews = null;
    }
  }

  public String getFormat() {
    return this.format;
  }

  public UserApp setFormat(String format) {
    this.format = format;
    return this;
  }

  public void unsetFormat() {
    this.format = null;
  }

  public boolean isSetFormat() {
    return this.format != null;
  }

  public void setFormatIsSet(boolean value) {
    if (!value) {
      this.format = null;
    }
  }

  @Override
public void setFieldValue(_Fields field, Object value) {
    switch (field) {
    case APP_ID:
      if (value == null) {
        unsetApp_id();
      } else {
        setApp_id((String)value);
      }
      break;

    case APP_NAME:
      if (value == null) {
        unsetApp_name();
      } else {
        setApp_name((String)value);
      }
      break;

    case VERSIONCODE:
      if (value == null) {
        unsetVersioncode();
      } else {
        setVersioncode((String)value);
      }
      break;

    case URL:
      if (value == null) {
        unsetUrl();
      } else {
        setUrl((String)value);
      }
      break;

    case APP_SIZE:
      if (value == null) {
        unsetApp_size();
      } else {
        setApp_size((Integer)value);
      }
      break;

    case MINSDKVERSION:
      if (value == null) {
        unsetMinsdkversion();
      } else {
        setMinsdkversion((String)value);
      }
      break;

    case APK_MD5:
      if (value == null) {
        unsetApk_md5();
      } else {
        setApk_md5((String)value);
      }
      break;

    case NOTIFY_CALLBACK_URL:
      if (value == null) {
        unsetNotify_callback_url();
      } else {
        setNotify_callback_url((String)value);
      }
      break;

    case APP_DESCRIPTION:
      if (value == null) {
        unsetApp_description();
      } else {
        setApp_description((String)value);
      }
      break;

    case REQUEST_PURVIEWS:
      if (value == null) {
        unsetRequestPurviews();
      } else {
        setRequestPurviews((List<com.nercis.isscp.idl.permission.Permissions>)value);
      }
      break;

    case FORMAT:
      if (value == null) {
        unsetFormat();
      } else {
        setFormat((String)value);
      }
      break;

    }
  }

  @Override
public Object getFieldValue(_Fields field) {
    switch (field) {
    case APP_ID:
      return getApp_id();

    case APP_NAME:
      return getApp_name();

    case VERSIONCODE:
      return getVersioncode();

    case URL:
      return getUrl();

    case APP_SIZE:
      return Integer.valueOf(getApp_size());

    case MINSDKVERSION:
      return getMinsdkversion();

    case APK_MD5:
      return getApk_md5();

    case NOTIFY_CALLBACK_URL:
      return getNotify_callback_url();

    case APP_DESCRIPTION:
      return getApp_description();

    case REQUEST_PURVIEWS:
      return getRequestPurviews();

    case FORMAT:
      return getFormat();

    }
    throw new IllegalStateException();
  }

  @Override
public boolean isSet(_Fields field) {
    if (field == null) {
      throw new IllegalArgumentException();
    }

    switch (field) {
    case APP_ID:
      return isSetApp_id();
    case APP_NAME:
      return isSetApp_name();
    case VERSIONCODE:
      return isSetVersioncode();
    case URL:
      return isSetUrl();
    case APP_SIZE:
      return isSetApp_size();
    case MINSDKVERSION:
      return isSetMinsdkversion();
    case APK_MD5:
      return isSetApk_md5();
    case NOTIFY_CALLBACK_URL:
      return isSetNotify_callback_url();
    case APP_DESCRIPTION:
      return isSetApp_description();
    case REQUEST_PURVIEWS:
      return isSetRequestPurviews();
    case FORMAT:
      return isSetFormat();
    }
    throw new IllegalStateException();
  }

  @Override
  public boolean equals(Object that) {
    if (that == null)
      return false;
    if (that instanceof UserApp)
      return this.equals((UserApp)that);
    return false;
  }

  public boolean equals(UserApp that) {
    if (that == null)
      return false;

    boolean this_present_app_id = true && this.isSetApp_id();
    boolean that_present_app_id = true && that.isSetApp_id();
    if (this_present_app_id || that_present_app_id) {
      if (!(this_present_app_id && that_present_app_id))
        return false;
      if (!this.app_id.equals(that.app_id))
        return false;
    }

    boolean this_present_app_name = true && this.isSetApp_name();
    boolean that_present_app_name = true && that.isSetApp_name();
    if (this_present_app_name || that_present_app_name) {
      if (!(this_present_app_name && that_present_app_name))
        return false;
      if (!this.app_name.equals(that.app_name))
        return false;
    }

    boolean this_present_versioncode = true && this.isSetVersioncode();
    boolean that_present_versioncode = true && that.isSetVersioncode();
    if (this_present_versioncode || that_present_versioncode) {
      if (!(this_present_versioncode && that_present_versioncode))
        return false;
      if (!this.versioncode.equals(that.versioncode))
        return false;
    }

    boolean this_present_url = true && this.isSetUrl();
    boolean that_present_url = true && that.isSetUrl();
    if (this_present_url || that_present_url) {
      if (!(this_present_url && that_present_url))
        return false;
      if (!this.url.equals(that.url))
        return false;
    }

    boolean this_present_app_size = true;
    boolean that_present_app_size = true;
    if (this_present_app_size || that_present_app_size) {
      if (!(this_present_app_size && that_present_app_size))
        return false;
      if (this.app_size != that.app_size)
        return false;
    }

    boolean this_present_minsdkversion = true && this.isSetMinsdkversion();
    boolean that_present_minsdkversion = true && that.isSetMinsdkversion();
    if (this_present_minsdkversion || that_present_minsdkversion) {
      if (!(this_present_minsdkversion && that_present_minsdkversion))
        return false;
      if (!this.minsdkversion.equals(that.minsdkversion))
        return false;
    }

    boolean this_present_apk_md5 = true && this.isSetApk_md5();
    boolean that_present_apk_md5 = true && that.isSetApk_md5();
    if (this_present_apk_md5 || that_present_apk_md5) {
      if (!(this_present_apk_md5 && that_present_apk_md5))
        return false;
      if (!this.apk_md5.equals(that.apk_md5))
        return false;
    }

    boolean this_present_notify_callback_url = true && this.isSetNotify_callback_url();
    boolean that_present_notify_callback_url = true && that.isSetNotify_callback_url();
    if (this_present_notify_callback_url || that_present_notify_callback_url) {
      if (!(this_present_notify_callback_url && that_present_notify_callback_url))
        return false;
      if (!this.notify_callback_url.equals(that.notify_callback_url))
        return false;
    }

    boolean this_present_app_description = true && this.isSetApp_description();
    boolean that_present_app_description = true && that.isSetApp_description();
    if (this_present_app_description || that_present_app_description) {
      if (!(this_present_app_description && that_present_app_description))
        return false;
      if (!this.app_description.equals(that.app_description))
        return false;
    }

    boolean this_present_requestPurviews = true && this.isSetRequestPurviews();
    boolean that_present_requestPurviews = true && that.isSetRequestPurviews();
    if (this_present_requestPurviews || that_present_requestPurviews) {
      if (!(this_present_requestPurviews && that_present_requestPurviews))
        return false;
      if (!this.requestPurviews.equals(that.requestPurviews))
        return false;
    }

    boolean this_present_format = true && this.isSetFormat();
    boolean that_present_format = true && that.isSetFormat();
    if (this_present_format || that_present_format) {
      if (!(this_present_format && that_present_format))
        return false;
      if (!this.format.equals(that.format))
        return false;
    }

    return true;
  }

  @Override
  public int hashCode() {
    return 0;
  }

  @Override
  public int compareTo(UserApp other) {
    if (!getClass().equals(other.getClass())) {
      return getClass().getName().compareTo(other.getClass().getName());
    }

    int lastComparison = 0;

    lastComparison = Boolean.valueOf(isSetApp_id()).compareTo(other.isSetApp_id());
    if (lastComparison != 0) {
      return lastComparison;
    }
    if (isSetApp_id()) {
      lastComparison = org.apache.thrift.TBaseHelper.compareTo(this.app_id, other.app_id);
      if (lastComparison != 0) {
        return lastComparison;
      }
    }
    lastComparison = Boolean.valueOf(isSetApp_name()).compareTo(other.isSetApp_name());
    if (lastComparison != 0) {
      return lastComparison;
    }
    if (isSetApp_name()) {
      lastComparison = org.apache.thrift.TBaseHelper.compareTo(this.app_name, other.app_name);
      if (lastComparison != 0) {
        return lastComparison;
      }
    }
    lastComparison = Boolean.valueOf(isSetVersioncode()).compareTo(other.isSetVersioncode());
    if (lastComparison != 0) {
      return lastComparison;
    }
    if (isSetVersioncode()) {
      lastComparison = org.apache.thrift.TBaseHelper.compareTo(this.versioncode, other.versioncode);
      if (lastComparison != 0) {
        return lastComparison;
      }
    }
    lastComparison = Boolean.valueOf(isSetUrl()).compareTo(other.isSetUrl());
    if (lastComparison != 0) {
      return lastComparison;
    }
    if (isSetUrl()) {
      lastComparison = org.apache.thrift.TBaseHelper.compareTo(this.url, other.url);
      if (lastComparison != 0) {
        return lastComparison;
      }
    }
    lastComparison = Boolean.valueOf(isSetApp_size()).compareTo(other.isSetApp_size());
    if (lastComparison != 0) {
      return lastComparison;
    }
    if (isSetApp_size()) {
      lastComparison = org.apache.thrift.TBaseHelper.compareTo(this.app_size, other.app_size);
      if (lastComparison != 0) {
        return lastComparison;
      }
    }
    lastComparison = Boolean.valueOf(isSetMinsdkversion()).compareTo(other.isSetMinsdkversion());
    if (lastComparison != 0) {
      return lastComparison;
    }
    if (isSetMinsdkversion()) {
      lastComparison = org.apache.thrift.TBaseHelper.compareTo(this.minsdkversion, other.minsdkversion);
      if (lastComparison != 0) {
        return lastComparison;
      }
    }
    lastComparison = Boolean.valueOf(isSetApk_md5()).compareTo(other.isSetApk_md5());
    if (lastComparison != 0) {
      return lastComparison;
    }
    if (isSetApk_md5()) {
      lastComparison = org.apache.thrift.TBaseHelper.compareTo(this.apk_md5, other.apk_md5);
      if (lastComparison != 0) {
        return lastComparison;
      }
    }
    lastComparison = Boolean.valueOf(isSetNotify_callback_url()).compareTo(other.isSetNotify_callback_url());
    if (lastComparison != 0) {
      return lastComparison;
    }
    if (isSetNotify_callback_url()) {
      lastComparison = org.apache.thrift.TBaseHelper.compareTo(this.notify_callback_url, other.notify_callback_url);
      if (lastComparison != 0) {
        return lastComparison;
      }
    }
    lastComparison = Boolean.valueOf(isSetApp_description()).compareTo(other.isSetApp_description());
    if (lastComparison != 0) {
      return lastComparison;
    }
    if (isSetApp_description()) {
      lastComparison = org.apache.thrift.TBaseHelper.compareTo(this.app_description, other.app_description);
      if (lastComparison != 0) {
        return lastComparison;
      }
    }
    lastComparison = Boolean.valueOf(isSetRequestPurviews()).compareTo(other.isSetRequestPurviews());
    if (lastComparison != 0) {
      return lastComparison;
    }
    if (isSetRequestPurviews()) {
      lastComparison = org.apache.thrift.TBaseHelper.compareTo(this.requestPurviews, other.requestPurviews);
      if (lastComparison != 0) {
        return lastComparison;
      }
    }
    lastComparison = Boolean.valueOf(isSetFormat()).compareTo(other.isSetFormat());
    if (lastComparison != 0) {
      return lastComparison;
    }
    if (isSetFormat()) {
      lastComparison = org.apache.thrift.TBaseHelper.compareTo(this.format, other.format);
      if (lastComparison != 0) {
        return lastComparison;
      }
    }
    return 0;
  }

  @Override
public _Fields fieldForId(int fieldId) {
    return _Fields.findByThriftId(fieldId);
  }

  @Override
public void read(org.apache.thrift.protocol.TProtocol iprot) throws org.apache.thrift.TException {
    schemes.get(iprot.getScheme()).getScheme().read(iprot, this);
  }

  @Override
public void write(org.apache.thrift.protocol.TProtocol oprot) throws org.apache.thrift.TException {
    schemes.get(oprot.getScheme()).getScheme().write(oprot, this);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder("UserApp(");
    boolean first = true;

    sb.append("app_id:");
    if (this.app_id == null) {
      sb.append("null");
    } else {
      sb.append(this.app_id);
    }
    first = false;
    if (!first) sb.append(", ");
    sb.append("app_name:");
    if (this.app_name == null) {
      sb.append("null");
    } else {
      sb.append(this.app_name);
    }
    first = false;
    if (!first) sb.append(", ");
    sb.append("versioncode:");
    if (this.versioncode == null) {
      sb.append("null");
    } else {
      sb.append(this.versioncode);
    }
    first = false;
    if (!first) sb.append(", ");
    sb.append("url:");
    if (this.url == null) {
      sb.append("null");
    } else {
      sb.append(this.url);
    }
    first = false;
    if (!first) sb.append(", ");
    sb.append("app_size:");
    sb.append(this.app_size);
    first = false;
    if (!first) sb.append(", ");
    sb.append("minsdkversion:");
    if (this.minsdkversion == null) {
      sb.append("null");
    } else {
      sb.append(this.minsdkversion);
    }
    first = false;
    if (!first) sb.append(", ");
    sb.append("apk_md5:");
    if (this.apk_md5 == null) {
      sb.append("null");
    } else {
      sb.append(this.apk_md5);
    }
    first = false;
    if (!first) sb.append(", ");
    sb.append("notify_callback_url:");
    if (this.notify_callback_url == null) {
      sb.append("null");
    } else {
      sb.append(this.notify_callback_url);
    }
    first = false;
    if (!first) sb.append(", ");
    sb.append("app_description:");
    if (this.app_description == null) {
      sb.append("null");
    } else {
      sb.append(this.app_description);
    }
    first = false;
    if (!first) sb.append(", ");
    sb.append("requestPurviews:");
    if (this.requestPurviews == null) {
      sb.append("null");
    } else {
      sb.append(this.requestPurviews);
    }
    first = false;
    if (!first) sb.append(", ");
    sb.append("format:");
    if (this.format == null) {
      sb.append("null");
    } else {
      sb.append(this.format);
    }
    first = false;
    sb.append(")");
    return sb.toString();
  }

  public void validate() throws org.apache.thrift.TException {
    }

  private void writeObject(java.io.ObjectOutputStream out) throws java.io.IOException {
    try {
      write(new org.apache.thrift.protocol.TCompactProtocol(new org.apache.thrift.transport.TIOStreamTransport(out)));
    } catch (org.apache.thrift.TException te) {
      throw new java.io.IOException(te);
    }
  }

  private void readObject(java.io.ObjectInputStream in) throws java.io.IOException, ClassNotFoundException {
    try {
      __isset_bitfield = 0;
      read(new org.apache.thrift.protocol.TCompactProtocol(new org.apache.thrift.transport.TIOStreamTransport(in)));
    } catch (org.apache.thrift.TException te) {
      throw new java.io.IOException(te);
    }
  }

  private static class UserAppStandardSchemeFactory implements SchemeFactory {
    @Override
    public UserAppStandardScheme getScheme() {
      return new UserAppStandardScheme();
    }
  }

  private static class UserAppStandardScheme extends StandardScheme<UserApp> {

    @Override
    public void read(org.apache.thrift.protocol.TProtocol iprot, UserApp struct) throws org.apache.thrift.TException {
      org.apache.thrift.protocol.TField schemeField;
      iprot.readStructBegin();
      while (true)
      {
        schemeField = iprot.readFieldBegin();
        if (schemeField.type == org.apache.thrift.protocol.TType.STOP) { 
          break;
        }
        switch (schemeField.id) {
          case 1: if (schemeField.type == org.apache.thrift.protocol.TType.STRING) {
              struct.app_id = iprot.readString();
              struct.setApp_idIsSet(true);
            } else { 
              org.apache.thrift.protocol.TProtocolUtil.skip(iprot, schemeField.type);
            }
            break;
          case 2: if (schemeField.type == org.apache.thrift.protocol.TType.STRING) {
              struct.app_name = iprot.readString();
              struct.setApp_nameIsSet(true);
            } else { 
              org.apache.thrift.protocol.TProtocolUtil.skip(iprot, schemeField.type);
            }
            break;
          case 3: if (schemeField.type == org.apache.thrift.protocol.TType.STRING) {
              struct.versioncode = iprot.readString();
              struct.setVersioncodeIsSet(true);
            } else { 
              org.apache.thrift.protocol.TProtocolUtil.skip(iprot, schemeField.type);
            }
            break;
          case 4: if (schemeField.type == org.apache.thrift.protocol.TType.STRING) {
              struct.url = iprot.readString();
              struct.setUrlIsSet(true);
            } else { 
              org.apache.thrift.protocol.TProtocolUtil.skip(iprot, schemeField.type);
            }
            break;
          case 5: if (schemeField.type == org.apache.thrift.protocol.TType.I32) {
              struct.app_size = iprot.readI32();
              struct.setApp_sizeIsSet(true);
            } else { 
              org.apache.thrift.protocol.TProtocolUtil.skip(iprot, schemeField.type);
            }
            break;
          case 6: if (schemeField.type == org.apache.thrift.protocol.TType.STRING) {
              struct.minsdkversion = iprot.readString();
              struct.setMinsdkversionIsSet(true);
            } else { 
              org.apache.thrift.protocol.TProtocolUtil.skip(iprot, schemeField.type);
            }
            break;
          case 7: if (schemeField.type == org.apache.thrift.protocol.TType.STRING) {
              struct.apk_md5 = iprot.readString();
              struct.setApk_md5IsSet(true);
            } else { 
              org.apache.thrift.protocol.TProtocolUtil.skip(iprot, schemeField.type);
            }
            break;
          case 8: if (schemeField.type == org.apache.thrift.protocol.TType.STRING) {
              struct.notify_callback_url = iprot.readString();
              struct.setNotify_callback_urlIsSet(true);
            } else { 
              org.apache.thrift.protocol.TProtocolUtil.skip(iprot, schemeField.type);
            }
            break;
          case 9: if (schemeField.type == org.apache.thrift.protocol.TType.STRING) {
              struct.app_description = iprot.readString();
              struct.setApp_descriptionIsSet(true);
            } else { 
              org.apache.thrift.protocol.TProtocolUtil.skip(iprot, schemeField.type);
            }
            break;
          case 10: if (schemeField.type == org.apache.thrift.protocol.TType.LIST) {
              {
                org.apache.thrift.protocol.TList _list0 = iprot.readListBegin();
                struct.requestPurviews = new ArrayList<com.nercis.isscp.idl.permission.Permissions>(_list0.size);
                for (int _i1 = 0; _i1 < _list0.size; ++_i1)
                {
                  com.nercis.isscp.idl.permission.Permissions _elem2;
                  _elem2 = com.nercis.isscp.idl.permission.Permissions.findByValue(iprot.readI32());
                  struct.requestPurviews.add(_elem2);
                }
                iprot.readListEnd();
              }
              struct.setRequestPurviewsIsSet(true);
            } else { 
              org.apache.thrift.protocol.TProtocolUtil.skip(iprot, schemeField.type);
            }
            break;
          case 11: if (schemeField.type == org.apache.thrift.protocol.TType.STRING) {
              struct.format = iprot.readString();
              struct.setFormatIsSet(true);
            } else { 
              org.apache.thrift.protocol.TProtocolUtil.skip(iprot, schemeField.type);
            }
            break;
          default:
            org.apache.thrift.protocol.TProtocolUtil.skip(iprot, schemeField.type);
        }
        iprot.readFieldEnd();
      }
      iprot.readStructEnd();

      struct.validate();
    }

    @Override
    public void write(org.apache.thrift.protocol.TProtocol oprot, UserApp struct) throws org.apache.thrift.TException {
      struct.validate();

      oprot.writeStructBegin(STRUCT_DESC);
      if (struct.app_id != null) {
        oprot.writeFieldBegin(APP_ID_FIELD_DESC);
        oprot.writeString(struct.app_id);
        oprot.writeFieldEnd();
      }
      if (struct.app_name != null) {
        oprot.writeFieldBegin(APP_NAME_FIELD_DESC);
        oprot.writeString(struct.app_name);
        oprot.writeFieldEnd();
      }
      if (struct.versioncode != null) {
        oprot.writeFieldBegin(VERSIONCODE_FIELD_DESC);
        oprot.writeString(struct.versioncode);
        oprot.writeFieldEnd();
      }
      if (struct.url != null) {
        oprot.writeFieldBegin(URL_FIELD_DESC);
        oprot.writeString(struct.url);
        oprot.writeFieldEnd();
      }
      oprot.writeFieldBegin(APP_SIZE_FIELD_DESC);
      oprot.writeI32(struct.app_size);
      oprot.writeFieldEnd();
      if (struct.minsdkversion != null) {
        oprot.writeFieldBegin(MINSDKVERSION_FIELD_DESC);
        oprot.writeString(struct.minsdkversion);
        oprot.writeFieldEnd();
      }
      if (struct.apk_md5 != null) {
        oprot.writeFieldBegin(APK_MD5_FIELD_DESC);
        oprot.writeString(struct.apk_md5);
        oprot.writeFieldEnd();
      }
      if (struct.notify_callback_url != null) {
        oprot.writeFieldBegin(NOTIFY_CALLBACK_URL_FIELD_DESC);
        oprot.writeString(struct.notify_callback_url);
        oprot.writeFieldEnd();
      }
      if (struct.app_description != null) {
        oprot.writeFieldBegin(APP_DESCRIPTION_FIELD_DESC);
        oprot.writeString(struct.app_description);
        oprot.writeFieldEnd();
      }
      if (struct.requestPurviews != null) {
        oprot.writeFieldBegin(REQUEST_PURVIEWS_FIELD_DESC);
        {
          oprot.writeListBegin(new org.apache.thrift.protocol.TList(org.apache.thrift.protocol.TType.I32, struct.requestPurviews.size()));
          for (com.nercis.isscp.idl.permission.Permissions _iter3 : struct.requestPurviews)
          {
            oprot.writeI32(_iter3.getValue());
          }
          oprot.writeListEnd();
        }
        oprot.writeFieldEnd();
      }
      if (struct.format != null) {
        oprot.writeFieldBegin(FORMAT_FIELD_DESC);
        oprot.writeString(struct.format);
        oprot.writeFieldEnd();
      }
      oprot.writeFieldStop();
      oprot.writeStructEnd();
    }

  }

  private static class UserAppTupleSchemeFactory implements SchemeFactory {
    @Override
    public UserAppTupleScheme getScheme() {
      return new UserAppTupleScheme();
    }
  }

  private static class UserAppTupleScheme extends TupleScheme<UserApp> {

    @Override
    public void write(org.apache.thrift.protocol.TProtocol prot, UserApp struct) throws org.apache.thrift.TException {
      TTupleProtocol oprot = (TTupleProtocol) prot;
      BitSet optionals = new BitSet();
      if (struct.isSetApp_id()) {
        optionals.set(0);
      }
      if (struct.isSetApp_name()) {
        optionals.set(1);
      }
      if (struct.isSetVersioncode()) {
        optionals.set(2);
      }
      if (struct.isSetUrl()) {
        optionals.set(3);
      }
      if (struct.isSetApp_size()) {
        optionals.set(4);
      }
      if (struct.isSetMinsdkversion()) {
        optionals.set(5);
      }
      if (struct.isSetApk_md5()) {
        optionals.set(6);
      }
      if (struct.isSetNotify_callback_url()) {
        optionals.set(7);
      }
      if (struct.isSetApp_description()) {
        optionals.set(8);
      }
      if (struct.isSetRequestPurviews()) {
        optionals.set(9);
      }
      if (struct.isSetFormat()) {
        optionals.set(10);
      }
      oprot.writeBitSet(optionals, 11);
      if (struct.isSetApp_id()) {
        oprot.writeString(struct.app_id);
      }
      if (struct.isSetApp_name()) {
        oprot.writeString(struct.app_name);
      }
      if (struct.isSetVersioncode()) {
        oprot.writeString(struct.versioncode);
      }
      if (struct.isSetUrl()) {
        oprot.writeString(struct.url);
      }
      if (struct.isSetApp_size()) {
        oprot.writeI32(struct.app_size);
      }
      if (struct.isSetMinsdkversion()) {
        oprot.writeString(struct.minsdkversion);
      }
      if (struct.isSetApk_md5()) {
        oprot.writeString(struct.apk_md5);
      }
      if (struct.isSetNotify_callback_url()) {
        oprot.writeString(struct.notify_callback_url);
      }
      if (struct.isSetApp_description()) {
        oprot.writeString(struct.app_description);
      }
      if (struct.isSetRequestPurviews()) {
        {
          oprot.writeI32(struct.requestPurviews.size());
          for (com.nercis.isscp.idl.permission.Permissions _iter4 : struct.requestPurviews)
          {
            oprot.writeI32(_iter4.getValue());
          }
        }
      }
      if (struct.isSetFormat()) {
        oprot.writeString(struct.format);
      }
    }

    @Override
    public void read(org.apache.thrift.protocol.TProtocol prot, UserApp struct) throws org.apache.thrift.TException {
      TTupleProtocol iprot = (TTupleProtocol) prot;
      BitSet incoming = iprot.readBitSet(11);
      if (incoming.get(0)) {
        struct.app_id = iprot.readString();
        struct.setApp_idIsSet(true);
      }
      if (incoming.get(1)) {
        struct.app_name = iprot.readString();
        struct.setApp_nameIsSet(true);
      }
      if (incoming.get(2)) {
        struct.versioncode = iprot.readString();
        struct.setVersioncodeIsSet(true);
      }
      if (incoming.get(3)) {
        struct.url = iprot.readString();
        struct.setUrlIsSet(true);
      }
      if (incoming.get(4)) {
        struct.app_size = iprot.readI32();
        struct.setApp_sizeIsSet(true);
      }
      if (incoming.get(5)) {
        struct.minsdkversion = iprot.readString();
        struct.setMinsdkversionIsSet(true);
      }
      if (incoming.get(6)) {
        struct.apk_md5 = iprot.readString();
        struct.setApk_md5IsSet(true);
      }
      if (incoming.get(7)) {
        struct.notify_callback_url = iprot.readString();
        struct.setNotify_callback_urlIsSet(true);
      }
      if (incoming.get(8)) {
        struct.app_description = iprot.readString();
        struct.setApp_descriptionIsSet(true);
      }
      if (incoming.get(9)) {
        {
          org.apache.thrift.protocol.TList _list5 = new org.apache.thrift.protocol.TList(org.apache.thrift.protocol.TType.I32, iprot.readI32());
          struct.requestPurviews = new ArrayList<com.nercis.isscp.idl.permission.Permissions>(_list5.size);
          for (int _i6 = 0; _i6 < _list5.size; ++_i6)
          {
            com.nercis.isscp.idl.permission.Permissions _elem7;
            _elem7 = com.nercis.isscp.idl.permission.Permissions.findByValue(iprot.readI32());
            struct.requestPurviews.add(_elem7);
          }
        }
        struct.setRequestPurviewsIsSet(true);
      }
      if (incoming.get(10)) {
        struct.format = iprot.readString();
        struct.setFormatIsSet(true);
      }
    }
  }

}

