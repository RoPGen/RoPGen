package com.nercis.isscp.engine.bupt.impl;

import java.util.List;
import java.util.Map;

import org.apache.thrift.TException;

import com.nercis.isscp.idl.APICheck;
import com.nercis.isscp.idl.AppCheckResult;
import com.nercis.isscp.idl.AppStatus;
import com.nercis.isscp.idl.CheckResultStatus;
import com.nercis.isscp.idl.DynamicCheckResultData;
import com.nercis.isscp.idl.InvalidRequestException;
import com.nercis.isscp.idl.PlotsType;
import com.nercis.isscp.idl.Result;
import com.nercis.isscp.idl.StaticCheckResultData;
import com.nercis.isscp.idl.UnavailableException;
import com.nercis.isscp.idl.UserApp;
import com.nercis.isscp.idl.virus.VirusDetectionResultData;
import com.nercis.isscp.ts.NodeHeat;
import com.nercis.isscp.ts.TSOperate;
import com.nercis.isscp.util.ExportExcel;
import com.nercis.isscp.util.SingleRecordInfo;
import com.nercis.isscp.util.SingleRecordInfoQueue;

public class TSOperateImpl implements TSOperate.Iface {

    public TSOperateImpl() {
        }

    @Override
    public String genMissionId(String submitId) throws InvalidRequestException, UnavailableException, TException {
        return null;
    }

    @Override
    public Result submitMission(String missionId, List<UserApp> userApps, List<PlotsType> plots, String useRule) throws InvalidRequestException,
            UnavailableException, TException {
        return null;
    }

    @Override
    public AppCheckResult queryApp(String missionId, String userAppId) throws InvalidRequestException, UnavailableException, TException {
        return null;
    }

    @Override
    public List<AppCheckResult> queryMission(String missionId) throws InvalidRequestException, UnavailableException, TException {
        return null;
    }

    @Override
    public Result updateAppStatus(String missionId, String userAppId, AppStatus status, List<Map<String, APICheck>> usedPermissions,
            StaticCheckResultData stcRD, DynamicCheckResultData dycRD, VirusDetectionResultData virRD) throws InvalidRequestException,
            UnavailableException, TException {
        return null;
    }

    @Override
    public Result updateUserAppInfo(String missionId, String userAppId, Map<PlotsType, CheckResultStatus> plotsStatus,
            List<Map<String, APICheck>> usedPermissions, StaticCheckResultData stcRD, DynamicCheckResultData dycRD, VirusDetectionResultData virRD)
            throws InvalidRequestException, UnavailableException, TException {
        System.out.println(userAppId + plotsStatus.toString());
        return Result.success;
    }

    @Override
    public Result heart(NodeHeat nodeHeat, long timestamp) throws InvalidRequestException, UnavailableException, TException {
        return Result.success;
    }

    @Override
    public Result updateUserAppStatus(String missionId, String userAppId, Map<PlotsType, CheckResultStatus> plotsStatus,
            Map<String, CheckResultStatus> functionStatus) throws InvalidRequestException, UnavailableException, TException {
        System.out.println("missionID:"+missionId+",userappId:"+userAppId +",status:"+ plotsStatus.toString());
        return Result.success;
    }

}
