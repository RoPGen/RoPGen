package com.nercis.isscp.idl;

import org.apache.thrift.scheme.IScheme;
import org.apache.thrift.scheme.SchemeFactory;
import org.apache.thrift.scheme.StandardScheme;

import org.apache.thrift.scheme.TupleScheme;
import org.apache.thrift.protocol.TTupleProtocol;
import org.apache.thrift.protocol.TProtocolException;
import org.apache.thrift.EncodingUtils;
import org.apache.thrift.TException;
import org.apache.thrift.async.AsyncMethodCallback;
import org.apache.thrift.server.AbstractNonblockingServer.*;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import java.util.EnumMap;
import java.util.Set;
import java.util.HashSet;
import java.util.EnumSet;
import java.util.Collections;
import java.util.BitSet;
import java.nio.ByteBuffer;
import java.util.Arrays;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AppDetectResult implements org.apache.thrift.TBase<AppDetectResult, AppDetectResult._Fields>, java.io.Serializable, Cloneable, Comparable<AppDetectResult> {
  private static final org.apache.thrift.protocol.TStruct STRUCT_DESC = new org.apache.thrift.protocol.TStruct("AppDetectResult");

  private static final org.apache.thrift.protocol.TField MISSION_ID_FIELD_DESC = new org.apache.thrift.protocol.TField("missionId", org.apache.thrift.protocol.TType.STRING, (short)1);
  private static final org.apache.thrift.protocol.TField USER_APP_ID_FIELD_DESC = new org.apache.thrift.protocol.TField("userAppId", org.apache.thrift.protocol.TType.STRING, (short)2);
  private static final org.apache.thrift.protocol.TField USED_PERMISSIONS_FIELD_DESC = new org.apache.thrift.protocol.TField("usedPermissions", org.apache.thrift.protocol.TType.LIST, (short)3);
  private static final org.apache.thrift.protocol.TField PLOTS_STATUS_FIELD_DESC = new org.apache.thrift.protocol.TField("plotsStatus", org.apache.thrift.protocol.TType.MAP, (short)4);
  private static final org.apache.thrift.protocol.TField FUNCTION_STATUS_FIELD_DESC = new org.apache.thrift.protocol.TField("functionStatus", org.apache.thrift.protocol.TType.MAP, (short)5);
  private static final org.apache.thrift.protocol.TField DETECT_RESULT_FIELD_DESC = new org.apache.thrift.protocol.TField("detectResult", org.apache.thrift.protocol.TType.STRING, (short)6);

  private static final Map<Class<? extends IScheme>, SchemeFactory> schemes = new HashMap<Class<? extends IScheme>, SchemeFactory>();
  static {
    schemes.put(StandardScheme.class, new AppDetectResultStandardSchemeFactory());
    schemes.put(TupleScheme.class, new AppDetectResultTupleSchemeFactory());
  }

  public String missionId; public String userAppId; public List<Map<String,APICheck>> usedPermissions; public Map<PlotsType,CheckResultStatus> plotsStatus; public Map<String,CheckResultStatus> functionStatus; public ByteBuffer detectResult; public enum _Fields implements org.apache.thrift.TFieldIdEnum {
    MISSION_ID((short)1, "missionId"),
    USER_APP_ID((short)2, "userAppId"),
    USED_PERMISSIONS((short)3, "usedPermissions"),
    PLOTS_STATUS((short)4, "plotsStatus"),
    FUNCTION_STATUS((short)5, "functionStatus"),
    DETECT_RESULT((short)6, "detectResult");

    private static final Map<String, _Fields> byName = new HashMap<String, _Fields>();

    static {
      for (_Fields field : EnumSet.allOf(_Fields.class)) {
        byName.put(field.getFieldName(), field);
      }
    }

    public static _Fields findByThriftId(int fieldId) {
      switch(fieldId) {
        case 1: return MISSION_ID;
        case 2: return USER_APP_ID;
        case 3: return USED_PERMISSIONS;
        case 4: return PLOTS_STATUS;
        case 5: return FUNCTION_STATUS;
        case 6: return DETECT_RESULT;
        default:
          return null;
      }
    }

    public static _Fields findByThriftIdOrThrow(int fieldId) {
      _Fields fields = findByThriftId(fieldId);
      if (fields == null) throw new IllegalArgumentException("Field " + fieldId + " doesn't exist!");
      return fields;
    }

    public static _Fields findByName(String name) {
      return byName.get(name);
    }

    private final short _thriftId;
    private final String _fieldName;

    _Fields(short thriftId, String fieldName) {
      _thriftId = thriftId;
      _fieldName = fieldName;
    }

    public short getThriftFieldId() {
      return _thriftId;
    }

    public String getFieldName() {
      return _fieldName;
    }
  }

  private _Fields optionals[] = {_Fields.USED_PERMISSIONS,_Fields.FUNCTION_STATUS};
  public static final Map<_Fields, org.apache.thrift.meta_data.FieldMetaData> metaDataMap;
  static {
    Map<_Fields, org.apache.thrift.meta_data.FieldMetaData> tmpMap = new EnumMap<_Fields, org.apache.thrift.meta_data.FieldMetaData>(_Fields.class);
    tmpMap.put(_Fields.MISSION_ID, new org.apache.thrift.meta_data.FieldMetaData("missionId", org.apache.thrift.TFieldRequirementType.REQUIRED, 
        new org.apache.thrift.meta_data.FieldValueMetaData(org.apache.thrift.protocol.TType.STRING)));
    tmpMap.put(_Fields.USER_APP_ID, new org.apache.thrift.meta_data.FieldMetaData("userAppId", org.apache.thrift.TFieldRequirementType.REQUIRED, 
        new org.apache.thrift.meta_data.FieldValueMetaData(org.apache.thrift.protocol.TType.STRING)));
    tmpMap.put(_Fields.USED_PERMISSIONS, new org.apache.thrift.meta_data.FieldMetaData("usedPermissions", org.apache.thrift.TFieldRequirementType.OPTIONAL, 
        new org.apache.thrift.meta_data.ListMetaData(org.apache.thrift.protocol.TType.LIST, 
            new org.apache.thrift.meta_data.FieldValueMetaData(org.apache.thrift.protocol.TType.MAP            , "permissionResults"))));
    tmpMap.put(_Fields.PLOTS_STATUS, new org.apache.thrift.meta_data.FieldMetaData("plotsStatus", org.apache.thrift.TFieldRequirementType.REQUIRED, 
        new org.apache.thrift.meta_data.MapMetaData(org.apache.thrift.protocol.TType.MAP, 
            new org.apache.thrift.meta_data.EnumMetaData(org.apache.thrift.protocol.TType.ENUM, PlotsType.class), 
            new org.apache.thrift.meta_data.EnumMetaData(org.apache.thrift.protocol.TType.ENUM, CheckResultStatus.class))));
    tmpMap.put(_Fields.FUNCTION_STATUS, new org.apache.thrift.meta_data.FieldMetaData("functionStatus", org.apache.thrift.TFieldRequirementType.OPTIONAL, 
        new org.apache.thrift.meta_data.MapMetaData(org.apache.thrift.protocol.TType.MAP, 
            new org.apache.thrift.meta_data.FieldValueMetaData(org.apache.thrift.protocol.TType.STRING), 
            new org.apache.thrift.meta_data.EnumMetaData(org.apache.thrift.protocol.TType.ENUM, CheckResultStatus.class))));
    tmpMap.put(_Fields.DETECT_RESULT, new org.apache.thrift.meta_data.FieldMetaData("detectResult", org.apache.thrift.TFieldRequirementType.REQUIRED, 
        new org.apache.thrift.meta_data.FieldValueMetaData(org.apache.thrift.protocol.TType.STRING        , true)));
    metaDataMap = Collections.unmodifiableMap(tmpMap);
    org.apache.thrift.meta_data.FieldMetaData.addStructMetaDataMap(AppDetectResult.class, metaDataMap);
  }

  public AppDetectResult() {
  }

  public AppDetectResult(
    String missionId,
    String userAppId,
    Map<PlotsType,CheckResultStatus> plotsStatus,
    ByteBuffer detectResult)
  {
    this();
    this.missionId = missionId;
    this.userAppId = userAppId;
    this.plotsStatus = plotsStatus;
    this.detectResult = detectResult;
  }

  public AppDetectResult(AppDetectResult other) {
    if (other.isSetMissionId()) {
      this.missionId = other.missionId;
    }
    if (other.isSetUserAppId()) {
      this.userAppId = other.userAppId;
    }
    if (other.isSetUsedPermissions()) {
      List<Map<String,APICheck>> __this__usedPermissions = new ArrayList<Map<String,APICheck>>(other.usedPermissions.size());
      for (Map<String,APICheck> other_element : other.usedPermissions) {
        __this__usedPermissions.add(other_element);
      }
      this.usedPermissions = __this__usedPermissions;
    }
    if (other.isSetPlotsStatus()) {
      Map<PlotsType,CheckResultStatus> __this__plotsStatus = new HashMap<PlotsType,CheckResultStatus>(other.plotsStatus.size());
      for (Map.Entry<PlotsType, CheckResultStatus> other_element : other.plotsStatus.entrySet()) {

        PlotsType other_element_key = other_element.getKey();
        CheckResultStatus other_element_value = other_element.getValue();

        PlotsType __this__plotsStatus_copy_key = other_element_key;

        CheckResultStatus __this__plotsStatus_copy_value = other_element_value;

        __this__plotsStatus.put(__this__plotsStatus_copy_key, __this__plotsStatus_copy_value);
      }
      this.plotsStatus = __this__plotsStatus;
    }
    if (other.isSetFunctionStatus()) {
      Map<String,CheckResultStatus> __this__functionStatus = new HashMap<String,CheckResultStatus>(other.functionStatus.size());
      for (Map.Entry<String, CheckResultStatus> other_element : other.functionStatus.entrySet()) {

        String other_element_key = other_element.getKey();
        CheckResultStatus other_element_value = other_element.getValue();

        String __this__functionStatus_copy_key = other_element_key;

        CheckResultStatus __this__functionStatus_copy_value = other_element_value;

        __this__functionStatus.put(__this__functionStatus_copy_key, __this__functionStatus_copy_value);
      }
      this.functionStatus = __this__functionStatus;
    }
    if (other.isSetDetectResult()) {
      this.detectResult = org.apache.thrift.TBaseHelper.copyBinary(other.detectResult);
;
    }
  }

  public AppDetectResult deepCopy() {
    return new AppDetectResult(this);
  }

  @Override
  public void clear() {
    this.missionId = null;
    this.userAppId = null;
    this.usedPermissions = null;
    this.plotsStatus = null;
    this.functionStatus = null;
    this.detectResult = null;
  }

  public String getMissionId() {
    return this.missionId;
  }

  public AppDetectResult setMissionId(String missionId) {
    this.missionId = missionId;
    return this;
  }

  public void unsetMissionId() {
    this.missionId = null;
  }

  public boolean isSetMissionId() {
    return this.missionId != null;
  }

  public void setMissionIdIsSet(boolean value) {
    if (!value) {
      this.missionId = null;
    }
  }

  public String getUserAppId() {
    return this.userAppId;
  }

  public AppDetectResult setUserAppId(String userAppId) {
    this.userAppId = userAppId;
    return this;
  }

  public void unsetUserAppId() {
    this.userAppId = null;
  }

  public boolean isSetUserAppId() {
    return this.userAppId != null;
  }

  public void setUserAppIdIsSet(boolean value) {
    if (!value) {
      this.userAppId = null;
    }
  }

  public int getUsedPermissionsSize() {
    return (this.usedPermissions == null) ? 0 : this.usedPermissions.size();
  }

  public java.util.Iterator<Map<String,APICheck>> getUsedPermissionsIterator() {
    return (this.usedPermissions == null) ? null : this.usedPermissions.iterator();
  }

  public void addToUsedPermissions(Map<String,APICheck> elem) {
    if (this.usedPermissions == null) {
      this.usedPermissions = new ArrayList<Map<String,APICheck>>();
    }
    this.usedPermissions.add(elem);
  }

  public List<Map<String,APICheck>> getUsedPermissions() {
    return this.usedPermissions;
  }

  public AppDetectResult setUsedPermissions(List<Map<String,APICheck>> usedPermissions) {
    this.usedPermissions = usedPermissions;
    return this;
  }

  public void unsetUsedPermissions() {
    this.usedPermissions = null;
  }

  public boolean isSetUsedPermissions() {
    return this.usedPermissions != null;
  }

  public void setUsedPermissionsIsSet(boolean value) {
    if (!value) {
      this.usedPermissions = null;
    }
  }

  public int getPlotsStatusSize() {
    return (this.plotsStatus == null) ? 0 : this.plotsStatus.size();
  }

  public void putToPlotsStatus(PlotsType key, CheckResultStatus val) {
    if (this.plotsStatus == null) {
      this.plotsStatus = new HashMap<PlotsType,CheckResultStatus>();
    }
    this.plotsStatus.put(key, val);
  }

  public Map<PlotsType,CheckResultStatus> getPlotsStatus() {
    return this.plotsStatus;
  }

  public AppDetectResult setPlotsStatus(Map<PlotsType,CheckResultStatus> plotsStatus) {
    this.plotsStatus = plotsStatus;
    return this;
  }

  public void unsetPlotsStatus() {
    this.plotsStatus = null;
  }

  public boolean isSetPlotsStatus() {
    return this.plotsStatus != null;
  }

  public void setPlotsStatusIsSet(boolean value) {
    if (!value) {
      this.plotsStatus = null;
    }
  }

  public int getFunctionStatusSize() {
    return (this.functionStatus == null) ? 0 : this.functionStatus.size();
  }

  public void putToFunctionStatus(String key, CheckResultStatus val) {
    if (this.functionStatus == null) {
      this.functionStatus = new HashMap<String,CheckResultStatus>();
    }
    this.functionStatus.put(key, val);
  }

  public Map<String,CheckResultStatus> getFunctionStatus() {
    return this.functionStatus;
  }

  public AppDetectResult setFunctionStatus(Map<String,CheckResultStatus> functionStatus) {
    this.functionStatus = functionStatus;
    return this;
  }

  public void unsetFunctionStatus() {
    this.functionStatus = null;
  }

  public boolean isSetFunctionStatus() {
    return this.functionStatus != null;
  }

  public void setFunctionStatusIsSet(boolean value) {
    if (!value) {
      this.functionStatus = null;
    }
  }

  public byte[] getDetectResult() {
    setDetectResult(org.apache.thrift.TBaseHelper.rightSize(detectResult));
    return detectResult == null ? null : detectResult.array();
  }

  public ByteBuffer bufferForDetectResult() {
    return detectResult;
  }

  public AppDetectResult setDetectResult(byte[] detectResult) {
    setDetectResult(detectResult == null ? (ByteBuffer)null : ByteBuffer.wrap(detectResult));
    return this;
  }

  public AppDetectResult setDetectResult(ByteBuffer detectResult) {
    this.detectResult = detectResult;
    return this;
  }

  public void unsetDetectResult() {
    this.detectResult = null;
  }

  public boolean isSetDetectResult() {
    return this.detectResult != null;
  }

  public void setDetectResultIsSet(boolean value) {
    if (!value) {
      this.detectResult = null;
    }
  }

  public void setFieldValue(_Fields field, Object value) {
    switch (field) {
    case MISSION_ID:
      if (value == null) {
        unsetMissionId();
      } else {
        setMissionId((String)value);
      }
      break;

    case USER_APP_ID:
      if (value == null) {
        unsetUserAppId();
      } else {
        setUserAppId((String)value);
      }
      break;

    case USED_PERMISSIONS:
      if (value == null) {
        unsetUsedPermissions();
      } else {
        setUsedPermissions((List<Map<String,APICheck>>)value);
      }
      break;

    case PLOTS_STATUS:
      if (value == null) {
        unsetPlotsStatus();
      } else {
        setPlotsStatus((Map<PlotsType,CheckResultStatus>)value);
      }
      break;

    case FUNCTION_STATUS:
      if (value == null) {
        unsetFunctionStatus();
      } else {
        setFunctionStatus((Map<String,CheckResultStatus>)value);
      }
      break;

    case DETECT_RESULT:
      if (value == null) {
        unsetDetectResult();
      } else {
        setDetectResult((ByteBuffer)value);
      }
      break;

    }
  }

  public Object getFieldValue(_Fields field) {
    switch (field) {
    case MISSION_ID:
      return getMissionId();

    case USER_APP_ID:
      return getUserAppId();

    case USED_PERMISSIONS:
      return getUsedPermissions();

    case PLOTS_STATUS:
      return getPlotsStatus();

    case FUNCTION_STATUS:
      return getFunctionStatus();

    case DETECT_RESULT:
      return getDetectResult();

    }
    throw new IllegalStateException();
  }

  public boolean isSet(_Fields field) {
    if (field == null) {
      throw new IllegalArgumentException();
    }

    switch (field) {
    case MISSION_ID:
      return isSetMissionId();
    case USER_APP_ID:
      return isSetUserAppId();
    case USED_PERMISSIONS:
      return isSetUsedPermissions();
    case PLOTS_STATUS:
      return isSetPlotsStatus();
    case FUNCTION_STATUS:
      return isSetFunctionStatus();
    case DETECT_RESULT:
      return isSetDetectResult();
    }
    throw new IllegalStateException();
  }

  @Override
  public boolean equals(Object that) {
    if (that == null)
      return false;
    if (that instanceof AppDetectResult)
      return this.equals((AppDetectResult)that);
    return false;
  }

  public boolean equals(AppDetectResult that) {
    if (that == null)
      return false;

    boolean this_present_missionId = true && this.isSetMissionId();
    boolean that_present_missionId = true && that.isSetMissionId();
    if (this_present_missionId || that_present_missionId) {
      if (!(this_present_missionId && that_present_missionId))
        return false;
      if (!this.missionId.equals(that.missionId))
        return false;
    }

    boolean this_present_userAppId = true && this.isSetUserAppId();
    boolean that_present_userAppId = true && that.isSetUserAppId();
    if (this_present_userAppId || that_present_userAppId) {
      if (!(this_present_userAppId && that_present_userAppId))
        return false;
      if (!this.userAppId.equals(that.userAppId))
        return false;
    }

    boolean this_present_usedPermissions = true && this.isSetUsedPermissions();
    boolean that_present_usedPermissions = true && that.isSetUsedPermissions();
    if (this_present_usedPermissions || that_present_usedPermissions) {
      if (!(this_present_usedPermissions && that_present_usedPermissions))
        return false;
      if (!this.usedPermissions.equals(that.usedPermissions))
        return false;
    }

    boolean this_present_plotsStatus = true && this.isSetPlotsStatus();
    boolean that_present_plotsStatus = true && that.isSetPlotsStatus();
    if (this_present_plotsStatus || that_present_plotsStatus) {
      if (!(this_present_plotsStatus && that_present_plotsStatus))
        return false;
      if (!this.plotsStatus.equals(that.plotsStatus))
        return false;
    }

    boolean this_present_functionStatus = true && this.isSetFunctionStatus();
    boolean that_present_functionStatus = true && that.isSetFunctionStatus();
    if (this_present_functionStatus || that_present_functionStatus) {
      if (!(this_present_functionStatus && that_present_functionStatus))
        return false;
      if (!this.functionStatus.equals(that.functionStatus))
        return false;
    }

    boolean this_present_detectResult = true && this.isSetDetectResult();
    boolean that_present_detectResult = true && that.isSetDetectResult();
    if (this_present_detectResult || that_present_detectResult) {
      if (!(this_present_detectResult && that_present_detectResult))
        return false;
      if (!this.detectResult.equals(that.detectResult))
        return false;
    }

    return true;
  }

  @Override
  public int hashCode() {
    return 0;
  }

  @Override
  public int compareTo(AppDetectResult other) {
    if (!getClass().equals(other.getClass())) {
      return getClass().getName().compareTo(other.getClass().getName());
    }

    int lastComparison = 0;

    lastComparison = Boolean.valueOf(isSetMissionId()).compareTo(other.isSetMissionId());
    if (lastComparison != 0) {
      return lastComparison;
    }
    if (isSetMissionId()) {
      lastComparison = org.apache.thrift.TBaseHelper.compareTo(this.missionId, other.missionId);
      if (lastComparison != 0) {
        return lastComparison;
      }
    }
    lastComparison = Boolean.valueOf(isSetUserAppId()).compareTo(other.isSetUserAppId());
    if (lastComparison != 0) {
      return lastComparison;
    }
    if (isSetUserAppId()) {
      lastComparison = org.apache.thrift.TBaseHelper.compareTo(this.userAppId, other.userAppId);
      if (lastComparison != 0) {
        return lastComparison;
      }
    }
    lastComparison = Boolean.valueOf(isSetUsedPermissions()).compareTo(other.isSetUsedPermissions());
    if (lastComparison != 0) {
      return lastComparison;
    }
    if (isSetUsedPermissions()) {
      lastComparison = org.apache.thrift.TBaseHelper.compareTo(this.usedPermissions, other.usedPermissions);
      if (lastComparison != 0) {
        return lastComparison;
      }
    }
    lastComparison = Boolean.valueOf(isSetPlotsStatus()).compareTo(other.isSetPlotsStatus());
    if (lastComparison != 0) {
      return lastComparison;
    }
    if (isSetPlotsStatus()) {
      lastComparison = org.apache.thrift.TBaseHelper.compareTo(this.plotsStatus, other.plotsStatus);
      if (lastComparison != 0) {
        return lastComparison;
      }
    }
    lastComparison = Boolean.valueOf(isSetFunctionStatus()).compareTo(other.isSetFunctionStatus());
    if (lastComparison != 0) {
      return lastComparison;
    }
    if (isSetFunctionStatus()) {
      lastComparison = org.apache.thrift.TBaseHelper.compareTo(this.functionStatus, other.functionStatus);
      if (lastComparison != 0) {
        return lastComparison;
      }
    }
    lastComparison = Boolean.valueOf(isSetDetectResult()).compareTo(other.isSetDetectResult());
    if (lastComparison != 0) {
      return lastComparison;
    }
    if (isSetDetectResult()) {
      lastComparison = org.apache.thrift.TBaseHelper.compareTo(this.detectResult, other.detectResult);
      if (lastComparison != 0) {
        return lastComparison;
      }
    }
    return 0;
  }

  public _Fields fieldForId(int fieldId) {
    return _Fields.findByThriftId(fieldId);
  }

  public void read(org.apache.thrift.protocol.TProtocol iprot) throws org.apache.thrift.TException {
    schemes.get(iprot.getScheme()).getScheme().read(iprot, this);
  }

  public void write(org.apache.thrift.protocol.TProtocol oprot) throws org.apache.thrift.TException {
    schemes.get(oprot.getScheme()).getScheme().write(oprot, this);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder("AppDetectResult(");
    boolean first = true;

    sb.append("missionId:");
    if (this.missionId == null) {
      sb.append("null");
    } else {
      sb.append(this.missionId);
    }
    first = false;
    if (!first) sb.append(", ");
    sb.append("userAppId:");
    if (this.userAppId == null) {
      sb.append("null");
    } else {
      sb.append(this.userAppId);
    }
    first = false;
    if (isSetUsedPermissions()) {
      if (!first) sb.append(", ");
      sb.append("usedPermissions:");
      if (this.usedPermissions == null) {
        sb.append("null");
      } else {
        sb.append(this.usedPermissions);
      }
      first = false;
    }
    if (!first) sb.append(", ");
    sb.append("plotsStatus:");
    if (this.plotsStatus == null) {
      sb.append("null");
    } else {
      sb.append(this.plotsStatus);
    }
    first = false;
    if (isSetFunctionStatus()) {
      if (!first) sb.append(", ");
      sb.append("functionStatus:");
      if (this.functionStatus == null) {
        sb.append("null");
      } else {
        sb.append(this.functionStatus);
      }
      first = false;
    }
    if (!first) sb.append(", ");
    sb.append("detectResult:");
    if (this.detectResult == null) {
      sb.append("null");
    } else {
      org.apache.thrift.TBaseHelper.toString(this.detectResult, sb);
    }
    first = false;
    sb.append(")");
    return sb.toString();
  }

  public void validate() throws org.apache.thrift.TException {
    if (missionId == null) {
      throw new org.apache.thrift.protocol.TProtocolException("Required field 'missionId' was not present! Struct: " + toString());
    }
    if (userAppId == null) {
      throw new org.apache.thrift.protocol.TProtocolException("Required field 'userAppId' was not present! Struct: " + toString());
    }
    if (plotsStatus == null) {
      throw new org.apache.thrift.protocol.TProtocolException("Required field 'plotsStatus' was not present! Struct: " + toString());
    }
    if (detectResult == null) {
      throw new org.apache.thrift.protocol.TProtocolException("Required field 'detectResult' was not present! Struct: " + toString());
    }
    }

  private void writeObject(java.io.ObjectOutputStream out) throws java.io.IOException {
    try {
      write(new org.apache.thrift.protocol.TCompactProtocol(new org.apache.thrift.transport.TIOStreamTransport(out)));
    } catch (org.apache.thrift.TException te) {
      throw new java.io.IOException(te);
    }
  }

  private void readObject(java.io.ObjectInputStream in) throws java.io.IOException, ClassNotFoundException {
    try {
      read(new org.apache.thrift.protocol.TCompactProtocol(new org.apache.thrift.transport.TIOStreamTransport(in)));
    } catch (org.apache.thrift.TException te) {
      throw new java.io.IOException(te);
    }
  }

  private static class AppDetectResultStandardSchemeFactory implements SchemeFactory {
    public AppDetectResultStandardScheme getScheme() {
      return new AppDetectResultStandardScheme();
    }
  }

  private static class AppDetectResultStandardScheme extends StandardScheme<AppDetectResult> {

    public void read(org.apache.thrift.protocol.TProtocol iprot, AppDetectResult struct) throws org.apache.thrift.TException {
      org.apache.thrift.protocol.TField schemeField;
      iprot.readStructBegin();
      while (true)
      {
        schemeField = iprot.readFieldBegin();
        if (schemeField.type == org.apache.thrift.protocol.TType.STOP) { 
          break;
        }
        switch (schemeField.id) {
          case 1: if (schemeField.type == org.apache.thrift.protocol.TType.STRING) {
              struct.missionId = iprot.readString();
              struct.setMissionIdIsSet(true);
            } else { 
              org.apache.thrift.protocol.TProtocolUtil.skip(iprot, schemeField.type);
            }
            break;
          case 2: if (schemeField.type == org.apache.thrift.protocol.TType.STRING) {
              struct.userAppId = iprot.readString();
              struct.setUserAppIdIsSet(true);
            } else { 
              org.apache.thrift.protocol.TProtocolUtil.skip(iprot, schemeField.type);
            }
            break;
          case 3: if (schemeField.type == org.apache.thrift.protocol.TType.LIST) {
              {
                org.apache.thrift.protocol.TList _list124 = iprot.readListBegin();
                struct.usedPermissions = new ArrayList<Map<String,APICheck>>(_list124.size);
                for (int _i125 = 0; _i125 < _list124.size; ++_i125)
                {
                  Map<String,APICheck> _elem126;
                  {
                    org.apache.thrift.protocol.TMap _map127 = iprot.readMapBegin();
                    _elem126 = new HashMap<String,APICheck>(2*_map127.size);
                    for (int _i128 = 0; _i128 < _map127.size; ++_i128)
                    {
                      String _key129;
                      APICheck _val130;
                      _key129 = iprot.readString();
                      _val130 = new APICheck();
                      _val130.read(iprot);
                      _elem126.put(_key129, _val130);
                    }
                    iprot.readMapEnd();
                  }
                  struct.usedPermissions.add(_elem126);
                }
                iprot.readListEnd();
              }
              struct.setUsedPermissionsIsSet(true);
            } else { 
              org.apache.thrift.protocol.TProtocolUtil.skip(iprot, schemeField.type);
            }
            break;
          case 4: if (schemeField.type == org.apache.thrift.protocol.TType.MAP) {
              {
                org.apache.thrift.protocol.TMap _map131 = iprot.readMapBegin();
                struct.plotsStatus = new HashMap<PlotsType,CheckResultStatus>(2*_map131.size);
                for (int _i132 = 0; _i132 < _map131.size; ++_i132)
                {
                  PlotsType _key133;
                  CheckResultStatus _val134;
                  _key133 = PlotsType.findByValue(iprot.readI32());
                  _val134 = CheckResultStatus.findByValue(iprot.readI32());
                  struct.plotsStatus.put(_key133, _val134);
                }
                iprot.readMapEnd();
              }
              struct.setPlotsStatusIsSet(true);
            } else { 
              org.apache.thrift.protocol.TProtocolUtil.skip(iprot, schemeField.type);
            }
            break;
          case 5: if (schemeField.type == org.apache.thrift.protocol.TType.MAP) {
              {
                org.apache.thrift.protocol.TMap _map135 = iprot.readMapBegin();
                struct.functionStatus = new HashMap<String,CheckResultStatus>(2*_map135.size);
                for (int _i136 = 0; _i136 < _map135.size; ++_i136)
                {
                  String _key137;
                  CheckResultStatus _val138;
                  _key137 = iprot.readString();
                  _val138 = CheckResultStatus.findByValue(iprot.readI32());
                  struct.functionStatus.put(_key137, _val138);
                }
                iprot.readMapEnd();
              }
              struct.setFunctionStatusIsSet(true);
            } else { 
              org.apache.thrift.protocol.TProtocolUtil.skip(iprot, schemeField.type);
            }
            break;
          case 6: if (schemeField.type == org.apache.thrift.protocol.TType.STRING) {
              struct.detectResult = iprot.readBinary();
              struct.setDetectResultIsSet(true);
            } else { 
              org.apache.thrift.protocol.TProtocolUtil.skip(iprot, schemeField.type);
            }
            break;
          default:
            org.apache.thrift.protocol.TProtocolUtil.skip(iprot, schemeField.type);
        }
        iprot.readFieldEnd();
      }
      iprot.readStructEnd();

      struct.validate();
    }

    public void write(org.apache.thrift.protocol.TProtocol oprot, AppDetectResult struct) throws org.apache.thrift.TException {
      struct.validate();

      oprot.writeStructBegin(STRUCT_DESC);
      if (struct.missionId != null) {
        oprot.writeFieldBegin(MISSION_ID_FIELD_DESC);
        oprot.writeString(struct.missionId);
        oprot.writeFieldEnd();
      }
      if (struct.userAppId != null) {
        oprot.writeFieldBegin(USER_APP_ID_FIELD_DESC);
        oprot.writeString(struct.userAppId);
        oprot.writeFieldEnd();
      }
      if (struct.usedPermissions != null) {
        if (struct.isSetUsedPermissions()) {
          oprot.writeFieldBegin(USED_PERMISSIONS_FIELD_DESC);
          {
            oprot.writeListBegin(new org.apache.thrift.protocol.TList(org.apache.thrift.protocol.TType.MAP, struct.usedPermissions.size()));
            for (Map<String,APICheck> _iter139 : struct.usedPermissions)
            {
              {
                oprot.writeMapBegin(new org.apache.thrift.protocol.TMap(org.apache.thrift.protocol.TType.STRING, org.apache.thrift.protocol.TType.STRUCT, _iter139.size()));
                for (Map.Entry<String, APICheck> _iter140 : _iter139.entrySet())
                {
                  oprot.writeString(_iter140.getKey());
                  _iter140.getValue().write(oprot);
                }
                oprot.writeMapEnd();
              }
            }
            oprot.writeListEnd();
          }
          oprot.writeFieldEnd();
        }
      }
      if (struct.plotsStatus != null) {
        oprot.writeFieldBegin(PLOTS_STATUS_FIELD_DESC);
        {
          oprot.writeMapBegin(new org.apache.thrift.protocol.TMap(org.apache.thrift.protocol.TType.I32, org.apache.thrift.protocol.TType.I32, struct.plotsStatus.size()));
          for (Map.Entry<PlotsType, CheckResultStatus> _iter141 : struct.plotsStatus.entrySet())
          {
            oprot.writeI32(_iter141.getKey().getValue());
            oprot.writeI32(_iter141.getValue().getValue());
          }
          oprot.writeMapEnd();
        }
        oprot.writeFieldEnd();
      }
      if (struct.functionStatus != null) {
        if (struct.isSetFunctionStatus()) {
          oprot.writeFieldBegin(FUNCTION_STATUS_FIELD_DESC);
          {
            oprot.writeMapBegin(new org.apache.thrift.protocol.TMap(org.apache.thrift.protocol.TType.STRING, org.apache.thrift.protocol.TType.I32, struct.functionStatus.size()));
            for (Map.Entry<String, CheckResultStatus> _iter142 : struct.functionStatus.entrySet())
            {
              oprot.writeString(_iter142.getKey());
              oprot.writeI32(_iter142.getValue().getValue());
            }
            oprot.writeMapEnd();
          }
          oprot.writeFieldEnd();
        }
      }
      if (struct.detectResult != null) {
        oprot.writeFieldBegin(DETECT_RESULT_FIELD_DESC);
        oprot.writeBinary(struct.detectResult);
        oprot.writeFieldEnd();
      }
      oprot.writeFieldStop();
      oprot.writeStructEnd();
    }

  }

  private static class AppDetectResultTupleSchemeFactory implements SchemeFactory {
    public AppDetectResultTupleScheme getScheme() {
      return new AppDetectResultTupleScheme();
    }
  }

  private static class AppDetectResultTupleScheme extends TupleScheme<AppDetectResult> {

    @Override
    public void write(org.apache.thrift.protocol.TProtocol prot, AppDetectResult struct) throws org.apache.thrift.TException {
      TTupleProtocol oprot = (TTupleProtocol) prot;
      oprot.writeString(struct.missionId);
      oprot.writeString(struct.userAppId);
      {
        oprot.writeI32(struct.plotsStatus.size());
        for (Map.Entry<PlotsType, CheckResultStatus> _iter143 : struct.plotsStatus.entrySet())
        {
          oprot.writeI32(_iter143.getKey().getValue());
          oprot.writeI32(_iter143.getValue().getValue());
        }
      }
      oprot.writeBinary(struct.detectResult);
      BitSet optionals = new BitSet();
      if (struct.isSetUsedPermissions()) {
        optionals.set(0);
      }
      if (struct.isSetFunctionStatus()) {
        optionals.set(1);
      }
      oprot.writeBitSet(optionals, 2);
      if (struct.isSetUsedPermissions()) {
        {
          oprot.writeI32(struct.usedPermissions.size());
          for (Map<String,APICheck> _iter144 : struct.usedPermissions)
          {
            {
              oprot.writeI32(_iter144.size());
              for (Map.Entry<String, APICheck> _iter145 : _iter144.entrySet())
              {
                oprot.writeString(_iter145.getKey());
                _iter145.getValue().write(oprot);
              }
            }
          }
        }
      }
      if (struct.isSetFunctionStatus()) {
        {
          oprot.writeI32(struct.functionStatus.size());
          for (Map.Entry<String, CheckResultStatus> _iter146 : struct.functionStatus.entrySet())
          {
            oprot.writeString(_iter146.getKey());
            oprot.writeI32(_iter146.getValue().getValue());
          }
        }
      }
    }

    @Override
    public void read(org.apache.thrift.protocol.TProtocol prot, AppDetectResult struct) throws org.apache.thrift.TException {
      TTupleProtocol iprot = (TTupleProtocol) prot;
      struct.missionId = iprot.readString();
      struct.setMissionIdIsSet(true);
      struct.userAppId = iprot.readString();
      struct.setUserAppIdIsSet(true);
      {
        org.apache.thrift.protocol.TMap _map147 = new org.apache.thrift.protocol.TMap(org.apache.thrift.protocol.TType.I32, org.apache.thrift.protocol.TType.I32, iprot.readI32());
        struct.plotsStatus = new HashMap<PlotsType,CheckResultStatus>(2*_map147.size);
        for (int _i148 = 0; _i148 < _map147.size; ++_i148)
        {
          PlotsType _key149;
          CheckResultStatus _val150;
          _key149 = PlotsType.findByValue(iprot.readI32());
          _val150 = CheckResultStatus.findByValue(iprot.readI32());
          struct.plotsStatus.put(_key149, _val150);
        }
      }
      struct.setPlotsStatusIsSet(true);
      struct.detectResult = iprot.readBinary();
      struct.setDetectResultIsSet(true);
      BitSet incoming = iprot.readBitSet(2);
      if (incoming.get(0)) {
        {
          org.apache.thrift.protocol.TList _list151 = new org.apache.thrift.protocol.TList(org.apache.thrift.protocol.TType.MAP, iprot.readI32());
          struct.usedPermissions = new ArrayList<Map<String,APICheck>>(_list151.size);
          for (int _i152 = 0; _i152 < _list151.size; ++_i152)
          {
            Map<String,APICheck> _elem153;
            {
              org.apache.thrift.protocol.TMap _map154 = new org.apache.thrift.protocol.TMap(org.apache.thrift.protocol.TType.STRING, org.apache.thrift.protocol.TType.STRUCT, iprot.readI32());
              _elem153 = new HashMap<String,APICheck>(2*_map154.size);
              for (int _i155 = 0; _i155 < _map154.size; ++_i155)
              {
                String _key156;
                APICheck _val157;
                _key156 = iprot.readString();
                _val157 = new APICheck();
                _val157.read(iprot);
                _elem153.put(_key156, _val157);
              }
            }
            struct.usedPermissions.add(_elem153);
          }
        }
        struct.setUsedPermissionsIsSet(true);
      }
      if (incoming.get(1)) {
        {
          org.apache.thrift.protocol.TMap _map158 = new org.apache.thrift.protocol.TMap(org.apache.thrift.protocol.TType.STRING, org.apache.thrift.protocol.TType.I32, iprot.readI32());
          struct.functionStatus = new HashMap<String,CheckResultStatus>(2*_map158.size);
          for (int _i159 = 0; _i159 < _map158.size; ++_i159)
          {
            String _key160;
            CheckResultStatus _val161;
            _key160 = iprot.readString();
            _val161 = CheckResultStatus.findByValue(iprot.readI32());
            struct.functionStatus.put(_key160, _val161);
          }
        }
        struct.setFunctionStatusIsSet(true);
      }
    }
  }

}

