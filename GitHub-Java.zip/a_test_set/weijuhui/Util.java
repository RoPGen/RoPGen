package com.weparty.widgets.DateSlider.labeler;

import java.util.Calendar;

import com.weparty.widgets.DateSlider.TimeObject;

class Util {
    public static Calendar addYears(long time, int years) {
        return add(time, years, Calendar.YEAR);
    }

    public static Calendar addMonths(long time, int months) {
        return add(time, months, Calendar.MONTH);
    }

    public static Calendar addWeeks(long time, int days) {
        return add(time, days, Calendar.WEEK_OF_YEAR);
    }

    public static Calendar addDays(long time, int days) {
        return add(time, days, Calendar.DAY_OF_MONTH);
    }

    public static Calendar addHours(long time, int hours) {
        return add(time, hours, Calendar.HOUR_OF_DAY);
    }

    public static Calendar addMinutes(long time, int minutes) {
        return add(time, minutes, Calendar.MINUTE);
    }
    
    public static Calendar addMinutes(long time, int minutes, int minInterval) {
        return add(time, minutes*minInterval, Calendar.MINUTE);
    }

    public static TimeObject getYear(Calendar c, String formatString) {
        int year = c.get(Calendar.YEAR);
        c.set(year, 0, 1, 0, 0, 0);
        c.set(Calendar.MILLISECOND, 0);
        long startTime = c.getTimeInMillis();
        c.set(year, 11, 31, 23, 59, 59);
        c.set(Calendar.MILLISECOND, 999);
        long endTime = c.getTimeInMillis();
        return new TimeObject(String.format(formatString, c,c), startTime, endTime);
    }

    public static TimeObject getMonth(Calendar c, String formatString) {
        int year = c.get(Calendar.YEAR);
        int month = c.get(Calendar.MONTH);
        c.set(year, month, 1, 0, 0, 0);
        c.set(Calendar.MILLISECOND, 0);
        long startTime = c.getTimeInMillis();
        c.set(year, month, c.getActualMaximum(Calendar.DAY_OF_MONTH), 23, 59, 59);
        c.set(Calendar.MILLISECOND, 999);
        long endTime = c.getTimeInMillis();
        return new TimeObject(String.format(formatString,c,c), startTime, endTime);
    }

    public static TimeObject getDay(Calendar c, String formatString) {
        int year = c.get(Calendar.YEAR);
        int month = c.get(Calendar.MONTH);
        int day = c.get(Calendar.DAY_OF_MONTH);
        c.set(year, month, day, 0, 0, 0);
        c.set(Calendar.MILLISECOND, 0);
        long startTime = c.getTimeInMillis();
        c.set(year, month, day, 23, 59, 59);
        c.set(Calendar.MILLISECOND, 999);
        long endTime = c.getTimeInMillis();
        return new TimeObject(String.format(formatString,c,c), startTime, endTime);
    }

    public static TimeObject getHour(Calendar c, String formatString) {
        int year = c.get(Calendar.YEAR);
        int month = c.get(Calendar.MONTH);
        int day = c.get(Calendar.DAY_OF_MONTH);
        int hour = c.get(Calendar.HOUR_OF_DAY);
        c.set(year, month, day, hour, 0, 0);
        c.set(Calendar.MILLISECOND, 0);
        long startTime = c.getTimeInMillis();
        c.set(year, month, day, hour, 59, 59);
        c.set(Calendar.MILLISECOND, 999);
        long endTime = c.getTimeInMillis();
        return new TimeObject(String.format(formatString, c,c), startTime, endTime);
    }

    public static TimeObject getMinute(Calendar c, String formatString) {
        return getMinute(c, formatString, 1);
    }
    
    public static TimeObject getMinute(Calendar c, String formatString, int minInterval) {
        int year = c.get(Calendar.YEAR);
        int month = c.get(Calendar.MONTH);
        int day = c.get(Calendar.DAY_OF_MONTH);
        int hour = c.get(Calendar.HOUR_OF_DAY);
        int minute = c.get(Calendar.MINUTE);
        c.set(year, month, day, hour, Math.min(59,minute+minInterval-1), 59);
        c.set(Calendar.MILLISECOND, 999);
        long endTime = c.getTimeInMillis();
        c.set(year, month, day, hour, minute, 0);
        c.set(Calendar.MILLISECOND, 0);
        long startTime = c.getTimeInMillis();
        return new TimeObject(String.format(formatString, c,c), startTime, endTime);
    }

    public static TimeObject getTime(Calendar c, String formatString, int minuteInterval) {
        int year = c.get(Calendar.YEAR);
        int month = c.get(Calendar.MONTH);
        int day = c.get(Calendar.DAY_OF_MONTH);
        int hour = c.get(Calendar.HOUR_OF_DAY);
        int minute = c.get(Calendar.MINUTE)/minuteInterval*minuteInterval;
        c.set(year, month, day, hour, minute+minuteInterval-1, 59);
        c.set(Calendar.MILLISECOND, 999);
        long endTime = c.getTimeInMillis();
        c.set(year, month, day, hour, minute, 0);
        c.set(Calendar.MILLISECOND, 0);
        long startTime = c.getTimeInMillis();
        return new TimeObject(String.format(formatString, c,c), startTime, endTime);
    }

    private static Calendar add(long time, int val, int field) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(time);
        c.add(field, val);
        return c;
    }
}
