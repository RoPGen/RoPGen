package com.googlecode.javaewah;

public interface BitmapStorage {

    void addWord(final long newData);
    
    void addLiteralWord(final long newData);

    void addStreamOfLiteralWords(final Buffer buffer, final int start, final int number);

    void addStreamOfEmptyWords(final boolean v, final long number);

    void addStreamOfNegatedLiteralWords(final Buffer buffer, final int start, final int number);

    void clear();

    void setSizeInBitsWithinLastWord(final int size);
}
