package com.googlecode.javaewah32;

import java.util.Stack;


final class ReverseEWAHIterator32 {

    public ReverseEWAHIterator32(final Buffer32 buffer) {
        this.pointer = 0;
        this.rlw = new RunningLengthWord32(buffer, this.pointer);
        this.positions = new Stack<Integer>();
        this.positions.ensureCapacity(buffer.sizeInWords());
        while(this.pointer < buffer.sizeInWords()) {
            this.positions.push(this.pointer);
            this.rlw.position = this.pointer;
            this.pointer += this.rlw.getNumberOfLiteralWords() + 1;
        }
    }

    public Buffer32 buffer() {
        return this.rlw.buffer;
    }

    public int position() {
        return this.pointer;
    }

    public boolean hasPrevious() {
        return !this.positions.isEmpty();
    }

    public RunningLengthWord32 previous() {
        this.pointer = this.positions.pop();
        this.rlw.position = this.pointer;
        return this.rlw;
    }

    private Stack<Integer> positions;

    private int pointer;

    protected RunningLengthWord32 rlw;

}
