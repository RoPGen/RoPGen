package wyf.ytl.view;           import static wyf.ytl.tool.ConstantUtil.*;
import wyf.ytl.entity.CityDrawable;
import android.graphics.Bitmap;             import android.graphics.Canvas;             import android.graphics.Paint;              import android.view.MotionEvent;            import android.view.View;                   public class FoodAlert extends GameAlert{
     CityDrawable city;String alertMessage = "�ղ�xx���ؽ���������,˵�����Ѿ�������,�Ƿ񻮲�����?";
    
    
    public FoodAlert(GameView gameView,CityDrawable city,Bitmap bmpDialogBack,Bitmap bmpDialogButton){
        super(gameView,bmpDialogBack, bmpDialogButton);
        this.city = city;
    }
    @Override
    public void drawDialog(Canvas canvas) {
        canvas.drawBitmap(bmpDialogBack, 0, DIALOG_START_Y, null);alertMessage=alertMessage.replaceFirst("xx", city.getCityName());drawString(canvas, alertMessage);Paint paint = new Paint();paint.setTextSize(DIALOG_WORD_SIZE);paint.setAntiAlias(true);paint.setARGB(255, 42, 48, 103);canvas.drawBitmap(bmpDialogButton, DIALOG_BTN_START_X, DIALOG_BTN_START_Y, null);canvas.drawText("����", DIALOG_BTN_START_X+DIALOG_BTN_WORD_LEFT,
                DIALOG_BTN_START_Y+DIALOG_WORD_SIZE+DIALOG_BTN_WORD_UP,
                paint);
        canvas.drawBitmap(bmpDialogButton, DIALOG_BTN_START_X+DIALOG_BTN_SPAN, DIALOG_BTN_START_Y, null);
        canvas.drawText("����",DIALOG_BTN_START_X+DIALOG_BTN_SPAN+DIALOG_BTN_WORD_LEFT, 
                DIALOG_BTN_START_Y+DIALOG_WORD_SIZE+DIALOG_BTN_WORD_UP,
                paint);
    }
    public boolean onTouch(View v, MotionEvent event) {
        if(event.getAction() == MotionEvent.ACTION_DOWN){int x = (int)event.getX();int y = (int)event.getY();if(x>DIALOG_BTN_START_X && x<DIALOG_BTN_START_X+DIALOG_BTN_WIDTH
                    && y>DIALOG_BTN_START_Y && y<DIALOG_BTN_START_Y+DIALOG_BTN_HEIGHT){gameView.setStatus(97);gameView.setCurrentGameAlert(null);
                gameView.setOnTouchListener(gameView);
            }
            else if(x>DIALOG_BTN_START_X+DIALOG_BTN_SPAN && x<DIALOG_BTN_START_X+DIALOG_BTN_SPAN+DIALOG_BTN_WIDTH
                    && y>DIALOG_BTN_START_Y && y<DIALOG_BTN_START_Y+DIALOG_BTN_HEIGHT){gameView.setCurrentGameAlert(null);
                gameView.setStatus(0);gameView.setOnTouchListener(gameView);
            }
        }
        return true;
    }
    
}