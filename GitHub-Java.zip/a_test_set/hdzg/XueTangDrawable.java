package wyf.ytl.entity;

import static wyf.ytl.tool.ConstantUtil.DIALOG_BTN_HEIGHT;
import static wyf.ytl.tool.ConstantUtil.DIALOG_BTN_SPAN;
import static wyf.ytl.tool.ConstantUtil.DIALOG_BTN_START_X;
import static wyf.ytl.tool.ConstantUtil.DIALOG_BTN_START_Y;
import static wyf.ytl.tool.ConstantUtil.DIALOG_BTN_WIDTH;
import static wyf.ytl.tool.ConstantUtil.DIALOG_BTN_WORD_LEFT;
import static wyf.ytl.tool.ConstantUtil.DIALOG_BTN_WORD_UP;
import static wyf.ytl.tool.ConstantUtil.DIALOG_START_Y;
import static wyf.ytl.tool.ConstantUtil.DIALOG_WORD_SIZE;

import java.io.Serializable;


import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;

public class XueTangDrawable extends MyMeetableDrawable implements Serializable{
    String [] dialogMessage={
            "ǰ����һ��ѧ�ã��Ƿ��ý������ڴ�ѧϰһ����Ԥ�����Ľ�Ǯ1500��",
            "�������һ��ѧ�ã�������Ľ�Ǯ̫���ˣ������˲������ȥ��",
            "xx����ͨ����ѧ��ѧϰһ�������������yy�㡣",
            "xx������ѧ������һ�죬ʲôҲûѧ�ᡣ"
        };
    int cost = 1500;int status=-1;int intelligenceIncrement = 3;public XueTangDrawable(){}
    
    public XueTangDrawable(Bitmap bmpSelf,Bitmap bmpDialogBack,Bitmap bmpDialogButton,boolean meetable,int width,int height,int col,int row,
            int refCol,int refRow,int [][] noThrough,
            int [][] meetableMatrix) {
        super(bmpSelf, col, row, width, height, refCol, refRow, noThrough, meetable,
                meetableMatrix, bmpDialogBack, bmpDialogButton);
    }
    @Override
    public void drawDialog(Canvas canvas, Hero hero) {
        String showString = null;tempHero = hero;
        canvas.drawBitmap(bmpDialogBack, 0, DIALOG_START_Y, null);
        if(status == -1){
            if(tempHero.getTotalMoney() < cost){status = 1;
            }
            else{status = 0;
            }           
        }
        showString = dialogMessage[status];drawString(canvas, showString);
        canvas.drawBitmap(bmpDialogButton, DIALOG_BTN_START_X, DIALOG_BTN_START_Y, null);       
        Paint paint = new Paint();
        paint.setARGB(255, 42, 48, 103);
        paint.setAntiAlias(true);
        paint.setTypeface(Typeface.create((Typeface)null,Typeface.ITALIC));
        paint.setTextSize(18);
        canvas.drawText("ȷ��",
                DIALOG_BTN_START_X+DIALOG_BTN_WORD_LEFT,
                DIALOG_BTN_START_Y+DIALOG_WORD_SIZE+DIALOG_BTN_WORD_UP,
                paint
                );
        if(status == 0){canvas.drawBitmap(bmpDialogButton, DIALOG_BTN_START_X+DIALOG_BTN_SPAN, DIALOG_BTN_START_Y, null);
            canvas.drawText("ȡ��", 
                    DIALOG_BTN_START_X+DIALOG_BTN_SPAN+DIALOG_BTN_WORD_LEFT, 
                    DIALOG_BTN_START_Y+DIALOG_WORD_SIZE+DIALOG_BTN_WORD_UP,
                    paint
                    );
        }       
    }
    @Override
    public boolean onTouch(View v, MotionEvent event) {
        int x = (int)event.getX();
        int y = (int)event.getY();
        if(event.getAction() == MotionEvent.ACTION_DOWN){
            if(x>DIALOG_BTN_START_X && x<DIALOG_BTN_START_X+DIALOG_BTN_WIDTH
                    && y>DIALOG_BTN_START_Y && y<DIALOG_BTN_START_Y+DIALOG_BTN_HEIGHT){switch(status){
                case 0:tempHero.setTotalMoney(tempHero.getTotalMoney() - cost);upgradeGeneralAgility();break;
                case 1:case 2:case 3:recoverGame();
                    break;
                }               
            }
            else if(x>DIALOG_BTN_START_X+DIALOG_BTN_SPAN && x<DIALOG_BTN_START_X+DIALOG_BTN_SPAN+DIALOG_BTN_WIDTH
                    && y>DIALOG_BTN_START_Y && y<DIALOG_BTN_START_Y+DIALOG_BTN_HEIGHT){recoverGame();
            }           
        }
        return true;
    }
    public void upgradeGeneralAgility(){
        int size = tempHero.generalList.size();
        int r = (int)(Math.random()*100)%size;General g = tempHero.generalList.get(r);        
        int increment = (int)(Math.random()*(intelligenceIncrement+1));if(increment == 0){status = 3;
            dialogMessage[3] = dialogMessage[3].replaceFirst("xx", g.getName());}
        else{status = 2;
            g.setIntelligence(g.getIntelligence()+increment);dialogMessage[2] = dialogMessage[2].replaceFirst("xx", g.getName());dialogMessage[2] = dialogMessage[2].replaceFirst("yy", increment+"");}

    }
    public void recoverGame(){
        tempHero.father.setOnTouchListener(tempHero.father);tempHero.father.setCurrentDrawable(null);tempHero.father.setStatus(0);tempHero.father.gvt.setChanging(true);status = -1;}
}