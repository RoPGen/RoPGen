package JDK.Collection;

import model.User;
import org.junit.Test;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class CollectionTest {

    @Test
    public void testDeepCopy() {
        List<User> list1 = new ArrayList<>();
        User       user1 = new User("111", "AAA");
        User       user2 = new User("222", "BBB");
        User       user3 = new User("333", "CCC");
        list1.add(user1);
        list1.add(user2);
        list1.add(user3);
        System.out.println("list:" + list1);
        user1.setUserId("444");
        System.out.println("list" + list1);

        Set<User> set = new HashSet<>(list1);
        System.out.println("Set:" + set);

        System.out.println("==============");
        user2.setUserId("5555");
        list1.add(new User("666", "EEE"));
        System.out.println("list" + list1);
        System.out.println("Set:" + set);


    }
}
