package info.monitorenter.io;

import java.io.IOException;
import java.io.OutputStream;
import java.util.LinkedList;
import java.util.List;

public class MultiplexingOutputStream extends OutputStream {
  private List<OutputStream> m_delegates;

  public MultiplexingOutputStream(final OutputStream streamOne, final OutputStream streamTwo) {
    this.m_delegates = new LinkedList<OutputStream>();
    this.m_delegates.add(streamOne);
    this.m_delegates.add(streamTwo);
  }

  public void addOutputStream(final OutputStream delegate) {
    this.m_delegates.add(delegate);
  }

  public boolean removeOutputStream(final OutputStream delegate) {
    boolean result = this.m_delegates.remove(delegate);
    return result;
  }

  @Override
  public void write(int b) throws IOException {
    for (OutputStream delegate : this.m_delegates) {
      delegate.write(b);
    }
  }
}
