package info.monitorenter.cpdetector.util.collections.ui;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;

import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

public class TableRendererHTML extends StreamTableRenderer{
 
  public TableRendererHTML(Writer out){
    super(out);
  }
  protected String CellStartTag(boolean rowstart) {
    return "<TD>";
  }
  protected String CellStopTag(boolean rowend) {
    return "</TD>";
  }
  protected String HeadCellStartTag(boolean firstOrLast) {
    return "<TH>";
  }
  protected String HeadCellStopTag(boolean firstOrLast) {
    return "</TH>";
  }
  protected String HeadRowStartTag() {
    return "<TR>";
  }
  protected String HeadRowStopTag() {
    return "</TR>";
  }
  protected String RowStartTag() {
    return "<TR>";
  }
  protected String RowStopTag() {
    return "</TR>";
  }
  protected String TableStartTag() {
    return "<TABLE>";
  }
  protected String TableStopTag() {
    return "</TABLE>";
  }
  
  public static void main(String[]args)throws Throwable{
    TableModel model = new DefaultTableModel(new String[]{"One","Two","Three"},10);
    Writer out = new OutputStreamWriter(new FileOutputStream(new File("test.html")));
    for(int rows=0;rows<10;rows++){
      for(int cols = 0;cols<3;cols++){
        model.setValueAt("Test("+rows+","+cols+")",rows,cols);
      }
    }
    new TableRendererHTML(out).render(model);
    out.close();
    
  }
}
