package com.opslab.util.ftp;


import org.apache.commons.net.ftp.FTPClient;

import java.io.File;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public interface FTPUtil {
    public boolean isExists(String fileName);

    public boolean downLoad(String fileName);

    public boolean downLoadDir(String directory);

    public boolean deleteFile(String fileName);

    public boolean deleteDir(String directory);

    public boolean putFile(String fileName, String remoteFileName, boolean isDelete);

    public boolean putFile(File file, String remoteFileName, boolean isDelete);

    public boolean putDir(String fileName, String remoteDir);

    public boolean putDir(File file, String remoteDir);

    public boolean mkDir(String destory);


    public List<String> listFile(String directory);

    public LinkedList<String> listDir(String direcotyr);

    public Map<String,FileAttr> listFileAttr(String directory);

    public boolean changeWorkDir(String directory);

    public String getWorkDir();

    public boolean changName(String oldName, String newName);

    public FTPClient client();

    public void destory();
}
