package com.opslab.util;

import com.sun.management.OperatingSystemMXBean;

import java.lang.management.ManagementFactory;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InterfaceAddress;
import java.net.NetworkInterface;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;

public class SysUtil {

    public static final String JVM_VERSION     = PropertiesUtil.key("java.version");
    public static final String JVM_ENCODING    = PropertiesUtil.key("file.encoding");
    public static final String JVM_TEMPDIR     = PropertiesUtil.key("java.io.tmpdir");
    public static final String HTTP_PROXY_HOST = "http.proxyHost";
    public static final String HTTP_PROXY_PORT = "http.proxyPort";
    ;
    public static final String HTTP_PROXY_USER = "http.proxyUser";
    ;
    public static final String HTTP_PROXY_PASSWORD = "http.proxyPassword";
    public static String HOST_IP;
    public static String HOST_NAME;
    public static String OS_ARCH           = PropertiesUtil.key("os.arch");
    public static String OS_NAME           = PropertiesUtil.key("os.name");
    public static String OS_VERSION        = PropertiesUtil.key("os.version");
    public static String SUN_DESKTOP       = PropertiesUtil.key("sun.desktop");
    public static String CURRENT_USER      = PropertiesUtil.key("user.name");
    public static String CURRENT_USER_HOME = PropertiesUtil.key("user.home");
    public static String CURRENT_USER_DIR  = PropertiesUtil.key("user.dir");
    public static String FILE_SEPARATOR    = PropertiesUtil.key("file.separator");
    public static String PATH_SEPARATOR    = PropertiesUtil.key("path.separator");
    public static String LINE_SEPARATOR    = PropertiesUtil.key("line.separator");
    public static  long                  TotalMemorySize;
    private static OperatingSystemMXBean osmxb;
    private static int kb = 1024;

    static {

        try {

            InetAddress addr = InetAddress.getLocalHost();
            HOST_NAME = addr.getHostName();
            Enumeration<NetworkInterface> nets = NetworkInterface.getNetworkInterfaces();
            for (NetworkInterface netint : Collections.list(nets)) {
                if (null != netint.getHardwareAddress()) {
                    List<InterfaceAddress> list = netint.getInterfaceAddresses();
                    for (InterfaceAddress interfaceAddress : list) {
                        InetAddress ip = interfaceAddress.getAddress();
                        if (ip instanceof Inet4Address) {
                            HOST_IP += interfaceAddress.getAddress().toString();
                        }
                    }
                }
            }
            HOST_IP = HOST_IP.replaceAll("null", "");
        } catch (Exception e) {
            System.out.println("获取服务器IP出错");
        }

        try {
            osmxb = (OperatingSystemMXBean) ManagementFactory.getOperatingSystemMXBean();

            TotalMemorySize = osmxb.getTotalPhysicalMemorySize() / kb;
        } catch (Exception e) {
            System.out.println("获取系统信息失败");
            e.printStackTrace();
        }


    }


    public final static long usedMemory() {
        if (valid.valid(osmxb)) {
            return (osmxb.getTotalPhysicalMemorySize() - osmxb.getFreePhysicalMemorySize()) / kb;
        }
        return 0;
    }

    public final static long JVMtotalMem() {
        return Runtime.getRuntime().totalMemory() / kb;
    }

    public final static long JVMfreeMem() {
        return Runtime.getRuntime().freeMemory() / kb;
    }

    public final static long JVMmaxMem() {
        return Runtime.getRuntime().maxMemory() / kb;
    }

    public final static void setHttpProxy(String host, String port, String username, String password) {
        System.getProperties().put(HTTP_PROXY_HOST, host);
        System.getProperties().put(HTTP_PROXY_PORT, port);
        System.getProperties().put(HTTP_PROXY_USER, username);
        System.getProperties().put(HTTP_PROXY_PASSWORD, password);
    }

    public final static void setHttpProxy(String host, String port) {
        System.getProperties().put(HTTP_PROXY_HOST, host);
        System.getProperties().put(HTTP_PROXY_PORT, port);
    }

}
