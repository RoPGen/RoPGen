package com.opslab.util.image;

import java.awt.*;
import java.awt.image.BufferedImage;

public final class ImageUtil {

    public static BufferedImage imageResize(BufferedImage originalImage, Integer width,Integer height){
        if(width <= 0){
            width =1;
        }
        if(height <= 0){
            height =1;
        }
        BufferedImage newImage = new BufferedImage(width,height,originalImage.getType());
        Graphics g = newImage.getGraphics();
        g.drawImage(originalImage,0,0,width,height,null);
        g.dispose();
        return newImage;
    }

    public static BufferedImage imageMagnifyRatio(BufferedImage originalImage, Integer withdRatio,Integer heightRatio){
        if(withdRatio <= 0){
            withdRatio =1;
        }
        if(heightRatio <= 0){
            heightRatio =1;
        }
        int width = originalImage.getWidth()*withdRatio;
        int height = originalImage.getHeight()*heightRatio;
        BufferedImage newImage = new BufferedImage(width,height,originalImage.getType());
        Graphics g = newImage.getGraphics();
        g.drawImage(originalImage,0,0,width,height,null);
        g.dispose();
        return newImage;
    }
    public static BufferedImage imageShrinkRatio(BufferedImage originalImage, Integer withdRatio,Integer heightRatio){
        if(withdRatio <= 0){
            withdRatio =1;
        }
        if(heightRatio <= 0){
            heightRatio =1;
        }
        int width = originalImage.getWidth()/withdRatio;
        int height = originalImage.getHeight()/heightRatio;
        BufferedImage newImage = new BufferedImage(width,height,originalImage.getType());
        Graphics g = newImage.getGraphics();
        g.drawImage(originalImage,0,0,width,height,null);
        g.dispose();
        return newImage;
    }
}
