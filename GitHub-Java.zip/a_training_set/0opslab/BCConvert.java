package com.opslab.util.algorithmImpl;

import com.opslab.util.StringUtil;

public class BCConvert {

    static final char DBC_CHAR_START = 33; static final char DBC_CHAR_END = 126; static final char SBC_CHAR_START = 65281; static final char SBC_CHAR_END = 65374; static final int CONVERT_STEP = 65248; static final char SBC_SPACE = 12288; static final char DBC_SPACE = ' '; public static String bj2qj(String src) {
        if(StringUtil.isEmpty(src)){
            return "";
        }
        StringBuilder buf = new StringBuilder(src.length());
        char[] ca = src.toCharArray();
        for (char t:ca) {
            if (t == DBC_SPACE) {
                buf.append(SBC_SPACE);
            } else if ((t >= DBC_CHAR_START) && (t <= DBC_CHAR_END)) {
                buf.append((char) (t + CONVERT_STEP));
            } else {
                buf.append(t);
            }
        }
        return buf.toString();
    }

    public static String qj2bj(String src) {
        if(StringUtil.isEmpty(src)){
            return "";
        }
        StringBuilder buf = new StringBuilder(src.length());
        char[] ca = src.toCharArray();
        for (int i = 0; i < src.length(); i++) {
            if (ca[i] >= SBC_CHAR_START && ca[i] <= SBC_CHAR_END) {
                buf.append((char) (ca[i] - CONVERT_STEP));
            } else if (ca[i] == SBC_SPACE) {
                buf.append(DBC_SPACE);
            } else {
                buf.append(ca[i]);
            }
        }
        return buf.toString();
    }

}