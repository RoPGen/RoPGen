package info.monitorenter.cpdetector.io;

import info.monitorenter.cpdetector.io.parser.EncodingLexer;
import info.monitorenter.cpdetector.io.parser.EncodingParser;
import info.monitorenter.io.LimitedInputStream;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.nio.charset.UnsupportedCharsetException;

import antlr.ANTLRException;

public class ParsingDetector
    extends AbstractCodepageDetector {
  private static final long serialVersionUID = 3618977875919778866L;

  private boolean m_verbose = false;

  public ParsingDetector() {
    this(false);
  }

  public ParsingDetector(boolean verbose) {
    super();
    this.m_verbose = verbose;
  }

  public Charset detectCodepage(final InputStream in, final int length) throws IOException {
    EncodingLexer lexer;
    EncodingParser parser;
    Charset charset = null;
    String csName = null;
    InputStream limitedInputStream = new LimitedInputStream(in, length);
    if (this.m_verbose) {
      System.out
          .println("  parsing for html-charset/xml-encoding attribute with codepage: US-ASCII");
    }
    try {
      lexer = new EncodingLexer(new InputStreamReader(limitedInputStream, "US-ASCII"));
      parser = new EncodingParser(lexer);
      csName = parser.htmlDocument();
      if (csName != null) {
        try {
          charset = Charset.forName(csName);
        } catch (UnsupportedCharsetException uce) {
          charset = UnsupportedCharset.forName(csName);
        }
      } else {
        charset = UnknownCharset.getInstance();
      }
    } catch (ANTLRException ae) {
      if (this.m_verbose) {
        System.out.println("  ANTLR parser exception: " + ae.getMessage());
      }
    } catch (Exception deepdown) {
      if (this.m_verbose) {
        System.out.println("  Decoding Exception: " + deepdown.getMessage()
            + " (unsupported java charset).");
      }
      if (charset == null) {
        if (csName != null) {
          charset = UnsupportedCharset.forName(csName);
        } else {
          charset = UnknownCharset.getInstance();
        }
      }
    }
    return charset;
  }

}
