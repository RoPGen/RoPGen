package com.opslab.util;


import java.io.*;
import java.util.Enumeration;
import java.util.Properties;

public final class PropertiesUtil {

    public final static String key(String key) {
        return System.getProperty(key);
    }

    public final static String GetValueByKey(String filePath, String key) {
        Properties pps = new Properties();
        try (InputStream in = new BufferedInputStream(new FileInputStream(filePath))) {
            pps.load(in);
            return pps.getProperty(key);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public final static String GetAllProperties(String filePath) throws IOException {
        Properties pps = new Properties();
        String     str = "";
        try (InputStream in = new BufferedInputStream(new FileInputStream(filePath))) {
            pps.load(in);
            Enumeration en = pps.propertyNames();
            while (en.hasMoreElements()) {
                String strKey = (String) en.nextElement();
                String strValue = pps.getProperty(strKey);
                str += strKey + ":" + strValue + "<>";
            }
        }
        return str.substring(0, str.lastIndexOf("<>"));
    }

    public final static void WriteProperties(String filePath, String pKey, String pValue) throws IOException {
        Properties props = new Properties();

        props.load(new FileInputStream(filePath));
        OutputStream fos = new FileOutputStream(filePath);
        props.setProperty(pKey, pValue);
        props.store(fos, "Update '" + pKey + "' value");

    }

}
