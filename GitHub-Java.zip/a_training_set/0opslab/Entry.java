package info.monitorenter.util;

public final class Entry<V, K> implements java.util.Map.Entry<V, K> {

  private final V m_key;

  private K m_value;

  public Entry(final V key, final K value) {
    this.m_key = key;
    this.m_value = value;
  }

  @SuppressWarnings("unchecked")
  @Override
  public boolean equals(final Object obj) {
    if (this == obj) {
      return true;
    }
    if (obj == null) {
      return false;
    }
    if (this.getClass() != obj.getClass()) {
      return false;
    }
    final Entry<V,K> other = (Entry<V,K>) obj;
    if (this.m_key == null) {
      if (other.m_key != null) {
        return false;
      }
    } else if (!this.m_key.equals(other.m_key)) {
      return false;
    }
    if (this.m_value == null) {
      if (other.m_value != null) {
        return false;
      }
    } else if (!this.m_value.equals(other.m_value)) {
      return false;
    }
    return true;
  }

  public V getKey() {
    return this.m_key;
  }

  public K getValue() {
    return this.m_value;
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((this.m_key == null) ? 0 : this.m_key.hashCode());
    result = prime * result + ((this.m_value == null) ? 0 : this.m_value.hashCode());
    return result;
  }

  public K setValue(final K value) {
    final K ret = this.m_value;
    this.m_value = value;
    return ret;
  }

}
