package com.opslab.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Map;

@SuppressWarnings("rawtypes")
public final class valid {

    public final static boolean isDate(String date,String format){
        try {
            SimpleDateFormat sdf = new SimpleDateFormat(format);
            sdf.parse(date);
            return true;
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return false;
    }

    public final static boolean valid(String src) {
        return !(src == null || "".equals(src.trim()));
    }

    public final static boolean valid(String... src) {
        for (String s : src) {
            if (!valid(s)) {
                return false;
            }
        }
        return true;
    }


    public final static boolean valid(Object obj) {
        return !(null == obj);
    }

    public final static boolean valid(Object... objs) {
        if (objs != null && objs.length != 0) {
            return true;
        }
        return false;
    }

    public final static boolean valid(Collection col) {
        return !(col == null || col.isEmpty());
    }

    public final static boolean valid(Collection... cols) {
        for (Collection c : cols) {
            if (!valid(c)) {
                return false;
            }
        }
        return true;
    }

    public final static boolean valid(Map map) {
        return !(map == null || map.isEmpty());
    }

    public final static boolean valid(Map... maps) {
        for (Map m : maps) {
            if (!valid(m)) {
                return false;
            }
        }
        return true;
    }
}
