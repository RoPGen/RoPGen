package com.opslab.util;

import java.math.BigInteger;
import java.security.MessageDigest;

public final class Password {

    private static final String SEC_PASSWORD =
            "^(?=.*?[0-9])(?=.*?[a-z])(?=.*?[A-Z])(?=.*?[@!#$%^&*()_+\\.\\-\\?<>'\"|=]+).{8,15}$";
    public final static String md5(String password){
        MessageDigest md;
        try {
            md = MessageDigest.getInstance("MD5");
            md.update(password.getBytes());
            String pwd = new BigInteger(1, md.digest()).toString(16);
            return pwd;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return password;
    }

    public final static  boolean isSec(String password){
        return RegUtil.isMatche(password,SEC_PASSWORD);
    }
}
