package info.monitorenter.cpdetector.io;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.Serializable;
import java.net.URL;
import java.nio.charset.Charset;

public interface ICodepageDetector extends Serializable, Comparable {
  public Reader open(URL url) throws IOException;

  public Charset detectCodepage(URL url) throws IOException;

  public Charset detectCodepage(InputStream in, int length) throws IOException;
}
