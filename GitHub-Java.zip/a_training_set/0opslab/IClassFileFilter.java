package info.monitorenter.cpdetector.io;

import java.io.FileFilter;

public interface IClassFileFilter extends FileFilter {
  public boolean accept(Class c);
}
