package com.opslab.util;


import java.util.Random;
import java.util.UUID;

public final class RandomUtil {
    public static final String ALLCHAR    = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    public static final String LETTERCHAR = "abcdefghijkllmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    public static final String NUMBERCHAR = "0123456789";


    public final static int integer(int scopeMin,int scoeMax){
        Random random = new Random();
        return (random.nextInt(scoeMax)%(scoeMax-scopeMin+1) + scopeMin);
    }
    public final static String number(int length) {
        StringBuffer sb     = new StringBuffer();
        Random       random = new Random();
        for (int i = 0; i < length; i++) {
            sb.append(NUMBERCHAR.charAt(random.nextInt(NUMBERCHAR.length())));
        }
        return sb.toString();
    }

    public final static String String(int length) {
        StringBuffer sb     = new StringBuffer();
        Random       random = new Random();
        for (int i = 0; i < length; i++) {
            sb.append(ALLCHAR.charAt(random.nextInt(ALLCHAR.length())));
        }
        return sb.toString();
    }

    public final static String MixString(int length) {
        StringBuffer sb     = new StringBuffer();
        Random       random = new Random();
        for (int i = 0; i < length; i++) {
            sb.append(ALLCHAR.charAt(random.nextInt(LETTERCHAR.length())));
        }
        return sb.toString();
    }

    public final static String LowerString(int length) {
        return MixString(length).toLowerCase();
    }

    public final static String UpperString(int length) {
        return MixString(length).toUpperCase();
    }

    public final static String ZeroString(int length) {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < length; i++) {
            sb.append('0');
        }
        return sb.toString();
    }

    public final static String toFixdLengthString(long num, int fixdlenth) {
        StringBuffer sb     = new StringBuffer();
        String       strNum = String.valueOf(num);
        if (fixdlenth - strNum.length() >= 0) {
            sb.append(ZeroString(fixdlenth - strNum.length()));
        } else {
            throw new RuntimeException("将数字" + num + "转化为长度为" + fixdlenth + "的字符串发生异常！");
        }
        sb.append(strNum);
        return sb.toString();
    }

    public final static String toFixdLengthString(int num, int fixdlenth) {
        StringBuffer sb     = new StringBuffer();
        String       strNum = String.valueOf(num);
        if (fixdlenth - strNum.length() >= 0) {
            sb.append(ZeroString(fixdlenth - strNum.length()));
        } else {
            throw new RuntimeException("将数字" + num + "转化为长度为" + fixdlenth + "的字符串发生异常！");
        }
        sb.append(strNum);
        return sb.toString();
    }

    public final static int getNotSimple(int[] param, int len) {
        Random rand = new Random();
        for (int i = param.length; i > 1; i--) {
            int index = rand.nextInt(i);
            int tmp = param[index];
            param[index] = param[i - 1];
            param[i - 1] = tmp;
        }
        int result = 0;
        for (int i = 0; i < len; i++) {
            result = result * 10 + param[i];
        }
        return result;
    }

    public final static Object randomItem(Object[] param) {
        int index = integer(0,param.length);
        return param[index];
    }

    public final static String uuid(){
        UUID uuid = UUID.randomUUID();
        String s = uuid.toString();
        return s.substring(0,8)+s.substring(9,13)+s.substring(14,18)+s.substring(19,23)+s.substring(24);
    }
    public final static String UUID(){
        UUID uuid = UUID.randomUUID();
        String s = uuid.toString();
        String temp =s.substring(0,8)+s.substring(9,13)+s.substring(14,18)+s.substring(19,23)+s.substring(24);
        return temp.toUpperCase();
    }
}
