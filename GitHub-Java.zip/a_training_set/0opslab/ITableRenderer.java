package info.monitorenter.cpdetector.util.collections.ui;

import javax.swing.table.TableModel;

public interface ITableRenderer {
  public void render(TableModel model)throws Exception;
}
