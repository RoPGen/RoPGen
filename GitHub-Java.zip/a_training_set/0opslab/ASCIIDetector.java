package info.monitorenter.cpdetector.io;

import info.monitorenter.util.FileUtil;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;


public final class ASCIIDetector
    extends AbstractCodepageDetector {
  private static final long serialVersionUID = 3760841259903824181L;

  private static ICodepageDetector instance;

  private ASCIIDetector() {
    super();
    }

  public static ICodepageDetector getInstance() {
    if (instance == null) {
      instance = new ASCIIDetector();
    }
    return instance;
  }

  public Charset detectCodepage(final InputStream in, final int length) throws IOException {
    Charset ret = UnknownCharset.getInstance();
    InputStream localin;
    if (!(in instanceof BufferedInputStream)) {
      localin = new BufferedInputStream(in, 4096);
    } else {
      localin = in;
    }
    if (FileUtil.isAllASCII(localin)) {
      ret = Charset.forName("US-ASCII");
    }
    return ret;

  }

}
