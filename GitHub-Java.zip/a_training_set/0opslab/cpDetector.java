package com.opslab.util.algorithmImpl;

import info.monitorenter.cpdetector.io.*;

public class cpDetector {
    public static CodepageDetectorProxy codepageDetector = CodepageDetectorProxy.getInstance();

    static {
        codepageDetector.add(new ParsingDetector(false));codepageDetector.add(JChardetFacade.getInstance());codepageDetector.add(ASCIIDetector.getInstance());codepageDetector.add(UnicodeDetector.getInstance());}
}
