package info.monitorenter.cpdetector.io;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.nio.charset.Charset;

public class HTMLCodepageDetector extends AbstractCodepageDetector {
    private static final long serialVersionUID = 3258135756131022643L;

    private ParsingDetector delegate;

    public HTMLCodepageDetector() {
        this(false);
    }

    public HTMLCodepageDetector(boolean verbose) {
        super();
        this.delegate = new ParsingDetector(verbose);
    }

    public int compareTo(Object o) {
        return delegate.compareTo(o);
    }

    public Charset detectCodepage(InputStream in, int length) throws IOException {
        return delegate.detectCodepage(in, length);
    }

    public Charset detectCodepage(final URL url) throws IOException {
        return delegate.detectCodepage(url);
    }

    public boolean equals(Object obj) {
        return delegate.equals(obj);
    }

    public int hashCode() {
        return delegate.hashCode();
    }

    public String toString() {
        return delegate.toString();
    }
}
