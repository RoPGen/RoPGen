import java.util.Scanner;

public class SeriaFibonacciConDoWhile {
  public static void main(String[] args) {   
    
    System.out.println("Escribe cualquier numero");
    
    int i = 1;
    int elemento;
    int num1 = 0;
    int num2 = 1;
    int suma;
    
    Scanner teclado = new Scanner(System.in);
    elemento = teclado.nextInt();
    
    do {  
        if (elemento == 1){
            System.out.print("0");  
        } else {
            System.out.print(num1 + " ");
            do{
                suma = num1 + num2;
                System.out.print(num2 + " ");
                num1 = num2;
                num2 = suma;
            }while (i++ < (elemento - 1));
        }
    }while (i < elemento);
  }
}
