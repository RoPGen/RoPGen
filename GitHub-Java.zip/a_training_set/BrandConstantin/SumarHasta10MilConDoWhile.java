import java.util.Scanner;

public class SumarHasta10MilConDoWhile {
  public static void main(String[] args) {
    
    Scanner teclado = new Scanner(System.in);
    
    int suma = 0;
    int numIntrod;
    int totalNumeros = 0;
    
    do {
        System.out.println("Introduce numeros:");
        numIntrod = teclado.nextInt();  
        
        suma += numIntrod;
        totalNumeros++;

    } while (suma <= 10000);
    
    System.out.println("La media de los numeros es " + (suma / totalNumeros));
    System.out.println("El total acumulado siendo " + suma);
    System.out.println("Con un total de numeros introducidos de " + totalNumeros);  
  }
}