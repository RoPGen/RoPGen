import java.util.Scanner;

public class BaseExponentePotenciaConFor {
    public static void main(String[] args) {   
        
    Scanner teclado = new Scanner(System.in);
    
    System.out.println("Escribe el base (numero entero positivo)");
    int base = teclado.nextInt();
    
    System.out.println("Escribe la exponente (numero entero positivo)");
    int exponente = teclado.nextInt();
    
    int potencia = 1;
    int y;
    
    for(y = 1; y <= exponente; y++){
        potencia *= base;
        System.out.println(base + " ^ " + y + " = " + potencia);   
    }
  } 
}
