import java.util.Scanner;

public class EnterosPositivosDivisibles {

public static void main(String[] args) {
Scanner teclado = new Scanner(System.in);
    
    System.out.println("Introduce un numro que sea grande");
    int numIntrod = teclado.nextInt();  

    System.out.println("Introduce un divisor que sea mas pequeño que el " + 
                 " anterior");
    int divisor = teclado.nextInt(); 
    
    do {
        for (int i = 1; i < numIntrod; i++){
            if((i % divisor) != 0){
                System.out.print(i + "   ");
            }
        }
    } while (numIntrod < 0);
  }
}