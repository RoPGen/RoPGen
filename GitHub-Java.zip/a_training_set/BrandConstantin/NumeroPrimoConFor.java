import java.util.Scanner;

public class NumeroPrimoConFor {
  public static void main(String[] args) {   
    
    Scanner teclado = new Scanner(System.in);
      
    System.out.println("Escribe un numero:");
    int num = teclado.nextInt();
    
    boolean primo = true;
    
        if (num % 2 == 0){
          primo = true;
          System.out.println("Numero primo!");
        } else {
          primo = false;
          System.out.println("Numero no primo!");
        }

  }
}
