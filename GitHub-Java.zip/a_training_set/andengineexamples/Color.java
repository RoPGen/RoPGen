package org.andengine.examples.adt.card;

public enum Color {
    CLUB,  DIAMOND,
    HEART,
    SPADE; 
