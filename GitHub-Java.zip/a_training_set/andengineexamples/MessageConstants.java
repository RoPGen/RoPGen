package org.andengine.examples.adt.messages;

public class MessageConstants {
    public static final short PROTOCOL_VERSION = 1;

    
