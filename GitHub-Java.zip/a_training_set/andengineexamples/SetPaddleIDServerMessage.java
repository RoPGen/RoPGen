package org.andengine.examples.game.pong.adt.messages.server;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

import org.andengine.examples.game.pong.util.constants.PongConstants;
import org.andengine.extension.multiplayer.protocol.adt.message.server.ServerMessage;

public class SetPaddleIDServerMessage extends ServerMessage implements PongConstants {
    public int mPaddleID;

    public SetPaddleIDServerMessage() {

    }

    public SetPaddleIDServerMessage(final int pPaddleID) {
        this.mPaddleID = pPaddleID;
    }

    public void set(final int pPaddleID) {
        this.mPaddleID = pPaddleID;
    }

    @Override
    public short getFlag() {
        return FLAG_MESSAGE_SERVER_SET_PADDLEID;
    }

    @Override
    protected void onReadTransmissionData(DataInputStream pDataInputStream) throws IOException {
        this.mPaddleID = pDataInputStream.readInt();
    }

    @Override
    protected void onWriteTransmissionData(final DataOutputStream pDataOutputStream) throws IOException {
        pDataOutputStream.writeInt(this.mPaddleID);
    }
    
    