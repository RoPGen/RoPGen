package org.andengine.examples.adt;

public enum ZoomState {
    IN, 
    OUT,
    NONE;

    
