package org.andengine.examples.game.snake.adt;

public class SnakeSuicideException extends Exception {
    private static final long serialVersionUID = -4008723747610431268L;

    
