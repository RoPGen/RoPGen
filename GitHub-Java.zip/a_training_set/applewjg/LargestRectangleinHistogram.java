public class Solution {
    public int largestRectangleArea_1(int[] height) {
        int res = 0;
        for (int i = 0; i < height.length; ++i) {
            if ((i < height.length - 1) && (height[i] <= height[i+1])) {
                continue;
            }
            int minheight = height[i];
            for (int j = i; j >= 0; --j) {
                minheight = Math.min(minheight, height[j]);
                res = Math.max(res, (i-j+1)*minheight);
            }
        }
        return res;
    }
    public int largestRectangleArea(int[] height) {
        int res = 0;
        Stack<Integer> stk = new Stack<Integer>();
        int i = 0;
        while (i < height.length) {
            if (stk.isEmpty() == true || (height[i] >= height[stk.peek()])) {
                stk.push(i++);
            } else {
                int idx = stk.pop();
                int width = stk.isEmpty() ? i : (i - stk.peek() - 1);
                res = Math.max(res, width*height[idx]);
            }
        }
        while (stk.isEmpty() == false) {
            int idx = stk.pop();
            int width = stk.isEmpty() ? height.length : (height.length - stk.peek() - 1);
            res = Math.max(res, width*height[idx]);
        }
        return res;
    }
}