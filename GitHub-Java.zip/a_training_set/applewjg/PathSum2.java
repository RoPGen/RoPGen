public class Solution {
    public List<List<Integer>> pathSum(TreeNode root, int sum) {
        List<List<Integer>> res = new ArrayList<List<Integer>>();
        ArrayList<Integer> path = new ArrayList<Integer>();
        pathSumRe(root, sum, res, path);
        return res; 
    }
    public void pathSumRe(TreeNode root, int sum, List<List<Integer>> res, ArrayList<Integer> path)
    {
        if (root == null) return;
        path.add(root.val);
        if (root.left == null && root.right == null && root.val == sum){
            ArrayList<Integer> tmp = new ArrayList<Integer>(path);
            res.add(tmp);
        }
        pathSumRe(root.left, sum - root.val, res, path);
        pathSumRe(root.right, sum - root.val, res, path);
        path.remove(path.size()-1);
    }
}

