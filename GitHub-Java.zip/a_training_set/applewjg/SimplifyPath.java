public class Solution {
    public String simplifyPath(String path) {
        if(path.length()==0) return "/";
        if(path.charAt(0)!='/') return "/";
        ArrayList<String> dirs = new ArrayList<String>();
        String[] str = path.split("/");
        for (int i = 0; i < str.length; ++i) {
            if ((i == 0 || i == str.length - 1) && str[i].compareTo("") == 0) continue;
            if (str[i].compareTo("..") == 0) {
                if (dirs.isEmpty() == false) {
                    dirs.remove(dirs.size() - 1);
                }
            } else if ((str[i].compareTo(".") != 0) && (str[i].compareTo("") != 0)) {
                dirs.add(str[i]);
            }
        }
        if (dirs.isEmpty() == true) return "/";
        StringBuilder res = new StringBuilder();
        for (int i = 0; i < dirs.size(); ++i) {
            res.append("/");
            res.append(dirs.get(i));
        }
        return res.toString();
    }
}