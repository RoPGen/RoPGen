public class Solution {
    public String fractionToDecimal(int numerator, int denominator) {
        if (numerator == 0) return new String("0");
        boolean flag = (numerator < 0)^(denominator < 0);
        long Numerator = Math.abs((long)numerator);
        long Denominator = Math.abs((long)denominator);
        StringBuffer res = new StringBuffer();
        if (flag == true) res.append('-');
        res.append(String.valueOf((Numerator / Denominator)));
        Numerator = Numerator % Denominator;
        if (Numerator == 0) return res.toString();
        res.append('.');
        HashMap<Long, Integer> map = new HashMap<Long, Integer>();
        for (int i = res.length(); Numerator != 0; ++i) {
            if (map.get(Numerator) != null) break;
            map.put(Numerator, i);
            Numerator *= 10;
            res.append(String.valueOf((Numerator / Denominator)));
            Numerator %= Denominator;
        }
        
        if (Numerator == 0) return res.toString();
        res.insert(map.get(Numerator),"(");
        res.append(')');
        return res.toString();
    }
}