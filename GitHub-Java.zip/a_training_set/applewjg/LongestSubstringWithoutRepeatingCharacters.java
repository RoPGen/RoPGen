public class Solution {
    public int lengthOfLongestSubstring_1(String s) {
        boolean[] hash = new boolean[256];
        Arrays.fill(hash,false);
        int n = s.length();
        if (n <= 1) return n;
        int start = 0, end = 0, res = 0;
        while (end < n && start + res < n) {
            if (hash[s.charAt(end)] == false) {
                hash[s.charAt(end++)] = true;
            } else {
                hash[s.charAt(start++)] = false;
            }
            res = Math.max(res, end - start);
        }
        return res;
    }
    public int lengthOfLongestSubstring_2(String s) {
        int[] hash = new int[256];
        Arrays.fill(hash, -1);
        int n = s.length();
        if (n <= 1) return n;
        hash[s.charAt(0)] = 0;
        int start = 0, res = 1, cur = 0;
        while (++cur < n) {
            if (hash[s.charAt(cur)] >= start) {
                start = hash[s.charAt(cur)] + 1;
            }
            res = Math.max(res, cur - start + 1);
            hash[s.charAt(cur)] = cur;
        }
        return res;
    }
}
