public class Solution {
    public ListNode rotateRight(ListNode head, int k) {
        if (head == null) return head;
        int n = 1;
        ListNode tail = head, cur = head;
        while (tail.next != null) {
            tail = tail.next;
            ++n;
        }
        k = k % n;
        if (k == 0) return head;
        for (int i = 0; i < n - k - 1; ++i) 
            cur = cur.next;
        ListNode newHead = cur.next;
        tail.next = head;
        cur.next = null;
        return newHead;
    }
}