public class Solution {
    public boolean isPalindrome(int x) {
        return isPalindrome_2(x);
    }
    public boolean isPalindrome_1(int x) {
        if (x < 0) return false;
        int d = 1;
        while (x / d >= 10) d *= 10;
        while (d > 1) {
            if (x % 10 != x / d) return false;
            x = (x % d) / 10;
            d /= 100;
        }
        return true;
    }
    public boolean isPalindrome_2(int x) {
        if (x < 0) return false;
        return x == reverse(x);
    }
    public int reverse(int x) {
        int res = 0;
        while (x > 0) {
            res = res * 10 + x % 10;
            x = x / 10;
        }
        return res;
    }
}