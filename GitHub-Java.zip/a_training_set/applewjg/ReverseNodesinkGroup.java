public class Solution {
    public ListNode reverseKGroup(ListNode head, int k) {
        if (k <= 1) return head;
        int T = GetLength(head) / k;
        ListNode dummy = new ListNode(0), cur = head, ins = dummy; 
        dummy.next = head;
        while ((T--) != 0) {
            for (int i = 0; i < k - 1; ++i) {
                ListNode move = cur.next;
                cur.next = move.next;
                move.next = ins.next;
                ins.next = move;
            }
            ins = cur;
            cur = cur.next;
        }
        return dummy.next;
    }
    public int GetLength(ListNode head) {
        int length = 0;
        while (head != null) {
            head = head.next;
            length++;
        }
        return length;
    }
}