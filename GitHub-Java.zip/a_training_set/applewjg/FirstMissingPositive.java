public class Solution {
    public int firstMissingPositive_1(int[] A) {
        for(int i=0;i<A.length;i++)
            if(A[i]<=0) A[i]=A.length+2;
        for(int i=0;i<A.length;i++)
        {
            if(Math.abs(A[i])<A.length+1)
            {
                int cur = Math.abs(A[i])-1;
                A[cur] = -Math.abs(A[cur]);
            }
        }
        for(int i=0;i<A.length;i++)
            if(A[i]>0) return i+1;
        return A.length+1;
    }
    int firstMissingPositive_2(int A[], int n) {
        for(int i=0;i<n;i++){
            while(A[i]>=1&&A[i]<=n&&A[i]!=A[A[i]-1]) {
                int tmp = A[i];
                A[i] = A[tmp - 1];
                A[tmp - 1] = tmp;
            }
        }
        int i=0;
        for(i=0;i<n;i++){
            if(A[i]!=i+1) break;
        }
        return i+1;
    }
}