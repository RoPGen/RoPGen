public class Solution {
    public List<Interval> insert_1(List<Interval> intervals, Interval newInterval) {
        List<Interval> res = new ArrayList<Interval>();
        boolean inserted = false;
        for (Interval it : intervals) {
            if (inserted || it.end < newInterval.start) {
                res.add(it);
            } else if (it.start > newInterval.end) {
                res.add(newInterval);
                res.add(it);
                inserted = true;
            } else {
                newInterval.start = Math.min(newInterval.start, it.start);
                newInterval.end = Math.max(newInterval.end, it.end);
            }
        }
        if (inserted == false) res.add(newInterval);
        return res;
    }
    public List<Interval> insert(List<Interval> intervals, Interval newInterval) {
        List<Interval> res = new ArrayList<Interval>();
        int n = intervals.size();
        int left = 0, right = n - 1;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            if (intervals.get(mid).start > newInterval.start) right = mid - 1;
            else left = mid + 1;
        }
        int idxStart = right;
        left = 0; right = n - 1;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            if (intervals.get(mid).end < newInterval.end) left = mid + 1;
            else right = mid - 1;
        }
        int idxEnd = left;
        if (idxStart >= 0 && newInterval.start <= intervals.get(idxStart).end) {
            newInterval.start = intervals.get(idxStart--).start;
        }
        if (idxEnd < n && newInterval.end >= intervals.get(idxEnd).start) {
            newInterval.end = intervals.get(idxEnd++).end;
        }
        for (int i = 0; i <= idxStart; ++i) {
            res.add(intervals.get(i));
        }
        res.add(newInterval);
        for (int i = idxEnd; i < n; ++i) {
            res.add(intervals.get(i));
        }
        return res;
    }
}