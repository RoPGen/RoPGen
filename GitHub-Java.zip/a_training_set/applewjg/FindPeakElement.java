public class Solution {
    public int findPeakElement(int[] num) {
        int left = 0, right = num.length - 1, mid = -1;
        while (left <= right) {
            mid = (left + right) /2;
            if ((mid == 0 || num[mid-1] <= num[mid]) && (mid == num.length - 1 || num[mid] >= num[mid+1]))
                return mid;
            if (mid > 0 && num[mid-1] > num[mid]) {
                right = mid - 1;
            } else if (num[mid+1] > num[mid]) {
                left = mid + 1;
            }
        }
        return mid;
    }
}