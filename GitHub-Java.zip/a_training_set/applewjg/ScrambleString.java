public class Solution {
    public boolean isScramble_1(String s1, String s2) {
        if (s1.compareTo(s2) == 0) return true;
        if (s1.length() != s2.length()) return false;
        return isScrambleRe(s1, s2);
    }
    public boolean isScrambleRe(String s1, String s2) {
        if (hasSameLetters(s1, s2) == false) return false;
        int len = s1.length();
        if (len == 0 || len == 1) return true;
        for (int i = 1; i < len; ++i) {
            if (isScrambleRe(s1.substring(0,i), s2.substring(0,i)) 
                && isScrambleRe(s1.substring(i), s2.substring(i)) 
                || isScrambleRe(s1.substring(0,i), s2.substring(len-i)) 
                && isScrambleRe(s1.substring(i), s2.substring(0,len-i))) {
                    return true;
                }
        }
        return false;
    }
    public boolean hasSameLetters(String s1, String s2) {
        if (s1.compareTo(s2) == 0) return true;
        if (s1.length() != s2.length()) return false;
        int[] count = new int[256];
        for (int i = 0; i < s1.length(); ++i) count[(int)s1.charAt(i)]++;
        for (int i = 0; i < s2.length(); ++i) count[(int)s2.charAt(i)]--;
        for (int i = 0; i < 256; ++i)
            if (count[i] != 0) return false;
        return true;
    }
    public boolean isScramble(String s1, String s2) {
        if (s1.compareTo(s2) == 0) return true;
        if (s1.length() != s2.length()) return false;
        int N = s1.length();
        boolean[][][] dp = new boolean[N+1][N][N];
        for (int k = 1; k <= N; ++k) {
            for (int i = 0; i <= N - k; ++i) {
                for (int j = 0; j <= N - k; ++j) {
                    dp[k][i][j] = false;
                    if (k == 1) dp[1][i][j] = (s1.charAt(i) == s2.charAt(j));
                    for (int p = 1; p < k && !dp[k][i][j]; ++p) {
                        if (dp[p][i][j] && dp[k-p][i+p][j+p] || dp[p][i][j+k-p] && dp[k-p][i+p][j])
                            dp[k][i][j] = true;
                    }
                }
            }
        }
        return dp[N][0][0];
    }
}