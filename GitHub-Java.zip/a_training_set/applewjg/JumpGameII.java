public class Solution {
    public int jump(int[] A) {
        int n = A.length;
        int last = 0, cur = 0, res = 0;
        for (int i = 0; i < n; ++i) {
            if (i > last) {
                res++;
                last = cur;
                if (cur >= n - 1) return res;
            }
            cur = Math.max(cur, i + A[i]);
        }
        return res;
    }
}