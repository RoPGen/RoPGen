public class Solution {
    public int ladderLength(String start, String end, Set<String> dict) {
        Queue<String> cur = new LinkedList<String>();
        if(start.compareTo(end) == 0) return 0;
        cur.offer(start);
        int depth = 1;
        Set<String> visited = new HashSet<String>();
        while (cur.isEmpty() == false) {
            Queue<String> queue = new LinkedList<String>();
            while(cur.isEmpty() == false) {
                String str = cur.poll();
                char[] word = str.toCharArray();
                for (int i = 0; i < word.length; ++i) {
                    char before = word[i];
                    for (char ch = 'a'; ch <= 'z'; ++ch) {
                        word[i] = ch;
                        String temp = new String(word);
                        if (end.compareTo(temp) == 0) return depth + 1;
                        if (dict.contains(temp) == true && visited.contains(temp) == false) {
                            queue.offer(temp);
                            visited.add(temp);
                        }
                    }
                    word[i] = before;
                }
            }
            cur = queue;
            ++depth;
        }
        return 0;
    }
}