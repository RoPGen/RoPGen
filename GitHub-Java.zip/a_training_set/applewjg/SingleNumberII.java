public class Solution {
    public int singleNumber_1(int[] A) {
        int res = 0;
        for (int i = 0; i < 32; ++i) {
            int one = 0;
            for (int num : A) {
                if (((num >> i) & 1) == 1) ++one;
            }
            res = res | ((one % 3)<<i);
        }
        return res;
    }
    public int singleNumber_2(int[] A) {
        int one = 0, twice = 0;
        for (int num : A) {
            twice = twice | (one & num);
            one = one ^ num;
            int three = one & twice;
            one = one ^ three;
            twice = twice ^ three;
        }
        return one;
    }
    public int singleNumber(int[] A) {
        int k = 1, n = 3;
        int[] x = new int[n];
        x[0] = ~0;
        for (int num : A) {
            int t = x[n-1];
            for (int i = n - 1; i >= 1; --i) {
                x[i] = (x[i-1] & num) | (x[i] & ~num);
            }
            x[0] = (t & num) | (x[0] & ~num);
        }
        return x[k];
    }
}