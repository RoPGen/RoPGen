public class Solution {
    public List<TreeNode> generateTrees(int n) {
        return generateTreesRe(1, n);
    }
    public List<TreeNode> generateTreesRe(int l, int r) {
        ArrayList<TreeNode> res = new ArrayList<TreeNode>();
        if (l > r) {
            res.add(null);
            return res;
        }
        for (int k = l; k <= r; ++k) {
            List<TreeNode> leftTrees = generateTreesRe(l, k-1);
            List<TreeNode> rightTrees = generateTreesRe(k+1, r);
            for (int i = 0; i < leftTrees.size(); i++) {
                for (int j = 0; j < rightTrees.size(); j++) {
                    TreeNode root = new TreeNode(k);
                    root.left = leftTrees.get(i);
                    root.right = rightTrees.get(j);
                    res.add(root);
                }
            }
        }
        return res;
    }
}