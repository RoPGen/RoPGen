class Solution {
    public void sortColors2(int[] A, int k) {
        int n = A.length;
        if (n <= 1) return;
        for (int i = 0; i < n; ++i) {
            if(A[i] > 0) {
                int c = A[i];
                A[i] = 0;
                while(true) {
                    if (A[c-1] <= 0) {
                        --A[c-1];
                        break;
                    } else {
                        int col = A[c-1];
                        A[c-1] = -1;
                        c = col;
                    }
                }
            }
        }
        int idx = n;
        for (int i = k; i > 0; --i) {
            for (int j = 0; j > A[i-1]; --j) A[--idx] = i;
        }
    }
}
