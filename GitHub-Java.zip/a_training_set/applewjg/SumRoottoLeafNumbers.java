public class Solution {
    public int sumNumbers(TreeNode root) {
        if (root == null) return 0;
        return sumNumbersRe(root,0);
    }
    public int sumNumbersRe(TreeNode root, int last) {
        if (root == null) return 0;
        int res = last * 10 + root.val;
        if (root.left == null && root.right == null) return res;
        if (root.left == null) return sumNumbersRe(root.right, res);
        if (root.right == null) return sumNumbersRe(root.left, res);
        return sumNumbersRe(root.left, res) + sumNumbersRe(root.right, res);
    }
}