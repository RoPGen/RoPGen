package facebook;
 
 import java.io.BufferedReader;
 import java.io.File;
 import java.io.FileReader;
 import java.io.IOException;
 import java.io.InputStreamReader;
 import java.io.PrintStream;
 import java.util.Arrays;
 
 public class Qual {
 
    private static BufferedReader br = null;
    private static int readInt() {
        try {
            return Integer.parseInt(br.readLine());
        } catch (NumberFormatException e) {
            
            e.printStackTrace();
        } catch (IOException e) {
            
            e.printStackTrace();
        }
        return 0;
    }
    
    private static double readDouble() {
        try {
            return Double.parseDouble(br.readLine());
        } catch (NumberFormatException e) {
            
            e.printStackTrace();
        } catch (IOException e) {
            
            e.printStackTrace();
        }
        return 0;
    }
    
    private static int[] readIntArr() {
        int[] ret = null;
        String[] tmp;
        try {
            String str = br.readLine();
            tmp = str.split(" ");
            ret = new int[tmp.length];
            for (int i = 0; i < tmp.length; i++)
                ret[i] = Integer.parseInt(tmp[i]);
        } catch (NumberFormatException e) {
            
            e.printStackTrace();
        } catch (IOException e) {
            
            e.printStackTrace();
        }
        return ret;
    }
    
    public static String generate(char s, int n) {
        char[] ret = new char[1];
        int l = 1;
        ret[0] = s;
        while (l < n) {
            
            char[] tmp = new char[2 * l];
            for (int i = 0; i < l; i++) {
                tmp[2*i] = ret[i];
                if (ret[i] == 'P') {
                    tmp[2 * i + 1] = 'R';
                } else if (ret[i] == 'R') {
                    tmp[2 * i + 1] = 'S';
                } else {
                    tmp[2 * i + 1] = 'P';
                }
            }
            
            ret = tmp;
            
            l *= 2;
        }
        
        for (l = 1; l < n; l*=2) {
            for (int i = 0; i < n; i+= 2 * l) {
                boolean swap = false;
                
                for (int j = 0; j < l; j++) {
                    if (ret[i + j] < ret[i + j + l])break;
                    if (ret[i + j] > ret[i + j + l]) {
                        swap = true;
                        break;
                    }
                }
                
                if (swap) {
                    for (int j = 0; j < l; j++) {
                        char t = ret[i + j];
                        ret[i + j] = ret[i + j + l];
                        ret[i + j + l] = t;
                    }
                }
            }
        }
        
        return new String(ret);
    }
    public static void main(String[] args) throws IOException {
        
        br = new BufferedReader(new FileReader(new File("input.txt")));
        System.setOut(new PrintStream(new File("output.txt")));
        int T = readInt();
        
        
        for (int ind = 1; ind<=T; ind++) {
            System.out.print("Case #" + ind + ": ");
            int[] ar = readIntArr();
            int n = ar[0];
            int p = ar[2];
            int r = ar[1];
            int s = ar[3];
            String[] tmp = new String[3];
            tmp[0] = generate('P', 1 << n);
            tmp[1] = generate('R', 1 << n);
            tmp[2] = generate('S', 1 << n);
            Arrays.sort(tmp);
            boolean found = false;
            for (int i = 0; i < 3; i++) {
                int pc = 0;
                int rc = 0;
                int sc = 0;
                for (int j = 0; j < tmp[i].length(); j++) {
                    char c = tmp[i].charAt(j);
                    if (c == 'R') rc++;
                    else if (c == 'P')pc++;
                    else sc++;
                }
                
                if (pc == p && rc == r && sc == s) {
                    System.out.println(tmp[i]);
                    found = true;
                    break;
                }
            }
            if (!found) System.out.println("IMPOSSIBLE");
            
        }
    }
 
 }
