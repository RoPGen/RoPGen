package facebook;
 
 import java.io.BufferedReader;
 import java.io.File;
 import java.io.FileReader;
 import java.io.IOException;
 import java.io.InputStreamReader;
 import java.io.PrintStream;
 import java.util.Arrays;
 import java.util.HashSet;
 import java.util.Set;
 
 public class Qual {
 
    private static BufferedReader br = null;
    private static int readInt() {
        try {
            return Integer.parseInt(br.readLine());
        } catch (NumberFormatException e) {
            
            e.printStackTrace();
        } catch (IOException e) {
            
            e.printStackTrace();
        }
        return 0;
    }
    
    private static double readDouble() {
        try {
            return Double.parseDouble(br.readLine());
        } catch (NumberFormatException e) {
            
            e.printStackTrace();
        } catch (IOException e) {
            
            e.printStackTrace();
        }
        return 0;
    }
    
    private static int[] readIntArr() {
        int[] ret = null;
        String[] tmp;
        try {
            String str = br.readLine();
            tmp = str.split(" ");
            ret = new int[tmp.length];
            for (int i = 0; i < tmp.length; i++)
                ret[i] = Integer.parseInt(tmp[i]);
        } catch (NumberFormatException e) {
            
            e.printStackTrace();
        } catch (IOException e) {
            
            e.printStackTrace();
        }
        return ret;
    }
    
    private static double[] readDouArr() {
        double[] ret = null;
        String[] tmp;
        try {
            String str = br.readLine();
            tmp = str.split(" ");
            ret = new double[tmp.length];
            for (int i = 0; i < tmp.length; i++)
                ret[i] = Double.parseDouble(tmp[i]);
        } catch (NumberFormatException e) {
            
            e.printStackTrace();
        } catch (IOException e) {
            
            e.printStackTrace();
        }
        return ret;
    }
    
 
    public static void main(String[] args) throws IOException {
        
        br = new BufferedReader(new FileReader(new File("input.txt")));
        System.setOut(new PrintStream(new File("output.txt")));
        int T = readInt();
        
        
        for (int ind = 1; ind<=T; ind++) {
            System.out.print("Case #" + ind + ": ");
            int n = readInt();
            
            boolean[][] w = new boolean[n][n];
            for (int  i = 0; i < n; i++) {
                String t = br.readLine();
                
                for (int j = 0; j < t.length(); j++)
                    w[i][j] = (t.charAt(j) == '1');
            }
            int h[] = new int[n];
            int v[] = new int[n];
            for (int i =0; i < n;i++)
                for (int j = 0;  j < n; j++) {
                    if (w[i][j]) {
                        h[i]++;
                        v[j]++;
                    }
                }
            
            int hz = 0;
            int vz = 0;
            int hb[] = new int[n];
            int vb[] = new int[n];
            int ma = 0;
            for (int i = 0; i<n;i++) {
                if (h[i] == 0)hz++;
                if (v[i] == 0)vz++;
                ma = Math.max(ma, h[i]);
                ma = Math.max(ma, v[i]);
            }
            int zero = Math.min(hz, vz);
            
            int one = 0;
            for (int i = 0; i < n; i++)
                for (int j = 0; j < n; j++) {
                    if (h[i] == 1 && v[j] == 1 && w[i][j]) {
                        one++;
                        hb[i] = 1;
                        vb[j] = 1;
                    }
                }
            int k = 0;
            for (int i = 0; i < n; i++) {
                if (k >= zero)break;
                if (h[i] == 0) {
                    k++;
                    hb[i] = 1;
                }
            }
            k=0;
            for (int i = 0; i < n; i++) {
                if (k >= zero)break;
                if (v[i] == 0) {
                    k++;
                    vb[i] = 1;
                }
            }
            
            int add = 0;
            if (zero + one < n) {
                int ti = -1;
                int tii = -1;
                int tcount = 0;
                if (ma < 3 && n - one == 4) {
                    for (int i = 0; i < n; i++) {
                        if (ti != -1)break;
                        for (int ii = i + 1; ii<n;ii++) {
                            if (hb[i] == 1 && h[i] != 0 || hb[ii] == 1 && h[ii] != 0)continue;
                            
                            Set<Integer> set = new HashSet<>();
                            for (int j = 0; j < n; j++) {
                                if (w[i][j]){tcount++;set.add(j);}
                                if (w[ii][j]){tcount++;set.add(j);}
                            }
                            
                            if (set.size() < 3) {
                                ti = i;
                                tii = ii;
                                break;
                            }
                        }
                    }
                }
                
                int Ti = -1;
                int Tii = -1;
                int Tcount = 0;
                if (ti > -1) {
                    
                    for (int i = 0; i < n; i++) {
                        if (Ti != -1)break;
                        for (int ii = i + 1; ii<n;ii++) {
                            if (hb[i] == 1 && h[i] != 0 || i == ti || i == tii || ii == ti || ii == tii || hb[ii] == 1 && h[ii] != 0)continue;
                            
                            Set<Integer> set = new HashSet<>();
                            for (int j = 0; j < n; j++) {
                                if (w[i][j]){set.add(j);Tcount++;}
                                if (w[ii][j]){
                                    set.add(j);Tcount++;
                                }
                            }
                            
                            if (set.size() < 3) {
                                Ti = i;
                                Tii = ii;
                                break;
                            }
                        }
                    }
                }
                
                for (int i = 0; i < n; i++) {
                    for (int j = 0; j < n; j++) {
                        if (hb[i] == 1 || vb[j] == 1)continue;
                        if (!w[i][j])add++;
                    }
                }
                
                if (Ti > -1) {
                    add = Math.min(tcount + Tcount, zero + add);
                    add -= zero;
                }
                
            }
            
            System.out.println(zero + add);
            
        }
    }
 
 }
