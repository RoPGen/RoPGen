package codejam;
 
 import java.io.File;
 import java.io.FileNotFoundException;
 import java.io.PrintStream;
 import java.util.Locale;
 import java.util.Scanner;
 
 
 @SuppressWarnings("FieldCanBeLocal")
 public class A {
     @SuppressWarnings({"FieldCanBeLocal", "UnusedDeclaration"})
     private int caseNumber;
     private static Scanner sc;
     private static PrintStream out;
     private static boolean PRINT_TO_CONSOLE = true;
     public static final char P = 'P';
     public static final char R = 'R';
     public static final char S = 'S';
     private int cc;
     private int n;
     
 
     void solve() {
         n = sc.nextInt();
         int r = sc.nextInt();
         int p = sc.nextInt();
         int s = sc.nextInt();
         cc = 1 << n;
 
         if (n > 1) {
             if (r == 0 || p == 0 || s == 0) {
                 out.printf("IMPOSSIBLE\n");
                 return;
             }
         } else {
             if (p == 1) {
                 if (r == 1) {
                     out.printf("PR\n");
                     return;
                 } else {
                     out.printf("PS\n");
                     return;
                 }
             } else if (r == 1) {
                 out.printf("RS\n");
                 return;
             } else {
                 out.printf("IMPOSSIBLE\n");
                 return;
             }
         }
 
 
         char[] comb = new char[cc];
         if (tryComb(p, r, s, comb, 0)) {
             out.printf("%s\n", new String(comb));
         } else {
             out.printf("IMPOSSIBLE\n");
         }
     }
 
     boolean tryComb(int p, int r, int s, char[] current, int index) {
         if (index == cc) {
             return check(current);
         }
         
         if (p > 0 && r > 0) {
             current[index++] = P;
             current[index++] = R;
             if (tryComb(p - 1, r - 1, s, current, index)) {
                 return true;
             }
             index -= 2;
         }
         
         if (p > 0 && s > 0) {
             current[index++] = P;
             current[index++] = S;
             if (tryComb(p - 1, r, s - 1, current, index)) {
                 return true;
             }
             index -= 2;
         }
         
         if (r > 0 && s > 0) {
             current[index++] = R;
             current[index++] = S;
             if (tryComb(p, r - 1, s - 1, current, index)) {
                 return true;
             }
         }
 
         return false;
     }
 
     boolean check(char[] comb) {
         char[] curr = comb;
         char[] next = new char[comb.length / 2];
         int len = next.length;
         while (true) {
             if (len == 0) {
                 return true;
             }
 
             for (int i = 0; i < len; ++i) {
                 char f = curr[i * 2];
                 char s = curr[i * 2 + 1];
                 char res;
                 if (f == P) {
                     if (s == S) {
                         res = S;
                     } else if (s == R) {
                         res = P;
                     } else {
                         return false;
                     }
                 } else if (f == R) {
                     if (s == P) {
                         res = P;
                     } else if (s == S) {
                         res = R;
                     } else {
                         return false;
                     }
                 } else { 
                     if (s == R) {
                         res = R;
                     } else if (s == P) {
                         res = S;
                     } else {
                         return false;
                     }
                 }
                 next[i] = res;
             }
 
             curr = next.clone();
             len /= 2;
         }
     }
 
     public static void main(String[] args) throws Exception {
         Locale.setDefault(Locale.US);
 
 
         String file = "A-small-attempt1";
 
         String outFileName = file + ".out";
         out = PRINT_TO_CONSOLE ? new CJPrintStream(outFileName) : new PrintStream(outFileName);
 
         String inFile = file + ".in";
         sc = new Scanner(new File(inFile));
 
         int cases = sc.nextInt();
         for (int caseNumber = 1; caseNumber <= cases; ++caseNumber) {
             out.printf("Case #%s: ", caseNumber);
             A template = new A();
             template.caseNumber = caseNumber;
             template.solve();
             out.flush();
         }
 
         sc.close();
     }
 
     static class CJPrintStream extends PrintStream {
         public CJPrintStream(String fileName) throws FileNotFoundException {
             super(fileName);
         }
 
         @SuppressWarnings("NullableProblems")
         @Override
         public PrintStream printf(String format, Object... args) {
             System.out.printf(format, args);
             return super.printf(format, args);
         }
 
         @Override
         public void println() {
             System.out.println();
             super.println();
         }
 
         @Override
         public void flush() {
             System.out.flush();
             super.flush();
         }
     }
 }
