import java.io.File;
 import java.io.PrintStream;
 import java.util.Arrays;
 import java.util.Locale;
 import java.util.Scanner;
 
 public class B {
 
    private static double calc(double[] com, int k) {
        double[][] prob = new double[k + 1][k + 1];
 
        prob[0][0] = 1;
 
        for (int i = 1; i <= k; i++) {
            for (int j = 0; j < i; j++) {
                int k1 = j;
                int k2 = i - 1 - j;
 
                prob[k1 + 1][k2] += prob[k1][k2] * com[i - 1];
                prob[k1][k2 + 1] += prob[k1][k2] * (1 - com[i - 1]);
            }
        }
 
        return prob[k / 2][k / 2];
    }
 
 
    private static double generate(int n, int k, int i, int j, double[] p, double[] com) {
        if (j == k) {
            return calc(com, k);
        }
 
        if (i == n) {
            return 0;
        }
 
        com[j] = p[i];
        double r1 = generate(n, k, i+1, j+1, p, com);
 
        double r2 = generate(n, k, i+1, j, p, com);
 
        return Math.max(r1, r2);
    }
 
 
 
 
    public static void main(String[] args) throws Exception {
        Locale.setDefault(Locale.US);
 
        Scanner in = new Scanner(new File("problem.in"));
        PrintStream out = new PrintStream(new File("problem.out"));
 
        int T = in.nextInt();
 
        for (int test = 1; test <= T; test++) {
 
            int n = in.nextInt();
            int k = in.nextInt();
 
            double[] p = new double[n];
 
            for (int i = 0; i < n; i++) {
                p[i] = in.nextDouble();
            }
            Arrays.sort(p);
 
            double[] com = new double[k];
 
            out.printf("Case #%d: %f", test, generate(n, k, 0, 0, p, com));
            out.println();
        }
 
    }
 }
