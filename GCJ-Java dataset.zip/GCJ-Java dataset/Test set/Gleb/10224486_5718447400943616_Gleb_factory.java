import java.io.BufferedReader;
 import java.io.File;
 import java.io.FileReader;
 import java.io.PrintWriter;
 import java.io.StreamTokenizer;
 import java.util.ArrayList;
 import java.util.Arrays;
 import java.util.List;
 import java.util.Scanner;
 
 public class Factory implements Runnable {
   private static final String NAME = "fact";
 
   private  StreamTokenizer in;
 
   int nextInt() throws Exception {
     in.nextToken();
     return (int) in.nval;
   }
 
   long nextLong() throws Exception {
     in.nextToken();
     return (long) in.nval;
   }
 
   List<int[]> perms(int n) {
     List<int[]> res = new ArrayList<int[]>();
     int[] p = new int[n];
     Arrays.fill(p, -1);
     doPerm(p, 0, res);
     return res;
   }
 
   void doPerm(int[] p, int k, List<int[]> res) {
     if (k == p.length) {
       res.add(Arrays.copyOf(p, p.length));
       return;
     }
     for (int i = 0; i < p.length; i++) {
       if (p[i] == -1) {
         p[i] = k;
         doPerm(p, k + 1, res);
         p[i] = -1;
       }
     }
   }
 
   boolean test(int[] p, int k, boolean[] o, int[] ord) {
     if (k == p.length) {
       return true;
     }
     int cur = ord[k];
     boolean found = false;
     for (int i = 0; i < p.length; i++) {
       if ((p[cur] & (1 << i)) != 0 && !o[i]) {
         found = true;
         o[i] = true;
         if (!test(p, k + 1, o, ord)) {
           return false;
         };
         o[i] = false;
       }
     }
     return found;
   }
 
   @Override
   public void run() {
     try {
       Scanner in = new Scanner(new File(NAME + ".in"));
 
       PrintWriter out = new PrintWriter(NAME + ".out");
 
       int tests = in.nextInt();
 
       for (int test = 1; test <= tests; test++) {
         int n = in.nextInt();
         int[] p = new int[n];
         for (int i = 0; i < n; i++) {
           p[i] = 0;
           String s = in.next();
           for (int m = 0; m < n; m++) {
             p[i] += (s.charAt(m) - '0') << m;
           }
         }
 
         List<int[]> perms = perms(n);
 
         int res = Integer.MAX_VALUE;
         for (int i = 0; i < 1 << (n * n); i++) {
           boolean g = true;
           int[] pp = new int[n];
           int diff = 0;
           for (int j = 0; j < n; j++) {
             for (int k = 0; k < n; k++) {
               int d = (i & (1 << (k + j * n))) == 0 ? 0 : 1;
               int origD = (p[j] & (1 << k)) == 0 ? 0 : 1;
               if (origD == 1 && d != 1) g = false;
               if (origD == 0 && d == 1) diff++;
               pp[j] += d << k;
             }
           }
           if (!g) continue;
           for (int[] perm : perms) {
             if (!test(pp, 0, new boolean[n], perm)) {
               g = false;
               break;
             }
           }
           if (!g) continue;
           res = Math.min(diff, res);
         }
         out.println("Case #" + test + ": " + res);
       }
 
       out.close();
     } catch (Exception e) {
       throw new RuntimeException(e);
     }
   }
 
   public static void main(String[] args) {
     new Thread(new Factory()).start();
   }
 }
