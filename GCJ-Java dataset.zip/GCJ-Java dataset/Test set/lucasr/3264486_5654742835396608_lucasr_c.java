package qualy;
 
 import java.util.Scanner;
 
 public class C {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int cases = sc.nextInt();
        for (int caze = 1; caze <= cases; caze++) {
            long n = sc.nextLong();
            long k = sc.nextLong();
            long min = 1, max = 0;
            long ans = -1;
            while (true) {
                long nn = (n - 1) / 2, nmin = 0, nmax = 0;
                if (max > 0) {
                    if (max >= k) {
                        ans = n + 1;
                        break;
                    }
                    k -= max;
                    nmax += max;
                    if ((n / 2 != (n + 1) / 2)) nmin += max;
                    else nmax += max;
                }
                if (min > 0) {
                    if (min >= k) {
                        ans = n;
                        break;
                    }
                    k -= min;
                    nmin += min;
                    if (((n-1) / 2 != n / 2)) nmax += min;
                    else nmin += min;
                }
                max = nmax;
                min = nmin;
                n = nn;
            }
 
            System.out.println("Case #" + caze + ": " + (ans / 2) + " " + ((ans - 1) / 2));
        }
    }
 }
