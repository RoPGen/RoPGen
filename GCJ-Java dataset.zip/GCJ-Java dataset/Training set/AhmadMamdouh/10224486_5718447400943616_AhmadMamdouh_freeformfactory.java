import java.io.BufferedReader;
 import java.io.FileReader;
 import java.io.IOException;
 import java.io.InputStream;
 import java.io.InputStreamReader;
 import java.util.ArrayList;
 import java.util.StringTokenizer;
 
 public class FreeformFactory {
    static boolean[][] can;
    static ArrayList<Integer> masks;
    static int res;
    static Boolean[][] dp;
 
    static void go(int index, int[] newCan) {
        if (index == can.length) {
            if (comp(can, newCan)) {
                dp = new Boolean[1 << can.length][1 << can.length];
                if (go(0, 0, newCan))
                    res = Math.min(res, compute(can, newCan));
            }
            return;
        }
        for (int x : masks) {
            newCan[index] = x;
            go(index + 1, newCan);
        }
    }
 
    private static int compute(boolean[][] can, int[] newCan) {
        int res = 0;
        for (int i = 0; i < can.length; i++) {
            for (int j = 0; j < can.length; j++) {
                if (!can[i][j] && (newCan[i] & (1 << j)) > 0)
                    res++;
            }
        }
        return res;
    }
 
    private static boolean go(int workers, int machines, int[] newCan) {
        if (workers == (1 << can.length) - 1
                && machines == (1 << can.length) - 1)
            return true;
        if (dp[workers][machines] != null)
            return dp[workers][machines];
        for (int i = 0; i < can.length; i++) {
            if ((workers & (1 << i)) == 0) {
                boolean foundOne = false;
                for (int j = 0; j < can.length; j++) {
                    if ((machines & (1 << j)) == 0
                            && (newCan[i] & (1 << j)) > 0) {
                        foundOne = true;
                        if (!go(workers | (1 << i), machines | (1 << j), newCan))
                            return dp[workers][machines] = false;
                    }
                }
                if (!foundOne)
                    return dp[workers][machines] = false;
            }
        }
        return dp[workers][machines] = true;
    }
 
    private static boolean comp(boolean[][] can, int[] newCan) {
        for (int i = 0; i < can.length; i++) {
            for (int j = 0; j < can.length; j++) {
                if (can[i][j] && (newCan[i] & (1 << j)) == 0)
                    return false;
            }
        }
        return true;
    }
 
    public static void main(String[] args) {
        InputReader r = new InputReader(System.in);
        int T = r.nextInt();
        int test = 1;
        while (test <= T) {
            int n = r.nextInt();
            can = new boolean[n][n];
            for (int i = 0; i < can.length; i++) {
                char[] arr = r.next().toCharArray();
                for (int j = 0; j < can.length; j++) {
                    can[i][j] = arr[j] == '1';
                }
            }
            masks = new ArrayList<Integer>();
            for (int i = 0; i < 1 << n; i++) {
                masks.add(i);
            }
            res = 1 << 28;
            go(0, new int[n]);
            System.out.printf("Case #%d: %d\n", test++, res);
        }
    }
 
    static class InputReader {
        private BufferedReader reader;
        private StringTokenizer tokenizer;
 
        public InputReader(InputStream stream) {
            reader = new BufferedReader(new InputStreamReader(stream));
            tokenizer = null;
        }
 
        public InputReader(FileReader stream) {
            reader = new BufferedReader(stream);
            tokenizer = null;
        }
 
        public String nextLine() {
            try {
                return reader.readLine();
            } catch (IOException e) {
                
                e.printStackTrace();
                return null;
            }
        }
 
        public String next() {
            while (tokenizer == null || !tokenizer.hasMoreTokens()) {
                try {
                    tokenizer = new StringTokenizer(reader.readLine());
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            return tokenizer.nextToken();
        }
 
        public int nextInt() {
            return Integer.parseInt(next());
        }
 
        public double nextDouble() {
            return Double.parseDouble(next());
        }
    }
 }
