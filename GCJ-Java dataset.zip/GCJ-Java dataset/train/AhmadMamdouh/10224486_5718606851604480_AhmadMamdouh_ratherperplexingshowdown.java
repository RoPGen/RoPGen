import java.io.BufferedReader;
 import java.io.FileReader;
 import java.io.IOException;
 import java.io.InputStream;
 import java.io.InputStreamReader;
 import java.util.StringTokenizer;
 import java.util.TreeSet;
 
 public class RatherPerplexingShowdown {
    static int rock, paper, scissors;
 
    static boolean can(int[] arr, int length) {
        if (length == 1)
            return true;
        int[] newArr = new int[length / 2];
        for (int i = 0; i < arr.length; i += 2) {
            switch (arr[i]) {
            case 0:
                switch (arr[i + 1]) {
                case 0:
                    return false;
                case 1:
                    newArr[i / 2] = 1;
                    break;
                case 2:
                    newArr[i / 2] = 0;
                    break;
                }
                break;
            case 1:
                switch (arr[i + 1]) {
                case 0:
                    newArr[i / 2] = 1;
                    break;
                case 1:
                    return false;
                case 2:
                    newArr[i / 2] = 2;
                    break;
                }
                break;
            case 2:
                switch (arr[i + 1]) {
                case 0:
                    newArr[i / 2] = 0;
                    break;
                case 1:
                    newArr[i / 2] = 2;
                    break;
                case 2:
                    return false;
                }
                break;
            }
        }
        return can(newArr, length / 2);
    }
 
    static TreeSet<String> set;
 
    static void go(int[] cnts, int[] arrangement, int index) {
        if (index == arrangement.length) {
            if (can(arrangement, arrangement.length)) {
                set.add(get(arrangement));
            }
            return;
        }
        for (int i = 0; i < cnts.length; i++) {
            if (cnts[i] > 0) {
                cnts[i]--;
                arrangement[index] = i;
                go(cnts, arrangement, index + 1);
                cnts[i]++;
            }
        }
    }
 
    private static String get(int[] arrangement) {
        String ret = "";
        for (int i = 0; i < arrangement.length; i++) {
            if (arrangement[i] == 0)
                ret += "R";
            else if (arrangement[i] == 1)
                ret += "P";
            else
                ret += "S";
        }
        return ret;
    }
 
    public static void main(String[] args) {
        InputReader r = new InputReader(System.in);
        int T = r.nextInt();
        int test = 1;
        while (test <= T) {
            int n = r.nextInt();
            rock = r.nextInt();
            paper = r.nextInt();
            scissors = r.nextInt();
            set = new TreeSet<String>();
            go(new int[] { rock, paper, scissors }, new int[1 << n], 0);
            String res = "";
            if (set.size() == 0)
                res = "IMPOSSIBLE";
            else
                res = set.first();
            System.out.printf("Case #%d: %s\n", test, res);
            test++;
        }
    }
 
    static class InputReader {
        private BufferedReader reader;
        private StringTokenizer tokenizer;
 
        public InputReader(InputStream stream) {
            reader = new BufferedReader(new InputStreamReader(stream));
            tokenizer = null;
        }
 
        public InputReader(FileReader stream) {
            reader = new BufferedReader(stream);
            tokenizer = null;
        }
 
        public String nextLine() {
            try {
                return reader.readLine();
            } catch (IOException e) {
                
                e.printStackTrace();
                return null;
            }
        }
 
        public String next() {
            while (tokenizer == null || !tokenizer.hasMoreTokens()) {
                try {
                    tokenizer = new StringTokenizer(reader.readLine());
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            return tokenizer.nextToken();
        }
 
        public int nextInt() {
            return Integer.parseInt(next());
        }
 
        public double nextDouble() {
            return Double.parseDouble(next());
        }
    }
 }
