import java.io.BufferedReader;
 import java.io.FileReader;
 import java.io.IOException;
 import java.io.InputStream;
 import java.io.InputStreamReader;
 import java.util.Arrays;
 import java.util.StringTokenizer;
 
 public class RedTapeCommitte {
    static double[] prob;
    static int k;
 
    
 
    public static void main(String[] args) {
        InputReader r = new InputReader(System.in);
        int T = r.nextInt();
        int test = 1;
        while (test <= T) {
            int n = r.nextInt();
            k = r.nextInt();
            prob = new double[n];
            for (int i = 0; i < prob.length; i++) {
                prob[i] = r.nextDouble();
            }
            
            double res = 0;
            for (int i = 0; i < (1 << n); i++) {
                if (Integer.bitCount(i) != k)
                    continue;
                double[] p = new double[k];
                int index = 0;
                for (int j = 0; j < n; j++) {
                    if ((i & (1 << j)) > 0) {
                        p[index++] = prob[j];
                    }
                }
                dp = new Double[n][n];
                double tieProb = go(p, 0, 0);
                res = Math.max(res, tieProb);
            }
            System.out.printf("Case #%d: %.9f\n", test++, res);
        }
    }
 
    static Double[][] dp;
 
    private static double go(double[] p, int yes, int no) {
        int index = yes + no;
        if (yes + no == p.length) {
            if (yes == no)
                return 1;
            return 0;
        }
        if (dp[yes][no] != null)
            return dp[yes][no];
        return dp[yes][no] = p[index] * go(p, yes + 1, no) + (1 - p[index])
                * go(p, yes, no + 1);
    }
 
    static class InputReader {
        private BufferedReader reader;
        private StringTokenizer tokenizer;
 
        public InputReader(InputStream stream) {
            reader = new BufferedReader(new InputStreamReader(stream));
            tokenizer = null;
        }
 
        public InputReader(FileReader stream) {
            reader = new BufferedReader(stream);
            tokenizer = null;
        }
 
        public String nextLine() {
            try {
                return reader.readLine();
            } catch (IOException e) {
                
                e.printStackTrace();
                return null;
            }
        }
 
        public String next() {
            while (tokenizer == null || !tokenizer.hasMoreTokens()) {
                try {
                    tokenizer = new StringTokenizer(reader.readLine());
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            return tokenizer.nextToken();
        }
 
        public int nextInt() {
            return Integer.parseInt(next());
        }
 
        public double nextDouble() {
            return Double.parseDouble(next());
        }
    }
 }
