import java.io.OutputStream;
 import java.io.FilenameFilter;
 import java.util.Locale;
 import java.io.FileOutputStream;
 import java.io.IOException;
 import java.io.FileInputStream;
 import java.io.File;
 import java.io.InputStream;
 import java.util.Arrays;
 import java.util.InputMismatchException;
 import java.util.ArrayList;
 import java.util.concurrent.atomic.AtomicInteger;
 import java.io.OutputStreamWriter;
 import java.util.NoSuchElementException;
 import java.io.OutputStream;
 import java.io.PrintWriter;
 import java.io.PrintStream;
 import java.util.Iterator;
 import java.io.BufferedWriter;
 import java.util.Collection;
 import java.io.IOException;
 import java.util.List;
 import java.io.Writer;
 import java.util.Queue;
 import java.util.ArrayDeque;
 import java.util.Collections;
 import java.io.InputStream;
 
 
 public class Main {
     public static void main(String[] args) {
         Locale.setDefault(Locale.US);
         InputStream inputStream;
         try {
             final String regex = "D-(small|large).*[.]in";
             File directory = new File(".");
             File[] candidates = directory.listFiles(new FilenameFilter() {
                 public boolean accept(File dir, String name) {
                     return name.matches(regex);
                 }
             });
             File toRun = null;
             for (File candidate : candidates) {
                 if (toRun == null || candidate.lastModified() > toRun.lastModified()) {
                     toRun = candidate;
                 }
             }
             inputStream = new FileInputStream(toRun);
         } catch (IOException e) {
             throw new RuntimeException(e);
         }
         OutputStream outputStream;
         try {
             outputStream = new FileOutputStream("d.out");
         } catch (IOException e) {
             throw new RuntimeException(e);
         }
         InputReader in = new InputReader(inputStream);
         OutputWriter out = new OutputWriter(outputStream);
         TaskD solver = new TaskD();
         solver.solve(1, in, out);
         out.close();
     }
 
     static class TaskD {
         public void solve(int testNumber, InputReader in, OutputWriter out) {
             Scheduler scheduler = new Scheduler(in, out, () -> new Task() {
                 int c;
                 int r;
                 int m;
                 char[][] map;
 
 
                 public void read(InputReader in) {
                     c = in.readInt();
                     r = in.readInt();
                     m = in.readInt();
                     map = IOUtils.readTable(in, r, c);
                 }
 
                 int answer;
                 int[] sold;
                 int[] turr;
 
 
                 public void solve() {
                     int[][] soldierId = new int[r][c];
                     int[][] turretId = new int[r][c];
                     ArrayUtils.fill(soldierId, -1);
                     ArrayUtils.fill(turretId, -1);
                     int soldierCount = 0;
                     int turretCount = 0;
                     List<IntIntPair> soldier = new ArrayList<>();
                     for (int i = 0; i < r; i++) {
                         for (int j = 0; j < c; j++) {
                             if (map[i][j] == 'S') {
                                 soldierId[i][j] = soldierCount++;
                                 soldier.add(new IntIntPair(i, j));
                                 map[i][j] = '.';
                             } else if (map[i][j] == 'T') {
                                 turretId[i][j] = turretCount++;
                             }
                         }
                     }
                     List<IntIntPair>[][] path = new List[soldierCount][turretCount];
                     IntIntPair[][] last = new IntIntPair[r][c];
                     IntList[][] attackedBy = new IntList[r][c];
                     for (int i = 0; i < r; i++) {
                         for (int j = 0; j < c; j++) {
                             attackedBy[i][j] = new IntArrayList();
                             for (int k = 0; k < 4; k++) {
                                 int cr = i + MiscUtils.DX4[k];
                                 int cc = j + MiscUtils.DY4[k];
                                 while (MiscUtils.isValidCell(cr, cc, r, c) && map[cr][cc] != '#') {
                                     if (map[cr][cc] == 'T') {
                                         attackedBy[i][j].add(turretId[cr][cc]);
                                     }
                                     cr += MiscUtils.DX4[k];
                                     cc += MiscUtils.DY4[k];
                                 }
                             }
                         }
                     }
                     int[][] distance = new int[r][c];
                     for (int i = 0; i < soldierCount; i++) {
                         Queue<IntIntPair> queue = new ArrayDeque<>();
                         ArrayUtils.fill(distance, -1);
                         IntIntPair cSoldier = soldier.get(i);
                         distance[cSoldier.first][cSoldier.second] = 0;
                         last[cSoldier.first][cSoldier.second] = null;
                         queue.add(cSoldier);
                         while (!queue.isEmpty()) {
                             int cr = queue.peek().first;
                             int cc = queue.poll().second;
                             for (int j : attackedBy[cr][cc]) {
                                 if (path[i][j] == null) {
                                     path[i][j] = new ArrayList<>();
                                     IntIntPair key = new IntIntPair(cr, cc);
                                     while (key != null) {
                                         key = last[key.first][key.second];
                                         if (key != null) {
                                             path[i][j].add(key);
                                         }
                                     }
                                     Collections.reverse(path[i][j]);
                                 }
                             }
                             if (distance[cr][cc] == m) {
                                 continue;
                             }
                             for (int j = 0; j < 4; j++) {
                                 int nr = cr + MiscUtils.DX4[j];
                                 int nc = cc + MiscUtils.DY4[j];
                                 if (MiscUtils.isValidCell(nr, nc, r, c) && distance[nr][nc] == -1 &&
                                         map[nr][nc] != '#') {
                                     queue.add(new IntIntPair(nr, nc));
                                     last[nr][nc] = new IntIntPair(cr, cc);
                                     distance[nr][nc] = distance[cr][cc] + 1;
                                 }
                             }
                         }
                     }
                     Graph graph = new Graph(soldierCount + turretCount + 2);
                     int source = soldierCount + turretCount;
                     int sink = source + 1;
                     for (int i = 0; i < soldierCount; i++) {
                         graph.addFlowEdge(source, i, 1);
                         for (int j = 0; j < turretCount; j++) {
                             if (path[i][j] != null) {
                                 graph.addFlowEdge(i, j + soldierCount, 1);
                             }
                         }
                     }
                     for (int i = 0; i < turretCount; i++) {
                         graph.addFlowEdge(i + soldierCount, sink, 1);
                     }
                     answer = (int) MaxFlow.dinic(graph, source, sink);
                     sold = new int[answer];
                     turr = new int[answer];
                     int[] toShoot = ArrayUtils.createArray(soldierCount, -1);
                     int[] shootBy = ArrayUtils.createArray(turretCount, -1);
                     for (int i = 0; i < soldierCount; i++) {
                         for (int j = graph.firstOutbound(i); j != -1; j = graph.nextOutbound(j)) {
                             if (graph.flow(j) > 0 && graph.destination(j) < source) {
                                 toShoot[i] = graph.destination(j) - soldierCount;
                                 shootBy[graph.destination(j) - soldierCount] = i;
                             }
                         }
                     }
                     int[] step = new int[soldierCount];
                     boolean[] killed = new boolean[turretCount];
                     int[] blockedBy = new int[soldierCount];
                     int[] queue = new int[soldierCount];
                     boolean[] inQueue = new boolean[soldierCount];
                     int[] idInQueue = new int[soldierCount];
                     int aAt = 0;
                     for (int i = 0; i < soldierCount; i++) {
                         if (toShoot[i] != -1) {
                             int size = 1;
                             queue[0] = i;
                             idInQueue[i] = 0;
                             inQueue[i] = true;
                             while (size != 0) {
                                 int current = queue[size - 1];
                                 int cTurr = toShoot[current];
                                 if (step[current] == path[current][cTurr].size()) {
                                     inQueue[current] = false;
                                     sold[aAt] = current;
                                     turr[aAt++] = cTurr;
                                     killed[cTurr] = true;
                                     toShoot[current] = -1;
                                     shootBy[cTurr] = -1;
                                     size--;
                                     continue;
                                 }
                                 int cr = path[current][cTurr].get(step[current]).first;
                                 int cc = path[current][cTurr].get(step[current]).second;
                                 boolean good = true;
                                 for (int j : attackedBy[cr][cc]) {
                                     if (killed[j]) {
                                         continue;
                                     }
                                     if (shootBy[j] == -1) {
                                         inQueue[current] = false;
                                         sold[aAt] = current;
                                         turr[aAt++] = j;
                                         killed[j] = true;
                                         toShoot[current] = -1;
                                         shootBy[cTurr] = -1;
                                         size--;
                                         good = false;
                                         break;
                                     } else if (inQueue[shootBy[j]]) {
                                         blockedBy[size - 1] = j;
                                         int start = idInQueue[shootBy[j]];
                                         for (int k = start; k < size; k++) {
                                             inQueue[queue[k]] = false;
                                             sold[aAt] = queue[k];
                                             turr[aAt++] = blockedBy[k];
                                             killed[blockedBy[k]] = true;
                                             toShoot[queue[k]] = -1;
                                             shootBy[blockedBy[k]] = -1;
                                         }
                                         size = start;
                                         good = false;
                                         break;
                                     } else {
                                         blockedBy[size - 1] = j;
                                         queue[size] = shootBy[j];
                                         idInQueue[shootBy[j]] = size++;
                                         inQueue[shootBy[j]] = true;
                                         good = false;
                                         break;
                                     }
                                 }
                                 if (good) {
                                     step[current]++;
                                 }
                             }
                         }
                     }
                 }
 
 
                 public void write(OutputWriter out, int testNumber) {
                     out.printLine("Case #" + testNumber + ":", answer);
                     for (int i = 0; i < answer; i++) {
                         out.printLine(sold[i] + 1, turr[i] + 1);
                     }
                 }
             }, 4);
         }
 
     }
 
     static interface IntQueue extends IntCollection {
         public int poll();
 
     }
 
     static interface Edge {
     }
 
     static interface IntStream extends Iterable<Integer>, Comparable<IntStream> {
         public IntIterator intIterator();
 
         default public Iterator<Integer> iterator() {
             return new Iterator<Integer>() {
                 private IntIterator it = intIterator();
 
                 public boolean hasNext() {
                     return it.isValid();
                 }
 
                 public Integer next() {
                     int result = it.value();
                     it.advance();
                     return result;
                 }
             };
         }
 
         default public int compareTo(IntStream c) {
             IntIterator it = intIterator();
             IntIterator jt = c.intIterator();
             while (it.isValid() && jt.isValid()) {
                 int i = it.value();
                 int j = jt.value();
                 if (i < j) {
                     return -1;
                 } else if (i > j) {
                     return 1;
                 }
                 it.advance();
                 jt.advance();
             }
             if (it.isValid()) {
                 return 1;
             }
             if (jt.isValid()) {
                 return -1;
             }
             return 0;
         }
 
     }
 
     static class InputReader {
         private InputStream stream;
         private byte[] buf = new byte[1024];
         private int curChar;
         private int numChars;
         private InputReader.SpaceCharFilter filter;
 
         public InputReader(InputStream stream) {
             this.stream = stream;
         }
 
         public int read() {
             if (numChars == -1) {
                 throw new InputMismatchException();
             }
             if (curChar >= numChars) {
                 curChar = 0;
                 try {
                     numChars = stream.read(buf);
                 } catch (IOException e) {
                     throw new InputMismatchException();
                 }
                 if (numChars <= 0) {
                     return -1;
                 }
             }
             return buf[curChar++];
         }
 
         public int readInt() {
             int c = read();
             while (isSpaceChar(c)) {
                 c = read();
             }
             int sgn = 1;
             if (c == '-') {
                 sgn = -1;
                 c = read();
             }
             int res = 0;
             do {
                 if (c < '0' || c > '9') {
                     throw new InputMismatchException();
                 }
                 res *= 10;
                 res += c - '0';
                 c = read();
             } while (!isSpaceChar(c));
             return res * sgn;
         }
 
         public boolean isSpaceChar(int c) {
             if (filter != null) {
                 return filter.isSpaceChar(c);
             }
             return isWhitespace(c);
         }
 
         public static boolean isWhitespace(int c) {
             return c == ' ' || c == '\n' || c == '\r' || c == '\t' || c == -1;
         }
 
         public char readCharacter() {
             int c = read();
             while (isSpaceChar(c)) {
                 c = read();
             }
             return (char) c;
         }
 
         public interface SpaceCharFilter {
             public boolean isSpaceChar(int ch);
 
         }
 
     }
 
     static class IOUtils {
         public static char[] readCharArray(InputReader in, int size) {
             char[] array = new char[size];
             for (int i = 0; i < size; i++) {
                 array[i] = in.readCharacter();
             }
             return array;
         }
 
         public static char[][] readTable(InputReader in, int rowCount, int columnCount) {
             char[][] table = new char[rowCount][];
             for (int i = 0; i < rowCount; i++) {
                 table[i] = readCharArray(in, columnCount);
             }
             return table;
         }
 
     }
 
     static class MaxFlow {
         private final Graph graph;
         private int source;
         private int destination;
         private IntQueue queue;
         private int[] distance;
         private int[] nextEdge;
 
         public MaxFlow(Graph graph, int source, int destination) {
             this.graph = graph;
             this.source = source;
             this.destination = destination;
             int vertexCount = graph.vertexCount();
             queue = new IntArrayQueue(vertexCount);
             distance = new int[vertexCount];
             nextEdge = new int[vertexCount];
         }
 
         public static long dinic(Graph graph, int source, int destination) {
             return new MaxFlow(graph, source, destination).dinic();
         }
 
         public long dinic() {
             long totalFlow = 0;
             while (true) {
                 edgeDistances();
                 if (distance[destination] == -1) {
                     break;
                 }
                 Arrays.fill(nextEdge, -2);
                 totalFlow += dinicImpl(source, Long.MAX_VALUE);
             }
             return totalFlow;
         }
 
         private void edgeDistances() {
             Arrays.fill(distance, -1);
             distance[source] = 0;
             queue.add(source);
             while (!queue.isEmpty()) {
                 int current = queue.poll();
                 int id = graph.firstOutbound(current);
                 while (id != -1) {
                     if (graph.capacity(id) != 0) {
                         int next = graph.destination(id);
                         if (distance[next] == -1) {
                             distance[next] = distance[current] + 1;
                             queue.add(next);
                         }
                     }
                     id = graph.nextOutbound(id);
                 }
             }
         }
 
         private long dinicImpl(int source, long flow) {
             if (source == destination) {
                 return flow;
             }
             if (flow == 0 || distance[source] == distance[destination]) {
                 return 0;
             }
             int id = nextEdge[source];
             if (id == -2) {
                 nextEdge[source] = id = graph.firstOutbound(source);
             }
             long totalPushed = 0;
             while (id != -1) {
                 int nextDestinationID = graph.destination(id);
                 if (graph.capacity(id) != 0 && distance[nextDestinationID] == distance[source] + 1) {
                     long pushed = dinicImpl(nextDestinationID, Math.min(flow, graph.capacity(id)));
                     if (pushed != 0) {
                         graph.pushFlow(id, pushed);
                         flow -= pushed;
                         totalPushed += pushed;
                         if (flow == 0) {
                             return totalPushed;
                         }
                     }
                 }
                 nextEdge[source] = id = graph.nextOutbound(id);
             }
             return totalPushed;
         }
 
     }
 
     static class Scheduler {
         private final AtomicInteger testsRemaining;
         private final AtomicInteger threadsRemaining;
 
         public Scheduler(InputReader in, OutputWriter out, TaskFactory factory, int numParallel) {
             try {
                 testsRemaining = new AtomicInteger(in.readInt());
                 threadsRemaining = new AtomicInteger(numParallel);
                 Task[] tasks = new Task[testsRemaining.get()];
                 for (int i = 0; i < tasks.length; i++) {
                     tasks[i] = factory.newTask();
                 }
                 for (Task task : tasks) {
                     task.read(in);
                     new Thread(() -> {
                         boolean freeThread = false;
                         synchronized (this) {
                             do {
                                 try {
                                     wait(10);
                                 } catch (InterruptedException ignored) {
                                 }
                                 if (threadsRemaining.get() != 0) {
                                     synchronized (threadsRemaining) {
                                         if (threadsRemaining.get() != 0) {
                                             threadsRemaining.decrementAndGet();
                                             freeThread = true;
                                         }
                                     }
                                 }
                             } while (!freeThread);
                         }
                         task.solve();
                         System.err.println(testsRemaining.decrementAndGet());
                         threadsRemaining.incrementAndGet();
                     }).start();
                 }
                 synchronized (this) {
                     while (testsRemaining.get() > 0) {
                         wait(10);
                     }
                 }
                 for (int i = 0; i < tasks.length; i++) {
                     tasks[i].write(out, i + 1);
                 }
             } catch (InterruptedException e) {
                 throw new RuntimeException(e);
             }
         }
 
     }
 
     static class ArrayUtils {
         public static void fill(int[][] array, int value) {
             for (int[] row : array) {
                 Arrays.fill(row, value);
             }
         }
 
         public static int[] createArray(int count, int value) {
             int[] array = new int[count];
             Arrays.fill(array, value);
             return array;
         }
 
     }
 
     static interface IntIterator {
         public int value() throws NoSuchElementException;
 
         public boolean advance();
 
         public boolean isValid();
 
     }
 
     static interface IntList extends IntReversableCollection {
         public abstract int get(int index);
 
         public abstract void addAt(int index, int value);
 
         public abstract void removeAt(int index);
 
         default public IntIterator intIterator() {
             return new IntIterator() {
                 private int at;
                 private boolean removed;
 
                 public int value() {
                     if (removed) {
                         throw new IllegalStateException();
                     }
                     return get(at);
                 }
 
                 public boolean advance() {
                     at++;
                     removed = false;
                     return isValid();
                 }
 
                 public boolean isValid() {
                     return !removed && at < size();
                 }
 
                 public void remove() {
                     removeAt(at);
                     at--;
                     removed = true;
                 }
             };
         }
 
 
         default public void add(int value) {
             addAt(size(), value);
         }
 
     }
 
     static interface IntReversableCollection extends IntCollection {
     }
 
     static abstract class IntAbstractStream implements IntStream {
 
         public String toString() {
             StringBuilder builder = new StringBuilder();
             boolean first = true;
             for (IntIterator it = intIterator(); it.isValid(); it.advance()) {
                 if (first) {
                     first = false;
                 } else {
                     builder.append(' ');
                 }
                 builder.append(it.value());
             }
             return builder.toString();
         }
 
 
         public boolean equals(Object o) {
             if (!(o instanceof IntStream)) {
                 return false;
             }
             IntStream c = (IntStream) o;
             IntIterator it = intIterator();
             IntIterator jt = c.intIterator();
             while (it.isValid() && jt.isValid()) {
                 if (it.value() != jt.value()) {
                     return false;
                 }
                 it.advance();
                 jt.advance();
             }
             return !it.isValid() && !jt.isValid();
         }
 
 
         public int hashCode() {
             int result = 0;
             for (IntIterator it = intIterator(); it.isValid(); it.advance()) {
                 result *= 31;
                 result += it.value();
             }
             return result;
         }
 
     }
 
     static class IntArrayList extends IntAbstractStream implements IntList {
         private int size;
         private int[] data;
 
         public IntArrayList() {
             this(3);
         }
 
         public IntArrayList(int capacity) {
             data = new int[capacity];
         }
 
         public IntArrayList(IntCollection c) {
             this(c.size());
             addAll(c);
         }
 
         public IntArrayList(IntStream c) {
             this();
             if (c instanceof IntCollection) {
                 ensureCapacity(((IntCollection) c).size());
             }
             addAll(c);
         }
 
         public IntArrayList(IntArrayList c) {
             size = c.size();
             data = c.data.clone();
         }
 
         public IntArrayList(int[] arr) {
             size = arr.length;
             data = arr.clone();
         }
 
         public int size() {
             return size;
         }
 
         public int get(int at) {
             if (at >= size) {
                 throw new IndexOutOfBoundsException("at = " + at + ", size = " + size);
             }
             return data[at];
         }
 
         private void ensureCapacity(int capacity) {
             if (data.length >= capacity) {
                 return;
             }
             capacity = Math.max(2 * data.length, capacity);
             data = Arrays.copyOf(data, capacity);
         }
 
         public void addAt(int index, int value) {
             ensureCapacity(size + 1);
             if (index > size || index < 0) {
                 throw new IndexOutOfBoundsException("at = " + index + ", size = " + size);
             }
             if (index != size) {
                 System.arraycopy(data, index, data, index + 1, size - index);
             }
             data[index] = value;
             size++;
         }
 
         public void removeAt(int index) {
             if (index >= size || index < 0) {
                 throw new IndexOutOfBoundsException("at = " + index + ", size = " + size);
             }
             if (index != size - 1) {
                 System.arraycopy(data, index + 1, data, index, size - index - 1);
             }
             size--;
         }
 
     }
 
     static interface IntCollection extends IntStream {
         public int size();
 
         default public boolean isEmpty() {
             return size() == 0;
         }
 
         default public void add(int value) {
             throw new UnsupportedOperationException();
         }
 
         default public IntCollection addAll(IntStream values) {
             for (IntIterator it = values.intIterator(); it.isValid(); it.advance()) {
                 add(it.value());
             }
             return this;
         }
 
     }
 
     static class Graph {
         public static final int REMOVED_BIT = 0;
         protected int vertexCount;
         protected int edgeCount;
         private int[] firstOutbound;
         private int[] firstInbound;
         private Edge[] edges;
         private int[] nextInbound;
         private int[] nextOutbound;
         private int[] from;
         private int[] to;
         private long[] weight;
         public long[] capacity;
         private int[] reverseEdge;
         private int[] flags;
 
         public Graph(int vertexCount) {
             this(vertexCount, vertexCount);
         }
 
         public Graph(int vertexCount, int edgeCapacity) {
             this.vertexCount = vertexCount;
             firstOutbound = new int[vertexCount];
             Arrays.fill(firstOutbound, -1);
 
             from = new int[edgeCapacity];
             to = new int[edgeCapacity];
             nextOutbound = new int[edgeCapacity];
             flags = new int[edgeCapacity];
         }
 
         public int addEdge(int fromID, int toID, long weight, long capacity, int reverseEdge) {
             ensureEdgeCapacity(edgeCount + 1);
             if (firstOutbound[fromID] != -1) {
                 nextOutbound[edgeCount] = firstOutbound[fromID];
             } else {
                 nextOutbound[edgeCount] = -1;
             }
             firstOutbound[fromID] = edgeCount;
             if (firstInbound != null) {
                 if (firstInbound[toID] != -1) {
                     nextInbound[edgeCount] = firstInbound[toID];
                 } else {
                     nextInbound[edgeCount] = -1;
                 }
                 firstInbound[toID] = edgeCount;
             }
             this.from[edgeCount] = fromID;
             this.to[edgeCount] = toID;
             if (capacity != 0) {
                 if (this.capacity == null) {
                     this.capacity = new long[from.length];
                 }
                 this.capacity[edgeCount] = capacity;
             }
             if (weight != 0) {
                 if (this.weight == null) {
                     this.weight = new long[from.length];
                 }
                 this.weight[edgeCount] = weight;
             }
             if (reverseEdge != -1) {
                 if (this.reverseEdge == null) {
                     this.reverseEdge = new int[from.length];
                     Arrays.fill(this.reverseEdge, 0, edgeCount, -1);
                 }
                 this.reverseEdge[edgeCount] = reverseEdge;
             }
             if (edges != null) {
                 edges[edgeCount] = createEdge(edgeCount);
             }
             return edgeCount++;
         }
 
         protected final GraphEdge createEdge(int id) {
             return new GraphEdge(id);
         }
 
         public final int addFlowWeightedEdge(int from, int to, long weight, long capacity) {
             if (capacity == 0) {
                 return addEdge(from, to, weight, 0, -1);
             } else {
                 int lastEdgeCount = edgeCount;
                 addEdge(to, from, -weight, 0, lastEdgeCount + entriesPerEdge());
                 return addEdge(from, to, weight, capacity, lastEdgeCount);
             }
         }
 
         protected int entriesPerEdge() {
             return 1;
         }
 
         public final int addFlowEdge(int from, int to, long capacity) {
             return addFlowWeightedEdge(from, to, 0, capacity);
         }
 
         public final int vertexCount() {
             return vertexCount;
         }
 
         public final int firstOutbound(int vertex) {
             int id = firstOutbound[vertex];
             while (id != -1 && isRemoved(id)) {
                 id = nextOutbound[id];
             }
             return id;
         }
 
         public final int nextOutbound(int id) {
             id = nextOutbound[id];
             while (id != -1 && isRemoved(id)) {
                 id = nextOutbound[id];
             }
             return id;
         }
 
         public final int destination(int id) {
             return to[id];
         }
 
         public final long capacity(int id) {
             if (capacity == null) {
                 return 0;
             }
             return capacity[id];
         }
 
         public final long flow(int id) {
             if (reverseEdge == null) {
                 return 0;
             }
             return capacity[reverseEdge[id]];
         }
 
         public final void pushFlow(int id, long flow) {
             if (flow == 0) {
                 return;
             }
             if (flow > 0) {
                 if (capacity(id) < flow) {
                     throw new IllegalArgumentException("Not enough capacity");
                 }
             } else {
                 if (flow(id) < -flow) {
                     throw new IllegalArgumentException("Not enough capacity");
                 }
             }
             capacity[id] -= flow;
             capacity[reverseEdge[id]] += flow;
         }
 
         public final boolean flag(int id, int bit) {
             return (flags[id] >> bit & 1) != 0;
         }
 
         public final boolean isRemoved(int id) {
             return flag(id, REMOVED_BIT);
         }
 
         protected void ensureEdgeCapacity(int size) {
             if (from.length < size) {
                 int newSize = Math.max(size, 2 * from.length);
                 if (edges != null) {
                     edges = resize(edges, newSize);
                 }
                 from = resize(from, newSize);
                 to = resize(to, newSize);
                 nextOutbound = resize(nextOutbound, newSize);
                 if (nextInbound != null) {
                     nextInbound = resize(nextInbound, newSize);
                 }
                 if (weight != null) {
                     weight = resize(weight, newSize);
                 }
                 if (capacity != null) {
                     capacity = resize(capacity, newSize);
                 }
                 if (reverseEdge != null) {
                     reverseEdge = resize(reverseEdge, newSize);
                 }
                 flags = resize(flags, newSize);
             }
         }
 
         protected final int[] resize(int[] array, int size) {
             int[] newArray = new int[size];
             System.arraycopy(array, 0, newArray, 0, array.length);
             return newArray;
         }
 
         private long[] resize(long[] array, int size) {
             long[] newArray = new long[size];
             System.arraycopy(array, 0, newArray, 0, array.length);
             return newArray;
         }
 
         private Edge[] resize(Edge[] array, int size) {
             Edge[] newArray = new Edge[size];
             System.arraycopy(array, 0, newArray, 0, array.length);
             return newArray;
         }
 
         protected class GraphEdge implements Edge {
             protected int id;
 
             protected GraphEdge(int id) {
                 this.id = id;
             }
 
         }
 
     }
 
     static class IntIntPair implements Comparable<IntIntPair> {
         public final int first;
         public final int second;
 
         public IntIntPair(int first, int second) {
             this.first = first;
             this.second = second;
         }
 
 
         public boolean equals(Object o) {
             if (this == o) {
                 return true;
             }
             if (o == null || getClass() != o.getClass()) {
                 return false;
             }
 
             IntIntPair pair = (IntIntPair) o;
 
             return first == pair.first && second == pair.second;
         }
 
 
         public int hashCode() {
             int result = first;
             result = 31 * result + second;
             return result;
         }
 
 
         public String toString() {
             return "(" + first + "," + second + ")";
         }
 
         @SuppressWarnings({"unchecked"})
         public int compareTo(IntIntPair o) {
             int value = Integer.compare(first, o.first);
             if (value != 0) {
                 return value;
             }
             return Integer.compare(second, o.second);
         }
 
     }
 
     static interface Task {
         public void read(InputReader in);
 
         public void solve();
 
         public void write(OutputWriter out, int testNumber);
 
     }
 
     static class OutputWriter {
         private final PrintWriter writer;
 
         public OutputWriter(OutputStream outputStream) {
             writer = new PrintWriter(new BufferedWriter(new OutputStreamWriter(outputStream)));
         }
 
         public OutputWriter(Writer writer) {
             this.writer = new PrintWriter(writer);
         }
 
         public void print(Object... objects) {
             for (int i = 0; i < objects.length; i++) {
                 if (i != 0) {
                     writer.print(' ');
                 }
                 writer.print(objects[i]);
             }
         }
 
         public void printLine(Object... objects) {
             print(objects);
             writer.println();
         }
 
         public void close() {
             writer.close();
         }
 
     }
 
     static class MiscUtils {
         public static final int[] DX4 = {1, 0, -1, 0};
         public static final int[] DY4 = {0, -1, 0, 1};
 
         public static boolean isValidCell(int row, int column, int rowCount, int columnCount) {
             return row >= 0 && row < rowCount && column >= 0 && column < columnCount;
         }
 
     }
 
     static class IntArrayQueue implements IntQueue {
         private int[] data;
         private int from;
         private int to;
 
         public IntArrayQueue(int capacity) {
             data = new int[Integer.highestOneBit(capacity) << 1];
         }
 
         public IntArrayQueue() {
             this(3);
         }
 
         public IntArrayQueue(int[] array) {
             this(array.length);
             to = array.length;
             System.arraycopy(array, 0, data, 0, to);
         }
 
         public IntArrayQueue(IntStream s) {
             addAll(s);
         }
 
         public IntArrayQueue(IntCollection c) {
             this(c.size());
             addAll(c);
         }
 
         public int size() {
             return (to - from) & (data.length - 1);
         }
 
         public void add(int v) {
             ensureCapacity(size() + 1);
             data[to++] = v;
             to &= data.length - 1;
         }
 
         public int poll() {
             if (from == to) {
                 throw new NoSuchElementException();
             }
             int result = data[from++];
             from &= data.length - 1;
             return result;
         }
 
         public IntIterator intIterator() {
             return new IntIterator() {
                 private int at = from;
 
                 public int value() {
                     if (at == to) {
                         throw new NoSuchElementException();
                     }
                     return data[at];
                 }
 
                 public boolean advance() {
                     if (!isValid()) {
                         throw new NoSuchElementException();
                     }
                     at++;
                     at &= data.length - 1;
                     return isValid();
                 }
 
                 public boolean isValid() {
                     return at != to;
                 }
 
                 public void remove() {
                     throw new UnsupportedOperationException();
                 }
             };
         }
 
         private void ensureCapacity(int capacity) {
             if (data.length <= capacity) {
                 int[] newData = new int[Integer.highestOneBit(capacity) << 1];
                 if (from <= to) {
                     System.arraycopy(data, from, newData, 0, size());
                 } else {
                     System.arraycopy(data, from, newData, 0, data.length - from);
                     System.arraycopy(data, 0, newData, data.length - from, to);
                 }
                 to = size();
                 from = 0;
                 data = newData;
             }
         }
 
     }
 
     static interface TaskFactory {
         public Task newTask();
 
     }
 }
 
