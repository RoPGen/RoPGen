package abtric.round1b;
 
 import java.io.IOException;
 import java.nio.file.FileSystems;
 import java.nio.file.Files;
 import java.util.ArrayList;
 import java.util.Collections;
 import java.util.HashMap;
 import java.util.List;
 
 import abtric.utility.Writer;
 
 public class GettingTheDigits {
    public static void main(String[] args) {
        
        String stringPath = "A-small-attempt1.in";
        
        try {
            final List<String> inputFile = Files
                    .readAllLines(FileSystems.getDefault().getPath("in\\GettingTheDigits", stringPath));
            
            final int T = Integer.parseInt(inputFile.get(0));
            String[] results = new String[T];
            for (int i = 0; i < T; i++) {
                
                final String S = inputFile.get(i + 1);
                HashMap<Character, Integer> counts = new HashMap<>();
                counts.put('O', 0);
                counts.put('N', 0);
                counts.put('E', 0);
                counts.put('T', 0);
                counts.put('W', 0);
                counts.put('H', 0);
                counts.put('R', 0);
                counts.put('F', 0);
                counts.put('U', 0);
                counts.put('I', 0);
                counts.put('V', 0);
                counts.put('S', 0);
                counts.put('X', 0);
                counts.put('G', 0);
                counts.put('Z', 0);
 
                for (int j = 0; j < S.length(); j++) {
                    char charAt = S.charAt(j);
                    counts.put(charAt, counts.get(charAt) + 1);
                }
 
                ArrayList<Integer> digits = new ArrayList<>();
 
                if (counts.get('Z') > 0) {
                    for (int j = 0; j < counts.get('Z'); j++) {
                        digits.add(0);
                    }
                    counts.put('E', counts.get('E') - counts.get('Z'));
                    counts.put('R', counts.get('R') - counts.get('Z'));
                    counts.put('O', counts.get('O') - counts.get('Z'));
                    counts.put('Z', 0);
                }
                if (counts.get('X') > 0) {
                    for (int j = 0; j < counts.get('X'); j++) {
                        digits.add(6);
                    }
                    counts.put('S', counts.get('S') - counts.get('X'));
                    counts.put('I', counts.get('I') - counts.get('X'));
                    counts.put('X', 0);
                }
                if (counts.get('W') > 0) {
                    for (int j = 0; j < counts.get('W'); j++) {
                        digits.add(2);
                    }
                    counts.put('T', counts.get('T') - counts.get('W'));
                    counts.put('O', counts.get('O') - counts.get('W'));
                    counts.put('W', 0);
                }
                if (counts.get('U') > 0) {
                    for (int j = 0; j < counts.get('U'); j++) {
                        digits.add(4);
                    }
                    counts.put('F', counts.get('F') - counts.get('U'));
                    counts.put('O', counts.get('O') - counts.get('U'));
                    counts.put('R', counts.get('R') - counts.get('U'));
                    counts.put('U', 0);
                }
                if (counts.get('F') > 0) {
                    for (int j = 0; j < counts.get('F'); j++) {
                        digits.add(5);
                    }
                    counts.put('I', counts.get('I') - counts.get('F'));
                    counts.put('V', counts.get('V') - counts.get('F'));
                    counts.put('E', counts.get('E') - counts.get('F'));
                    counts.put('F', 0);
                }
                if (counts.get('O') > 0) {
                    for (int j = 0; j < counts.get('O'); j++) {
                        digits.add(1);
                    }
                    counts.put('N', counts.get('N') - counts.get('O'));
                    counts.put('E', counts.get('E') - counts.get('O'));
                    counts.put('O', 0);
                }
                if (counts.get('R') > 0) {
                    for (int j = 0; j < counts.get('R'); j++) {
                        digits.add(3);
                    }
                    counts.put('T', counts.get('T') - counts.get('R'));
                    counts.put('H', counts.get('H') - counts.get('R'));
                    counts.put('E', counts.get('E') - counts.get('R'));
                    counts.put('E', counts.get('E') - counts.get('R'));
                    counts.put('R', 0);
                }
                if (counts.get('V') > 0) {
                    for (int j = 0; j < counts.get('V'); j++) {
                        digits.add(7);
                    }
                    counts.put('S', counts.get('S') - counts.get('V'));
                    counts.put('E', counts.get('E') - counts.get('V'));
                    counts.put('E', counts.get('E') - counts.get('V'));
                    counts.put('N', counts.get('N') - counts.get('V'));
                    counts.put('V', 0);
                }
                if (counts.get('G') > 0) {
                    for (int j = 0; j < counts.get('G'); j++) {
                        digits.add(8);
                    }
                    counts.put('E', counts.get('E') - counts.get('G'));
                    counts.put('I', counts.get('I') - counts.get('G'));
                    counts.put('H', counts.get('H') - counts.get('G'));
                    counts.put('T', counts.get('T') - counts.get('G'));
                    counts.put('G', 0);
                }
                if (counts.get('N') > 0) {
                    for (int j = 0; j < counts.get('N')/2; j++) {
                        digits.add(9);
                    }
                    counts.put('I', counts.get('I') - counts.get('N'));
                    counts.put('E', counts.get('E') - counts.get('N'));
                    counts.put('N', 0);
                }
 
                Collections.sort(digits);
                results[i] = "";
                for (int j = 0; j < digits.size(); j++) {
                    results[i] += digits.get(j).toString();
                }
            }
            
            Writer.write("out\\GettingTheDigits-small.out", results);
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
 }
