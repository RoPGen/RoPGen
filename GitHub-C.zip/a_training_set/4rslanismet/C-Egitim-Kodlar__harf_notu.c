



#include <stdio.h>

int main ()
{
    
    int n;
    
    printf("ders notunuzu 0-100 arasında giriniz:");
    scanf("%d",&n);
    
    if (n<=100 && n>=0)
    {
            
        if(90<=n)
            printf("harf notunuz A");
    
    
        else if(80<=n && n<90)
            printf("harf notunuz B");
    
    
        else if(70<=n && n<80)
            printf("harf notunuz C");   
        
        else 
            printf("harf notunuz F");
    }
    
    else 
    {
        printf("girilen değer tanımsız");
        return 1;
    }
    
    return 0;
    }
