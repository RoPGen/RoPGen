
 package durazom.util;
 
 
 public interface Case {
     
     public String solve(String line);
     
 }
