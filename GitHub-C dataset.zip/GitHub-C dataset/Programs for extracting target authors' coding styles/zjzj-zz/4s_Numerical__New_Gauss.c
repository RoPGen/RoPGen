#include <stdio.h>
#include <math.h>
#define error 0.0000000001 

int i, j, k;

void initial_value( int N, double x[N] ){ 
    for( i = 0; i < N; i++ ) x[i] = 1.0;
}

void Seidel( int N, double x[N], double  y[N], double a[N][N], double b[N]){ 
    for( j = 0; j < N; j++ ){
        for( k = 0; k < N; k++ ) y[k] = x[k];
        x[j] = ( (a[j][j] * y[j]) + b[j] );
        for( k = 0; k < N; k++ ) x[j] -= ( a[j][k] * y[k] );
        x[j] /= a[j][j];
    }
}

int Convergence_test( int N, double x[N], double y[N] ){ 
    for( j = 0; j < N; j++ ){
        if( error < fabs( x[j] - y[j] ))return (1);
    }
    return (0);
}

int main(){ 
    FILE *fp; 

    fp = fopen("gyo.txt", "r" );
    if( fp == NULL ){
        printf("gyo.txtを準備して下さい\n");
        return -1;
    }
    int N;
    fscanf( fp, "%d", &N );
    double a[N][N]; 
    double b[N]; 
    for( i = 0; i < N; i++ ){
        for( j = 0; j < N; j++ ){
            fscanf( fp, "%lf", &a[i][j] );
        }
    }
    for( i = 0; i < N; i++ ){
        fscanf( fp, "%lf", &b[i] );
    }
    fclose( fp );
    double x[N], y[N];
    int c = 0;

    initial_value( N, x );
    while( Convergence_test( N, x, y ) ){ 
        Seidel( N, x, y, a, b );
        c++; 
    }
    printf("[%3d週目] ", c );
    for( i = 0; i < N; i++) printf(" x%d = %.10f ", i+1, x[i] );
    putchar('\n');
    return 0;
}


