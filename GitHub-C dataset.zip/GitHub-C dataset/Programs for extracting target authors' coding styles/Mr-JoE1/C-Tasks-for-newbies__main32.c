



#include <stdio.h>
#include <stdlib.h>

int main()
{
    int money;                                                  
    int twenty_bills, five_bills, one_bills;                    
    int remainder;

    printf("Enter Your Money : ");                              
    scanf("%d" , &money);

    twenty_bills = money / 20;
    remainder = money % 20;                                     

    five_bills = remainder / 5;
    remainder = remainder % 5;                                  

    one_bills = remainder;

    printf("Your Money   : %d$\n"
           "20$ Bills    : %d\n"
           "5$  Bills    : %d\n"
           "1$  Bills    : %d\n" , money , twenty_bills , five_bills , one_bills);

    return 0;
}
