#include "binary_trees.h"


int scale(const binary_tree_t *tree)
{
    int ll = 1;
    int lr = 1;

    if (tree == NULL)
    {
        return (-1);
    }
    ll += scale((*tree).left);
    lr += scale((*tree).right);
    if (lr > ll)
    {
        return (lr);
    }
    return (ll);
}


int binary_tree_balance(const binary_tree_t *tree)
{
    int left = 0, right = 0;

    if (tree == NULL)
        return (0);
    left = scale((*tree).left);
    right = scale((*tree).right);
    return (left - right);
}
