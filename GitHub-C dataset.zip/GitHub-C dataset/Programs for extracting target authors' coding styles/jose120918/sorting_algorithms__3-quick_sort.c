#include "sort.h"

int partition(int *array, int low, int high, size_t size)
{
    int pivot, wall, i = low, swap_temp;

    pivot = array[high];
    wall = low - 1;

    while (i <= high)
    {
        if (array[i] <= pivot)
        {
            wall++;
            if (wall != i)
            {
                swap_temp = array[wall];
                array[wall] = array[i];
                array[i] = swap_temp;
                print_array(array, size);
            }
        }
        i++;
    }
    return (wall);
}


void quick_sort_lomuto(int *array, int low, int high, size_t size)
{
    int par_i;

    if (low > high)
        return;

    par_i = partition(array, low, high, size);

    quick_sort_lomuto(array, low, par_i - 1, size);
    quick_sort_lomuto(array, par_i + 1, high, size);
}


void quick_sort(int *array, size_t size)
{
    quick_sort_lomuto(array, 0, size - 1, size);
}
