#include "binary_trees.h"



int binary_tree_balance(const binary_tree_t *tree)
{
    int diff;

    if (tree == NULL)
    {
        return (0);
    }

    diff = 0;
    diff = calc_diff(tree, tree, diff);
    return (diff);
}



int calc_diff(const binary_tree_t *root, const binary_tree_t *tree, int diff)
{
    int right;
    int left;

    right = diff;
    left = diff;

    if (tree == NULL)
    {
        return (0);
    }

    left = left + calc_diff(root, tree->left, left);
    right = right + calc_diff(root, tree->right, right);

    if (root == tree)
    {
        return (left - right);
    }
    if (right > left)
    {
        return (right + 1);
    }
    return (left + 1);
}
