

#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/fs.h>
#include <asm/uaccess.h>    
#include <linux/cdev.h>

MODULE_LICENSE("GPL");


int init_module(void);
void cleanup_module(void);
static int device_open(struct inode *, struct file *);
static int device_release(struct inode *, struct file *);
static ssize_t device_read(struct file *, char *, size_t, loff_t *);
static ssize_t device_write(struct file *, const char *, size_t, loff_t *);

#define SUCCESS 0
#define DEVICE_NAME "chardev"   
#define BUF_LEN 80      



dev_t start;
struct cdev* chardev=NULL;
static int Device_Open = 0; 
static char msg[BUF_LEN];   
static char *msg_Ptr;       
static int counter=0;       

static struct file_operations fops = {
    .read = device_read,
    .write = device_write,
    .open = device_open,
    .release = device_release
};


int init_module(void)
{
    int major;      
    int minor;      
    int ret;

    
    if ((ret=alloc_chrdev_region (&start, 0, 1,DEVICE_NAME))) {
        printk(KERN_INFO "Can't allocate chrdev_region()");
        return ret;
    }

    
    if ((chardev=cdev_alloc())==NULL) {
        printk(KERN_INFO "cdev_alloc() failed ");
        unregister_chrdev_region(start, 1);
        return -ENOMEM;
    }

    cdev_init(chardev,&fops);

    if ((ret=cdev_add(chardev,start,1))) {
        printk(KERN_INFO "cdev_add() failed ");
        kobject_put(&chardev->kobj);
        unregister_chrdev_region(start, 1);
        return ret;
    }

    major=MAJOR(start);
    minor=MINOR(start);

    printk(KERN_INFO "I was assigned major number %d. To talk to\n", major);
    printk(KERN_INFO "the driver, create a dev file with\n");
    printk(KERN_INFO "'sudo mknod -m 666 /dev/%s c %d %d'.\n", DEVICE_NAME, major,minor);
    printk(KERN_INFO "Try to cat and echo to the device file.\n");
    printk(KERN_INFO "Remove the device file and module when done.\n");

    return SUCCESS;
}


void cleanup_module(void)
{
    
    if (chardev)
        cdev_del(chardev);

    
    unregister_chrdev_region(start, 1);
}


static int device_open(struct inode *inode, struct file *file)
{
    if (Device_Open)
        return -EBUSY;

    Device_Open++;

    
    sprintf(msg, "I already told you %d times Hello world!\n", counter++);

    
    msg_Ptr = msg;

    
    try_module_get(THIS_MODULE);

    return SUCCESS;
}


static int device_release(struct inode *inode, struct file *file)
{
    Device_Open--;      

    
    module_put(THIS_MODULE);

    return 0;
}


static ssize_t device_read(struct file *filp,   
                           char *buffer,    
                           size_t length,   
                           loff_t * offset)
{
    
    int bytes_to_read = length;

    
    if (*msg_Ptr == 0)
        return 0;

    
    if (bytes_to_read > strlen(msg_Ptr))
        bytes_to_read=strlen(msg_Ptr);

    
    if (copy_to_user(buffer,msg_Ptr,bytes_to_read))
        return -EFAULT;

    
    msg_Ptr+=bytes_to_read;

    
    return bytes_to_read;
}


static ssize_t
device_write(struct file *filp, const char *buff, size_t len, loff_t * off)
{
    printk(KERN_ALERT "Sorry, this operation isn't supported.\n");
    return -EPERM;
}
