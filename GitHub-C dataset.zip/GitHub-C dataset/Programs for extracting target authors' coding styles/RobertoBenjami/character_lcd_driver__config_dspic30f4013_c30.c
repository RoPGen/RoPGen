#include <p30Fxxxx.h>

 int FOSC __attribute__((space(prog), address(0xF80000))) = 0xC302 ;




 int FWDT __attribute__((space(prog), address(0xF80002))) = 0x3F ;





 int FBORPOR __attribute__((space(prog), address(0xF80004))) = 0x87B3 ;






 int FGS __attribute__((space(prog), address(0xF8000A))) = 0x7 ;




 int FICD __attribute__((space(prog), address(0xF8000C))) = 0xC003 ;





