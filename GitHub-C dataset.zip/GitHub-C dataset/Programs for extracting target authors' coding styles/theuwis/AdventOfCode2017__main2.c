#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void){
    FILE *fp;
    if(!(fp = fopen("data", "r"))){
        fprintf(stderr, "Error opening file\n");
        return EXIT_FAILURE;
    }

    char current_char, compare_char;    
    long answer = 0;                        
    int current_char_index = 0;     

    
    fseek(fp, 0, SEEK_END);
    long file_size = ftell(fp);
    fseek(fp, 0, SEEK_SET);

    
    while((current_char = fgetc(fp)) != EOF){
        
        if(current_char_index < file_size / 2){
            fseek(fp, file_size/2 - 1, SEEK_CUR);
            compare_char = fgetc(fp);
        }
        
        else{
            int diff = file_size - current_char_index;

            fseek(fp, file_size / 2 - diff, SEEK_SET);
            compare_char = fgetc(fp);
        }

        if(current_char == compare_char){
            answer += (current_char - '0');
        }

        current_char_index++;
        fseek(fp, current_char_index, SEEK_SET);
    }

    printf("answer=%ld\n", answer);

    fclose(fp);
    return EXIT_SUCCESS;
}