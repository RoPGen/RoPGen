
#include <stdio.h>
#include<stdlib.h>
#include "myStackADT.h"


int main()
{
    struct stack *sp=(struct stack*)malloc(sizeof(struct stack));
    sp->size=10;
    sp->top= -1;
    sp->arr= (char *)malloc(sp->size* sizeof(int));
    
    
    printf("Before pushing, Full: %d\n", isFull(sp));
    printf("Before pushing, Empty: %d\n", isEmpty(sp));
    
    push(sp, 56);
    push(sp, 55);
    push(sp, 54);
    push(sp, 53);
    push(sp, 52);
    push(sp, 51);
    push(sp, 50);
    push(sp, 49);
    push(sp, 48);
    push(sp, 47); 
    push(sp, 46);
    
    printf("After pushing, Full: %d\n", isFull(sp));
    printf("After pushing, Empty: %d\n", isEmpty(sp));
    
    printf("Popped %d from the stack\n", pop(sp)); 



    char*exp = "(8)*((9))";
     
     if(parenthesisMatch(exp)){
          printf("The Parenthesis is matching.\n");
     }
     else{
          printf("The Parenthesis is not matching.\n");
     }
     
    return 0;
}