#include <stdlib.h>
#include "binary_trees.h"


binary_tree_t *binary_tree_insert_right(binary_tree_t *parent, int value)
{
    binary_tree_t *right_aux;
    binary_tree_t *new_node;

    if (!parent)
        return (NULL);
    new_node = malloc(sizeof(binary_tree_t));
    if (!new_node)
        return (NULL);
    new_node->n = value;
    new_node->parent = parent;
    new_node->left = NULL;
    new_node->right = NULL;
    if (parent->right == NULL)
    {
        parent->right = new_node;
    }
    else
    {
        right_aux = parent->right;
        parent->right = new_node;
        new_node->right = right_aux;
        right_aux->parent = new_node;
    }
    return (new_node);
}
