#include "shell.h"


int _putchar(char c)
{
    return (write(1, &c, 1));
}


char *_strncpy(char *dest, char *src, int n)
{
int i;

i = 0;
    while (i < n && *(src + i))
    {
    *(dest + i) = *(src + i);
    i++;
    }
    while (i < n)
    {
    *(dest + i) = '\0';
    i++;
    }
    return (dest);
}



int _strlen(char *s)
{
    int i;

        for (i = 0; s[i] != '\0'; i++)
        {
            continue;
        }
return (i);
}


int _atoi(char *s)
{
int i, j, n, x;

    i = n = 0;
    x = 1;
    while ((s[i] < '0' || s[i] > '9') && (s[i] != '\0'))
    {
        if (s[i] == '-')
            x *= -1;
        i++;
    }
    j = i;
    while ((s[j] >= '0') && (s[j] <= '9'))
    {
        n = (n * 10) + x * ((s[j]) - '0');
        j++;
    }
    return (n);
}

void _puts(char *str)
{
    int i;

    for (i = 0; str[i] != '\0'; i++)
    {
        _putchar(str[i]);
    }
_putchar('\n');
return;
}
