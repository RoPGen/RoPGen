

#include "notebook.h"
#include "trabajo.h"
#include "servicio.h"
#include "utn.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>




int inicializarTrabajo(eTrabajo listadoDeTrabajos[], int tamanioTrabajos)
{
    int error = -1;
    if(listadoDeTrabajos != NULL && tamanioTrabajos>0)
    {
        error = 0;
        for (int i = 0; i < tamanioTrabajos; ++i)
        {
            listadoDeTrabajos[i].isEmpty = 1;
        }
    }
    return error;
}

int buscarLibreTrabajo(eTrabajo listadoDeTrabajos[], int tamanioTrabajos)
{
    int indice = -1;

    for(int i = 0; i < tamanioTrabajos; i++)
    {
        if(listadoDeTrabajos[i].isEmpty == 1)
        {
            indice = i;
            break;
        }
    }

    return indice;
}

int altaTrabajo(eNotebook listaNotebook[], eTrabajo listaDeTrabajos[], eServicio listaDeServicios[], eMarca listaDeMarcas[],eTipo listaDeTipos [],eCliente listaDeClientes [], int tamCliente, int tamNotebook, int tamTrabajos, int tamServicios,int tamTipo, int tamMarcas, int idTrabajo)
{

    int error = 1;
    int indiceTrabajo;
    int indiceNotebook;
    int idNotebook;
    eTrabajo nuevoTrabajo;


    if(listaDeClientes != NULL && listaNotebook != NULL  && listaDeTrabajos != NULL && listaDeServicios != NULL && listaDeTipos != NULL && listaDeMarcas != NULL && tamNotebook > 0 && tamTrabajos > 0 && tamServicios >0 && tamCliente >0)
    {

        system("cls");
        printf("\n*** ALTA DE TRABAJO ***\n");
        listarNotebook(listaNotebook,listaDeMarcas,listaDeClientes,listaDeTipos,tamCliente,tamNotebook,tamMarcas,tamTipo);
        indiceTrabajo = buscarLibreTrabajo(listaDeTrabajos, tamNotebook);

        if(indiceTrabajo == -1)
        {
            printf("El sistema esta completo\n");
        }
        else
        {
            nuevoTrabajo.idTrabajo = idTrabajo;
            nuevoTrabajo.isEmpty = 0;

            printf("\nIngrese el ID de la notebook para el trabajo: \n");
            fflush(stdin);
            scanf("%d",&idNotebook);


            indiceNotebook = buscarNotebook(listaNotebook, tamNotebook, idNotebook);


                while(indiceNotebook == -1)
                {
                    printf("No existe una notebook con ese ID, vuelva a ingresarlo \n");
                    scanf("%d",&idNotebook);
                    indiceNotebook = buscarNotebook(listaNotebook, tamNotebook, idNotebook);
                }

                nuevoTrabajo.idNotebook = listaNotebook[indiceNotebook].id;

                mostrarUnaNotebook(listaNotebook[indiceNotebook], listaDeMarcas, listaDeClientes, listaDeTipos, tamCliente, tamTipo, tamMarcas);
                listarServicios(listaDeServicios,tamServicios);
                printf("Ingrese el servicio que desea realizarle: \n");
                scanf("%d",&nuevoTrabajo.idServicio);

                while(nuevoTrabajo.idServicio <2000 || nuevoTrabajo.idServicio > 2003)
                {
                    printf("No existe un servicio con esa ID, ingresela nuevamente: \n");
                    scanf("%d",&nuevoTrabajo.idServicio);
                }

                printf("Ingrese el dia en que se realizo el trabajo:\n");
                scanf("%d",&nuevoTrabajo.fechaTrabajo.dia);

                while(nuevoTrabajo.fechaTrabajo.dia < 0 || nuevoTrabajo.fechaTrabajo.dia >31)
                {
                    printf("Error, ingrese una dia valido 01 al 31");
                    scanf("%d",&nuevoTrabajo.fechaTrabajo.dia);
                }

                printf("Ingrese el mes en que se realizo el trabajo:\n");
                scanf("%d",&nuevoTrabajo.fechaTrabajo.mes);


                while(nuevoTrabajo.fechaTrabajo.mes < 0 || nuevoTrabajo.fechaTrabajo.mes >12)
                {
                    printf("Error, ingrese un mes valido 01 al 12");
                    scanf("%d",&nuevoTrabajo.fechaTrabajo.mes);
                }

                printf("Ingrese el anio en que se realizo el trabajo:\n");
                scanf("%d",&nuevoTrabajo.fechaTrabajo.anio);


                while(nuevoTrabajo.fechaTrabajo.anio < 0 || nuevoTrabajo.fechaTrabajo.anio >2020)
                {
                    printf("Error, ingrese un anio valido anterior al 2020");
                    scanf("%d",&nuevoTrabajo.fechaTrabajo.anio);
                }

            }

            listaDeTrabajos[indiceTrabajo] = nuevoTrabajo;

            error = 0;

        }

    return error;
}

int listarTrabajos(eTrabajo listadoDeTrabajos[], eNotebook listadoNotebook[], eServicio listadoDeServicios[], int tamNotebook, int tamTrabajos, int tamServicios)
{

    int error = 1;
    int flag = 0;

    if( listadoDeTrabajos != NULL && listadoNotebook != NULL && listadoDeServicios !=NULL &&  tamNotebook > 0 && tamTrabajos >0 && tamServicios > 0)
    {
        system("cls");
        printf(" idTrabajo         idNotebook          Modelo Notebook        Servicio         Fecha          Precio\n");
        printf("\n------------------------------------------------------------------------------------------------------\n");

        for(int i=0; i<tamTrabajos; i++)
        {
            if(verificarExistenciaTrabajo(listadoDeTrabajos,tamTrabajos) == 0)
            {
                 mostrarUnTrabajo(listadoDeTrabajos[i],listadoNotebook,listadoDeServicios,tamTrabajos,tamServicios);
                 flag = 1;
                 error = 0;
            }
        }

        printf("\n------------------------------------------------------------------------------------------------------\n");

        if( flag == 0)
        {
            printf("    No hay trabajos en la lista\n");
        }

    }
    return error;

}

int obtenerDescipcionModelo(eNotebook listaDeNotebook[], int tamanioNotebook, int idNotebook, char descripcionModelo[])
{
    int error = -1;

    if(listaDeNotebook != NULL && tamanioNotebook > 0 && descripcionModelo != NULL && idNotebook>=1)
    {
        for(int i = 0; i<tamanioNotebook;i++)
        {
            if(listaDeNotebook[i].id == idNotebook)
            {
                strcpy(descripcionModelo, listaDeNotebook[i].modelo);
                error = 0;
                break;
            }
        }
    }
    return error;
}

int obtenerDescipcionServicioTrabajo(eServicio listaDeServicios[], int tamanioServicios, int idServicio , char descripcionServicio[])
{
    int error = -1;

    if(listaDeServicios != NULL && tamanioServicios > 0 && descripcionServicio != NULL)
    {
        for(int i = 0; i<tamanioServicios;i++)
        {
            if(listaDeServicios[i].idServicio == idServicio)
            {
                strcpy(descripcionServicio, listaDeServicios[i].descripcion);
                error = 0;
                break;
            }
        }
    }
    return error;
}

int verificarExistenciaTrabajo(eTrabajo listadoDetrabajos[], int tamTrabajos)
{
    int error= -1;

    if(listadoDetrabajos!=NULL && tamTrabajos > 0)
    {
        for(int i=0; i<tamTrabajos; i++)
        {
            if(listadoDetrabajos[i].isEmpty==0)
            {
                error=0;
                break;
            }
        }
    }
    return error;
}

void mostrarUnTrabajo(eTrabajo unTrabajo, eNotebook listadoNotebook[], eServicio listadoDeServicio[], int tamNotebook, int tamServicios)
{
    char descripcionModelo[20];
    char descripcionServicio[20];
    int precioBuscado;

    if(listadoNotebook != NULL && listadoDeServicio !=NULL)
    {
        if(obtenerDescipcionModelo(listadoNotebook,tamNotebook,unTrabajo.idNotebook,descripcionModelo)==0 && obtenerDescipcionServicioTrabajo(listadoDeServicio,tamServicios,unTrabajo.idServicio,descripcionServicio)==0)
        {
            obtenerPrecio(listadoDeServicio,tamServicios,unTrabajo.idServicio,&precioBuscado);

                printf("   %d                 %d                %4s          %4s             %2d/%2d/%4d       %3d\n",unTrabajo.idTrabajo,unTrabajo.idNotebook,descripcionModelo, descripcionServicio,unTrabajo.fechaTrabajo.dia,unTrabajo.fechaTrabajo.mes,unTrabajo.fechaTrabajo.anio,precioBuscado);

        }
    }
}


int obtenerPrecio(eServicio listadoDeServicios[], int tamanioServicios, int idServicio, int *precio)
{

        int error = -1;

        if(listadoDeServicios != NULL && tamanioServicios > 0 && idServicio > 0)
        {
            for(int i = 0; i<tamanioServicios;i++)
            {
                if(listadoDeServicios[i].idServicio == idServicio)
                {
                    *precio = listadoDeServicios[i].precio;

                    error = 0;
                    break;
                }
            }
        }
      return error;
}

int hardCodearTrabajos(eTrabajo listadoDeTrabajos[], int tamTrabajos)
{
    int error = 1;

    int idServicios[10] = {2000,2000,2000,2001,2001,2002,2002,2002,2003,2003};
    int idsNotebooks[10] ={1,2,1,1,2,3,4,4,5,2,};
    int idTrabajo[10] = {101,102,103,104,105,106,107,108,109,110};
    int dia[10] = {10,20,30,10,10,20,12,11,5,4};
    int mes[10] = {10,4,5,10,10,20,12,11,2,1};
    int anio[10] ={2020,2010,2002,2020,2001,2001,2001,2005,2004,2020} ;

    for(int i =0; i<tamTrabajos;i++)
    {
        listadoDeTrabajos[i].idServicio = idServicios[i];
        listadoDeTrabajos[i].idNotebook = idsNotebooks[i];
        listadoDeTrabajos[i].fechaTrabajo.dia = dia[i];
        listadoDeTrabajos[i].fechaTrabajo.mes = mes[i];
        listadoDeTrabajos[i].fechaTrabajo.anio = anio[i];
        listadoDeTrabajos[i].idTrabajo = idTrabajo[i];
    }

    return error;
}

int listarTrabajosXNotebook(eTrabajo listadoDeTrabajos[], eNotebook listadoNotebook[],eCliente listaDeClientes [],eMarca listaDeMarcas[],eTipo listaDeTipos[], eServicio listadoDeServicios[], int tamClientes, int tamNotebook, int tamTrabajos, int tamServicios,int tamMarcas,int tamTipos)
{

    int error = 1;
    int flag = 0;
    int idNotebook;
    int indice;


    if( listaDeTipos != NULL && listadoNotebook != NULL && listaDeMarcas != NULL && listadoDeServicios !=NULL && listaDeClientes !=NULL && tamNotebook > 0 && tamTrabajos >0 && tamServicios > 0)
    {

         if(verificarExistenciaTrabajo(listadoDeTrabajos,tamTrabajos) == 0)
         {
             system("cls");
             listarNotebook(listadoNotebook, listaDeMarcas, listaDeClientes, listaDeTipos, tamClientes, tamNotebook, tamMarcas, tamTipos);
             printf("Ingrese el Id de la notebook para ver los trabajos:\n");
             scanf("%d",&idNotebook);

             indice = buscarNotebook(listadoNotebook,tamNotebook,idNotebook);

             while(indice == -1)
             {
                 printf("Error, no existe una notebook con ese ID, vuelva a ingresarlo");
                 scanf("%d",&idNotebook);
                 indice = buscarNotebook(listadoNotebook,tamNotebook,idNotebook);
             }
             error = 0;



             printf(" idTrabajo         idNotebook          Modelo Notebook        Servicio         Fecha          Precio\n");
             printf("\n------------------------------------------------------------------------------------------------------\n");

             for(int i=0; i<tamTrabajos; i++)
             {
                 if(listadoDeTrabajos[i].idNotebook == idNotebook)
                 {
                     mostrarUnTrabajo(listadoDeTrabajos[i],listadoNotebook,listadoDeServicios,tamTrabajos,tamServicios);
                     flag = 1;
                 }


             }

             printf("\n------------------------------------------------------------------------------------------------------\n");

             if( flag == 0)
             {
                 printf("    No hay trabajos en la lista\n");
             }
         }



    }
    return error;

}


int mostrarSumaDeImportesXNotebook(eServicio listaDeServicios [],int tamServicios,eTrabajo listaDeTrabajos[],eNotebook listadoDeNotebook[], int tamanioNotebooks,eMarca listaDeMarcas[], eTipo listaDeTipos[],eCliente listaDeClientes [],int tamClientes, int tamTipos, int tamMarcas, int tamTrabajos)
{
   int error = -1;
   int idNotebook;
   char descripcionModelo[20];
   float acumuladorServicios;
   int indice;

   if( listaDeTipos != NULL && listadoDeNotebook != NULL && listaDeMarcas != NULL && listaDeServicios !=NULL && listaDeClientes !=NULL && tamanioNotebooks > 0 && tamTrabajos >0 && tamServicios > 0)
   {
       system("cls");
       printf("***IMPORTE TOTAL SERVICIOS NOTEBOOK***\n\n");
       listarNotebook(listadoDeNotebook, listaDeMarcas, listaDeClientes, listaDeTipos, tamClientes, tamanioNotebooks, tamMarcas, tamTipos);

       utn_getNumeroInt(&idNotebook,"Ingrese el ID de la notebook\n","Error, ingrese un numero valido\n",1,1000, 4);

        indice = buscarNotebook(listadoDeNotebook, tamanioNotebooks, idNotebook);
        if(indice == -1)
        {
            printf("No existe una notebook con ese ID\n");
        }else
        {

            obtenerDescipcionModelo(listadoDeNotebook, tamanioNotebooks, idNotebook, descripcionModelo);

              for(int i=0;i<tamTrabajos;i++)
              {
                  if(listaDeTrabajos[i].isEmpty == 0 && listaDeTrabajos[i].idNotebook == idNotebook)
                  {
                      for(int j = 0;j<tamServicios;j++)
                      {
                          if(listaDeTrabajos[i].idServicio == listaDeServicios[j].idServicio)
                          {
                              acumuladorServicios += listaDeServicios[j].precio;
                          }
                      }
                      error = 0;
                  }
              }
              printf("El total a pagar de la notebook\n");
              mostrarUnaNotebook(listadoDeNotebook[indice], listaDeMarcas, listaDeClientes, listaDeTipos, tamClientes, tamTipos, tamMarcas);
              printf("es de $%.2f\n",acumuladorServicios);
        }
   }
   return error;
}
