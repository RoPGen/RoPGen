#include "sort.h"
#include <stdio.h>

void merge(int *array, int lo, int cnt, int dir)
{
    int k = 0, i, tmp;

    if (cnt > 1)
    {
        k = cnt / 2;
        i = lo;
        while (i < lo + k)
        {
            if (dir == (array[i] > array[i + k]))
            {
                tmp = array[i];
                array[i] = array[i + k];
                array[i + k] = tmp;
            }
            i++;
        }
        merge(array, lo, k, dir);
        merge(array, lo + k, k, dir);
    }
}

void rec_bitonicsort(int *array, int lo, int cnt, int dir, size_t size)
{
    int i = 0;
    char *s;

    if (cnt > 1)
    {
        if (dir == 1)
            s = "UP";
        else
            s = "DOWN";
        printf("Merging [%d/%lu] (%s):\n", cnt, size, s);
        print_array(&array[lo], cnt);

        i = cnt / 2;
        rec_bitonicsort(array, lo, i, 1, size);
        rec_bitonicsort(array, lo + i, i, 0, size);
        merge(array, lo, cnt, dir);
        printf("Result [%d/%lu] (%s):\n", cnt, size, s);
        print_array(&array[lo], cnt);

    }
}

void bitonic_sort(int *array, size_t size)
{
    if (array == NULL || size < 2)
        return;
    rec_bitonicsort(array, 0, (int)size, 1, size);
}
