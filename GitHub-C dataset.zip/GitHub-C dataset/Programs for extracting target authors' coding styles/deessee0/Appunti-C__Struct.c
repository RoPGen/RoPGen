#include <stdio.h>
#include <malloc.h>

struct elemento
{
    
    int info;
    
    struct elemento* next;
};


typedef struct elemento ElementodiLista;


typedef ElementodiLista* ListadiElementi;

int main(void) 
{
    
    
    ElementodiLista elem;

    elem.info = 10;
    elem.next = NULL;
    
    
    
    ListadiElementi lista;
    
    lista = malloc(sizeof(ElementodiLista));

    (*lista).info = 11;
    (*lista).next = NULL;
}

