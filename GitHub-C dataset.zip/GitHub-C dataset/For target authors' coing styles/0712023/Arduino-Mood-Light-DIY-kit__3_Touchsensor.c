#include <Adafruit_NeoPixel.h>  
int RGB_PIN = 3;  
int NUMPIXELS = 8;  
Adafruit_NeoPixel pixels = Adafruit_NeoPixel(NUMPIXELS, RGB_PIN, NEO_GRB + NEO_KHZ800);

int TOUCH_PIN = 4;  
int touch_count;
boolean up = true;

void setup() {
  pixels.begin();  
  pixels.show();  
}

void loop() {
  if ( digitalRead(TOUCH_PIN) == 1 ) {  

    for ( int i = 0; i < NUMPIXELS; i++ ) { 
      pixels.setPixelColor(i, pixels.Color( touch_count , 0 , 0) );  
      pixels.show(); 
    }  

    if ( up ) {  
      touch_count++;
      if ( touch_count == 255 )
        up = false;
    }
    else if ( !up ) {  
      touch_count--;
      if ( touch_count == 0 )
        up = true;
    }
  }
}
