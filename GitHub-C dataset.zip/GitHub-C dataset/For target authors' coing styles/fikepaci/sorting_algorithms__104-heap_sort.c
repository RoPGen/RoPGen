#include "sort.h"


void heap_sort(int *array, size_t size)
{
    int high;

    heapify(array, size);
    high = size - 1;

    while (high > 0)
    {
        swap(array, array[high], array[0]);
        print_array(array, size);
        high = size - 1;
        printf("BEFORE INITIAL SIFT_DOWN\n");
        sift_down(array, 0, high, size);
    }
}


void heapify(int *array, size_t size)
{
    int low;

    low = (size - 2) / 2;

    while (low >= 0)
    {
        printf("BEFORE HEAPIFY SIFT_DOWN\n");
        sift_down(array, low, size - 1, size);
        low = low - 1;
    }
}


void sift_down(int *array, int low, int high, size_t size)
{
    int root;
    int child;

    root = low;

    while (root * 2 + 1 <= high)
    {
        child = root * 2 + 1;
        if (child + 1 <= high && array[child] < array[child + 1])
            child = child + 1;
        if (array[root] < array[child])
        {
            printf("BEFORE SIFT_DOWN SWAP\n");
            swap(array, array[root], array[child]);
            print_array(array, size);
            root = child;
        }
        else
            return;
    }
}


void swap(int *array, int i, int j)
{
    int temp;

    temp = array[i];
    array[i] = array[j];
    array[j] = temp;
}
