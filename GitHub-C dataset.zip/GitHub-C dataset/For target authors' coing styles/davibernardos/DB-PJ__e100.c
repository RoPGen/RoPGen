#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define TAMANHO 6

int * GeraCaptcha(int Captcha[TAMANHO])
{
    int contador, escolha, captcha;
    
    for(contador=0; contador<TAMANHO; contador++)
    {
        escolha=rand();
        escolha=(escolha % 3);
        if(escolha == 0) 
        {
            captcha=rand();
            captcha=(captcha % 10)+48;
            Captcha[contador]=captcha;
        }
        if(escolha == 1) 
        {
            captcha=rand();
            captcha=(captcha % 25)+97;
            Captcha[contador]=captcha;
        }
        if(escolha == 2) 
        {
            captcha=rand();
            captcha=(captcha % 25)+65;
            Captcha[contador]=captcha;
        }
    }
    return Captcha;
}

int ValidaCaptcha(int CaptchaCompleto[TAMANHO], char CaptchaUsuario[TAMANHO])
{
    int contador;
    
    for(contador=0; contador<TAMANHO; contador++)
    {
        if(CaptchaCompleto[contador] != CaptchaUsuario[contador]) 
        {
            return 1;
        }
    }
    return 0;
}

int main(void)
{
    int teste=-1, contador, CaptchaVazio[TAMANHO], * CaptchaCompleto;
    char CaptchaUsuario[TAMANHO];
    float tempo;
    clock_t c2, c1;
    
    srand(time(NULL)); 
    while(teste!=0)
    {
        CaptchaCompleto=GeraCaptcha(CaptchaVazio);
        printf("Prove que voce nao eh um Robo!\n\n");
        printf("      ");
        for(contador=0; contador<TAMANHO; contador++)
        {
            printf("%c", CaptchaCompleto[contador]); 
        }
        printf("\n\nInsira os 6 caracteres acima seguindo a ordem apresentada em 15 segundos.\n\n");
        printf("Captcha:");
        c1 = clock(); 
        gets(CaptchaUsuario); 
        c2 = clock(); 
        tempo = (c2 - c1)*1000/CLOCKS_PER_SEC;
        if(tempo > 15000)
        {
            system("cls");
            printf("\nTompo maximo excedido!\n\n"); 
        }
        else
        {
            if(strlen(CaptchaUsuario) != TAMANHO)
                teste = 1;
            else
                teste=ValidaCaptcha(CaptchaCompleto, CaptchaUsuario); 
            if(teste == 1)
            {
                system("cls");
                printf("\nCaptcha invalido!!\n\n");
            }
        }
    }
    printf("\nCaptcha valido!!\n");
}
