

#include<stdio.h>


void RemoveCharacters(char str[]){
    int i = 0;
    int j = 0;

    
    while(str[i] != '\0'){

        
        if(!((str[i] >= 'a' && str[i] <= 'z') || (str[i] >= 'A' && str[i] <= 'Z'))){
            j = i;

            
            while(str[j] != '\0'){
            str[j] = str[j+1];
            j++;
            }
        }
        i++;
    }
}

int main(void){
    setvbuf(stdout , NULL , _IONBF , 0);
    setvbuf(stderr , NULL , _IONBF , 0);

    char str[30];

    printf("Enter String: ");

    
    gets(str);

    
    printf("String before polishing: %s",str);

    
    RemoveCharacters(str);

    printf("\n");

    
    printf("String after polishing: %s",str);

    return 0;
}
