#include <stdio.h>
#include "44b.h"
#include "leds.h"
#include "utils.h"
#include "D8Led.h"
#include "intcontroller.h"
#include "timer.h"
#include "gpio.h"
#include "keyboard.h"
#include "uart.h"

#define N 4 
#define M 128 


volatile static char *keyBuffer = NULL;
volatile static int keyCount = 0;


volatile static char *tmrBuffer = NULL;
volatile static int tmrBuffSize = 0;


static char passwd[N];  
static char guess[N];   
char readlineBuf[M];    


struct ulconf uconf = {
    .ired = OFF,
    .par  = ONE,
    .wordlen = EIGHT,
    .echo = ON,
    .baud    = 115200,
};

enum state {
    INIT = 0,     
    SPWD = 1,     
    DOGUESS = 2,  
    SGUESS = 3,   
    GOVER = 4     
};
enum state gstate; 


void timer_ISR(void) __attribute__ ((interrupt ("IRQ")));
void keyboard_ISR(void) __attribute__ ((interrupt ("IRQ")));


static void push_buffer(char *buffer, int key)
{
    int i;
    for (i=0; i < N-1; i++)
        buffer[i] = buffer[i+1];
    buffer[N-1] = (char) key;
}

void timer_ISR(void)
{
    static int pos = 0; 

    
    D8Led_digit(tmrBuffer[pos]);

    
    
    
    
    
    if(pos == tmrBuffSize-1){
        pos = 0;
        tmr_stop(TIMER0);
        tmrBuffer = NULL;
    }
    
    else{
        pos++;
    }

    
    ic_cleanflag(INT_TIMER0);
}

void printD8Led(char *buffer, int size)
{
    
    tmrBuffer = buffer;
    tmrBuffSize = size;

    
    tmr_start(TIMER0);

    
    while(tmrBuffer != NULL);
}

void keyboard_ISR(void)
{
    int key;

    
    Delay(200);

    
    
    key = kb_scan();

    if (key != -1) {
        
        
        
        if(key == 15){
            ic_disable(INT_EINT1);
            keyBuffer = NULL;
        }
        else{
            
            
            push_buffer(keyBuffer, key);
            
            keyCount++;
        }
        
        while (!(rPDATG & 0x02));
    }

    
    Delay(200);

    
    ic_cleanflag(INT_EINT1);
}

int read_kbd(char *buffer)
{
    
    
    keyBuffer = buffer;
    keyCount = 0;

    
    ic_enable(INT_EINT1);

    
    
    while(keyBuffer != NULL);

    
    return keyCount;
}

int readline(char *buffer, int size)
{
    int count = 0; 
    char c;        

    if (size == 0)
        return 0;

    
    
    
    
    

    uart_getch(UART0, &c);

    while(count < size && c != '\r')
    {
        if(c != '\n')
        {   buffer[count] = c;
            count++;}

        uart_getch(UART0, &c);
    }

    return count;
}

static int show_result()
{
    int error = 0;
    int i = 0;
    char buffer[2] = {0};

    
    while(i < N && error != 1){
        if(passwd[i] != guess[i]) error = 1;
        i++;
    }

    
    
    
    
    
    if(error == 0){ 
        buffer[0] = 10;
        buffer[1] = 10;
        uart_printf(UART0, "\nCorrecto\n");
    }
    else if(error == 1){ 
        buffer[0] = 14;
        buffer[1] = 14;
        uart_printf(UART0, "\nError\n");
    }
    printD8Led(buffer, 2);


    
    
    

    
    while(tmrBuffer != NULL);

    
    return error;
}

int setup(void)
{
    D8Led_init();

    
    tmr_set_prescaler(0, 255);
    
    
    tmr_set_divider(0, D1_4);
    tmr_set_count(TIMER0, 62500, 1);
    tmr_update(TIMER0);
    
    tmr_set_mode(TIMER0, RELOAD);

    

    
    pISR_TIMER0 = timer_ISR;
    pISR_EINT1 = keyboard_ISR;

    
    ic_init();
     
    ic_enable(INT_GLOBAL);
    ic_conf_irq(ENABLE, VEC);
    ic_conf_fiq(DISABLE);
    ic_conf_line(INT_TIMER0, IRQ);
    ic_conf_line(INT_EINT1, IRQ);
    ic_enable(INT_TIMER0);
    ic_enable(INT_EINT1);

    

    
    

        

    uart_init();
    uart_lconf(UART0, &uconf);
    uart_conf_rxmode(UART0, INT);
    uart_conf_txmode(UART0, INT);

    

    Delay(0);

    
    gstate = INIT;
    D8Led_digit(12);

    return 0;
}

static char ascii2digit(char c)
{
    char d = -1;

    if ((c >= '0') && (c <= '9'))
        d = c - '0';
    else if ((c >= 'a') && (c <= 'f'))
        d = c - 'a' + 10;
    else if ((c >= 'A') && (c <= 'F'))
        d = c - 'A' + 10;

    return d;
}


int loop(void)
{
    int count; 
    int error;

    

    switch (gstate) {
        case INIT:
            do {
                
                
                
                
                
                D8Led_digit(12);
                count = read_kbd(passwd);
                if(count < N){
                    D8Led_digit(14);
                    Delay(5000);
                }

            } while (count < N);
            
            gstate = SPWD;

            break;

        case SPWD:

            
            
            
            Delay(10000);
            printD8Led(passwd, N);

            
            gstate = DOGUESS;
            break;

        case DOGUESS:
            Delay(10000);
            do {
                
                

                uart_send_str(UART0, "Introduzca passwd: ");
                D8Led_digit(15);
                count = readline(readlineBuf, M);

                if(count < N)
                {
                    D8Led_digit(14);
                    Delay(5000);
                }

            } while (count < N);

            
            int i;
            for(i = 1; i <= N; i++)
                guess[N-i] = ascii2digit(readlineBuf[count-i]);


            
            gstate = SGUESS;

            break;

        case SGUESS:
            
            
            
            Delay(10000);
            printD8Led(guess, N);
            
            gstate = GOVER;

            break;

        case GOVER:
            
            
            Delay(10000);
            int resultado = show_result();
            
            if(resultado == 0) gstate = INIT;
            else gstate = DOGUESS;

            break;
    }
    return 0;
}

int main(void)
{
    setup();

    while (1) {
        loop();
    }
}
