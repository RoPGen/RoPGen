
 
#include "ft6206.h"
#include "nrf_log.h"
#include "nrf_log_ctrl.h"
#include "nrf_log_default_backends.h"

uint8_t const ft6206_ven_id_reg_addr = FT6206_REG_VENDID;
uint8_t const ft6206_chip_id_reg_addr = FT6206_REG_CHIPID;
uint8_t const ft6206_num_touches_reg_addr = FT6206_REG_NUMTOUCHES;
uint8_t const ft6206_read_data_reg_addr = 0x00;


static void twi_config(void);  
static void ft6206_get_all_registers_bg(void);   
static void get_data_cb(ret_code_t result, void *p_user_data);  
static void ft6206_get_touch_bg(void);   
static void get_touch_cb(ret_code_t result, void *p_user_data);  
static void ft6206_get_point(void);  
static long map(long x, long in_min, long in_max, long out_min, long out_max);  


static uint8_t const default_config[] = { FT6206_REG_THRESHHOLD, FT6206_DEFAULT_THRESSHOLD };
static app_twi_transfer_t const ft6206_init_transfers[FT6206_INIT_TRANSFER_COUNT] =
{
    APP_TWI_WRITE(FT6206_ADDR, default_config, sizeof(default_config), 0)
};

static void twi_config(void)
{
    uint32_t err_code;

    nrf_drv_twi_config_t const config = {
       .scl                = ARDUINO_SCL_PIN,
       .sda                = ARDUINO_SDA_PIN,
       .frequency          = NRF_TWI_FREQ_400K,
       .interrupt_priority = APP_IRQ_PRIORITY_LOWEST,
       .clear_bus_init     = false
    };

    err_code = app_twi_init(&m_app_twi, &config);
    APP_ERROR_CHECK(err_code);
}

static void get_data_cb(ret_code_t result, void *p_user_data)
{   
    ft6206_get_point();
    m_gui_fns_struct.gtu(m_x, m_y, 1);
}


static void ft6206_get_all_registers_bg()
{
    static app_twi_transfer_t const transfers[] =  { FT6206_READ(&ft6206_read_data_reg_addr, &m_buffer[0], 16) };
    
    static app_twi_transaction_t const transaction =
    {
        .callback            = get_data_cb,
        .p_user_data         = NULL,
        .p_transfers         = transfers,
        .number_of_transfers = sizeof(transfers) / sizeof(transfers[0])
    };
    
    APP_ERROR_CHECK(app_twi_schedule(&m_app_twi, &transaction));   
}


#define DEBOUNCE_SENSITIVITY 5
static void get_touch_cb(ret_code_t result, void *p_user_data)
{
    static int is_touchscreen_pressed = 0;
    
    m_touches = m_buffer[0x0];
    if (m_buffer[0] == 1 || m_buffer[0] == 2) {  
        ++is_touchscreen_pressed;        
    }
    else {        
        is_touchscreen_pressed = 0;
        
        m_gui_fns_struct.gtu(-1, -1, 0);        
    }
    if (is_touchscreen_pressed == DEBOUNCE_SENSITIVITY) {        
        ft6206_get_all_registers_bg();
    }
}

static void ft6206_get_touch_bg()
{
    static app_twi_transfer_t const transfers[] = { FT6206_READ_NUM_TOUCHES(&m_buffer[0]) };
    
    static app_twi_transaction_t const transaction =    
    {
        .callback            = get_touch_cb,
        .p_user_data         = NULL,
        .p_transfers         = transfers,
        .number_of_transfers = sizeof(transfers) / sizeof(transfers[0])
    };    

    
    if (app_twi_is_idle(&m_app_twi)) {
        APP_ERROR_CHECK(app_twi_schedule(&m_app_twi, &transaction));
    }
}

static long map(long x, long in_min, long in_max, long out_min, long out_max) 
{
    return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}

static void ft6206_get_point(void)
{    
    if (m_touches > 2) {
        m_touches = 0;
        m_x = m_y = 0;
    }
    
    if (m_touches == 0) {
        m_x = m_y = 0;
        return;
    }
       
    for (uint8_t i=0; i<2; i++) {
        m_touchX[i] = m_buffer[0x03 + i*6] & 0x0F;
        m_touchX[i] <<= 8;
        m_touchX[i] |= m_buffer[0x04 + i*6]; 
        m_touchY[i] = m_buffer[0x05 + i*6] & 0x0F;
        m_touchY[i] <<= 8;
        m_touchY[i] |= m_buffer[0x06 + i*6];
        m_touchID[i] = m_buffer[0x05 + i*6] >> 4;
    }
    
    
    m_x = map(m_touchX[0], 0, 240, 240, 0);
    m_y = map(m_touchY[0], 0, 320, 320, 0);

    
    
    
}


#if 0
extern int UG_TextboxSetBackColor( void*, int, int );
extern int UG_TextboxShow(void *, int);
extern int UG_TextboxHide(void *, int);
extern void* ptr_window7;
#endif


static void timeout_handler(void * p_context)
{
#if 0
    static bool switcher = true;
    NRF_LOG_INFO("tick\r\n");
    if (switcher) 
         UG_TextboxSetBackColor( ptr_window7, 0, 0x9A85 );
    else
        UG_TextboxSetBackColor( ptr_window7, 0, 0xFFBB );




    switcher = !switcher; 
#endif    
    ft6206_get_touch_bg();
    m_gui_fns_struct.gu(); 
}

static void timer_init(void)
{
    
    uint32_t err_code;
    
    err_code = app_timer_init();
    APP_ERROR_CHECK(err_code);
    
    err_code = app_timer_create(&m_gui_timer_id, APP_TIMER_MODE_REPEATED, timeout_handler);
    APP_ERROR_CHECK(err_code);
    
    err_code = app_timer_start(m_gui_timer_id, APP_TIMER_TICKS(50), NULL);
    APP_ERROR_CHECK(err_code);
}







void init_ft6206(void *gui_touch_update_function, void *gui_update_function)
{
    if ((!gui_touch_update_function) || (!gui_update_function))
        return;
    m_gui_fns_struct.gtu = (gui_touch_update)gui_touch_update_function;
    m_gui_fns_struct.gu  = (gui_update)gui_update_function;
    twi_config();
    APP_ERROR_CHECK(app_twi_perform(&m_app_twi, ft6206_init_transfers, FT6206_INIT_TRANSFER_COUNT, NULL)); 
    timer_init();
}
