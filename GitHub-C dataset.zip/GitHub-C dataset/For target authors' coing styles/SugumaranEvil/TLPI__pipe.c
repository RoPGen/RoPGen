






#include "pipe.h"

int main()
{
    char str_1[] = "Hi i am data from pipe\n"; 
    char str_2[50];
    int fd[2];  

    ssize_t write_ret = 0;
    ssize_t read_ret = 0;
    int pipe_ret;
    pipe_ret = pipe(fd);

    printf("pipe_ret %d\n",pipe_ret);

    int fk = fork();

    printf("PID => %d\tfd[0] => %d\tfd[1] => %d\n",getpid(),fd[0],fd[1]);

    if(fk > 0) {
        close(fd[0]); 
        write_ret = write(fd[1],str_1,strlen(str_1)+1); 
        printf("write ret_val => %ld\n",write_ret);  
    }
    else if(fk == 0) {
        close(fd[1]); 
        read_ret = read(fd[0],str_2,50);   
        printf("read ret_val => %ld\n",read_ret); 
    }
    else {
        printf("fork failed\n");
    }

    printf("String from pipe ==> %s\n",str_2);

    if(fk == 0){
        close(fd[0]);
    }
    if(fk > 0){
        close(fd[1]);
    }

}
