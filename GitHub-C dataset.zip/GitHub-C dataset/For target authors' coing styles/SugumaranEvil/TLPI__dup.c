

         




#include "dup.h"

int main()
{
    int dp;
    int op_fd;
    ssize_t wt,rd;
    char str[]="hi it is string\n";
    char buf[100];

    op_fd = open("test",O_CREAT | O_RDWR, 0664);
    perror("open");

    dp = dup(op_fd);
    printf("fd => %d\tdp => %d\n",op_fd,dp);

    wt = write(dp,str,strlen(str));
    perror("write");
    printf("write ret val %ld\n",wt);

    off_t seek = lseek(op_fd,0,SEEK_SET);
    perror("lseek");

    rd = read(op_fd,buf,5); 
    perror("read");
    printf("read ret val %ld\n",rd);

    printf("original_fd =>%s\n",buf); 

    rd = read(dp,buf,5);
    perror("read");
    printf("read ret val %ld\n",rd);

    printf("duplicate_fd =>%s\n",buf);
}
