



#include <stdio.h>
#include <stdlib.h>

int main()
{
    unsigned int grade;
    unsigned int total;
    int counter;                        

    float average;

    total = 0;                          
    counter = 0;                        
    while(counter < 10)                 
    {
        printf("Enter A Grade : ");
        scanf("%u" , &grade);

        total = total + grade;          

        counter++;                      
    }

    average = (float)total / 10;        

    printf("\nAverage = %f\n" , average);

    return 0;
}
