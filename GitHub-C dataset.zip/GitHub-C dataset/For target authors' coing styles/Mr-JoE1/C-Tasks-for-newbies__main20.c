



#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n;

    printf("Enter The Number Of Values : ");
    scanf("%d" , &n);

    int values[ n ];

    for(int i = 0;i < n;i++)
    {
        printf("Enter Element %d : " , i + 1);
        scanf("%d" , &values[ i ]);
    }

    printf("\n");
    printf("Input Values In Reverse Order : \n");

    
    for(int i = n - 1;i > -1;i--)
    {
        printf("%d\n" , values[ i ]);
    }

    printf("\n");

    return 0;
}
