#include <stdio.h>


void printb(unsigned short x);

int main(void) {
    unsigned short x, y;
    
    x = 60; 
    
    
    printf("     x: %5u %04X ... ", x, x);
    printb(x);
    printf("\n");

    
    y = x << 3;
    printf("x << 3: %5u %04X ... ", y, y);
    printb(y);
    printf("\n");
    
    
    y = x >> 2;
    printf("x >> 2: %5u %04X ... ", y, y);
    printb(y);
    printf("\n");
    
    return 0;
}

void printb(unsigned short x) {
    unsigned short n = 32768;
    int i;
    
    for(i = 0; i < 16; i++) {
        if(x / n != 0) {
            x = x % n;
            printf("1");
        } else 
            printf("0");
        if (i % 4 == 3)
            printf(" ");
        n /= 2;
    }
}
