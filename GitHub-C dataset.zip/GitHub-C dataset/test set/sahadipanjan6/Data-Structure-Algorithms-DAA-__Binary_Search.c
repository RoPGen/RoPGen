#include<stdio.h>
#define MAX 10


void display(int array[MAX], int length);
void bubble_sort(int array[MAX], int length);
int binary_search(int array[MAX], int low, int high, int key);

void main()
{
    int i, size, key = 0;
        
    printf("\nEnter number of elements: \n");
    scanf("%d", &size);
    int input_array[size];

    printf("\nEnter the array elements...\n");
    for(i=0; i<size; i++)
        scanf("%d", &input_array[i]);

    
    printf("\nOriginal Array is as follows:- \n");
    display(input_array, size);

    
    printf("\nEnter the key to be searched: \n");
    scanf("%d", &key);

    
    printf("\n%d is found in Index %d after sorting the array\n", key, binary_search(input_array, 0, size, key));
}


void display(int array[MAX], int length)
{
    int i = 0;
    for(i=0; i<length; i++)
        printf("%d\t", array[i]);

    printf("\n");
}


void bubble_sort(int array[MAX], int length)
{
    int i, j, temp = 0;
    int size = length;

    for(i=0; i<size; i++)
    {
        for(j=0; j<(size-i-1); j++)
        {
            if(array[j] > array[j+1])
            {
                
                temp = array[j];
                array[j] = array[j+1];
                array[j+1] = temp;
            }
        }
    }
}


int binary_search(int array[MAX], int low, int high, int key)
{
    int i = 0;
    int index = -1;
    int size = high;

    
    bubble_sort(array, size);

    
    while(low < high)
    {
        
        int mid = (low + high) / 2;

        
        if(key == array[mid])
        {
            index = mid;
            break;
        }

        
        else if(key < array[mid])
            high = mid - 1;

        
        else if(key > array[mid])
            low = mid + 1;
    }

    return index;
}