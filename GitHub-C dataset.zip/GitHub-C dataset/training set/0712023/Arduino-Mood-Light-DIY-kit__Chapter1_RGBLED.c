#include <MsTimer2.h>  
#include <Adafruit_NeoPixel.h>  
int RGB_PIN = 3;  
int NUMPIXELS = 8;  
Adafruit_NeoPixel pixels = Adafruit_NeoPixel(NUMPIXELS, RGB_PIN, NEO_GRB + NEO_KHZ800);

int TOUCH_PIN = 4;  
int POTEN_PIN = A5;  
int Mode_EA = 6;  
int random_ms = 200;  
int rainbow[6][3] = {
  {255, 0, 0},     
  {255, 50, 0},    
  {255, 150, 0},   
  {0, 255, 0},     
  {0, 0, 255},     
  {100, 0, 200},   
}; 

int r = 0 , g = 0 , b = 0, Mode, touch_count, rainbow_count, rain;  
boolean touch = true, Mode_5 = true, up = true;  

void setup() {
  pixels.begin();  
  pixels.show();  
}


void loop() {
  Mode_set();  
  int poten = analogRead(POTEN_PIN);  

  if ( Mode != 6 ) {
    for ( int i = 0; i < NUMPIXELS; i++ ) { 
      pixels.setPixelColor(i, pixels.Color( map(poten, 0, 1023, 0, r) , map(poten, 0, 1023, 0, g) , map(poten, 0, 1023, 0, b) ) );  
      pixels.show(); 
    }
    rain = 0;
  }

  if ( digitalRead(TOUCH_PIN) == 1 ) {
    touch_count++;
    delay(10);

    if ( touch_count >= 100 ) {
      if ( r == 0 && g == 0 && b == 0 ) {
        r = 255;
        
      }                                                    

      else {
        r = 0;
        g = 0;
        b = 0;
        Mode = 0;
      }                                                   
      touch_count = 0;
    }

    else if ( touch && ( r != 0 || g != 0 || b != 0 ) ) {
      Mode++;

      if ( Mode > Mode_EA ) {
        Mode = 1;
      }

      touch = false;
    }                                                   
  }

  else {
    touch = true;
    touch_count = 0;
  }

}

void Mode_set() {
  if ( Mode == 1) {
    r = 210;
    g = 100;
    b = 10;
  }

  else if ( Mode == 2 ) {
    r = 255;
    g = 20;
    b = 180;
  }

  else if ( Mode == 3 ) {
    r = 65;
    g = 255;
    b = 20;
  }

  else if ( Mode == 4 ) {
    r = 65;
    g = 216;
    b = 255;
  }

  else if ( Mode == 5 ) {
    if ( Mode_5 ) {
      MsTimer2::set(random_ms, random_set);
      MsTimer2::start();
      Mode_5 = false;
    }
  }

  else if ( Mode == 6 ) {
    if ( !Mode_5 ) {
      MsTimer2::stop();
      Mode_5 = true;
    }

    for ( int i = 0; i < NUMPIXELS; i++ ) { 
      pixels.setPixelColor(i, pixels.Color( map(rainbow_count, 0, 1023, 0, rainbow[rain][0]) , map(rainbow_count, 0, 1023, 0, rainbow[rain][1]) , map(rainbow_count, 0, 1023, 0, rainbow[rain][2]) ) );  
      pixels.show(); 
    }

    if ( up ) {
      rainbow_count++;
      delayMicroseconds(500);
      if ( rainbow_count == 1023 )
        up = false;
    }

    else if ( !up ) {
      rainbow_count--;
      delayMicroseconds(2000);
      if ( rainbow_count == 0 ) {
        up = true;
        rain++;
        if ( rain == 6)
          rain = 0;
      }
    }
  }
}

void random_set() {
  r = random(255);
  g = random(255);
  b = random(255);
}
