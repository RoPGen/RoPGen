#include <Adafruit_NeoPixel.h>  
int RGB_PIN = 3;  
int NUMPIXELS = 8;  
Adafruit_NeoPixel pixels = Adafruit_NeoPixel(NUMPIXELS, RGB_PIN, NEO_GRB + NEO_KHZ800);

int CDS_PIN = A0;

void setup() {
  pixels.begin();  
  pixels.show();  
  Serial.begin(9600);  
}

void loop() {
  int cds = analogRead(CDS_PIN);  
  Serial.print("cds : ");
  Serial.print(cds);

  if (cds > 800) {  
    for ( int i = 0; i < NUMPIXELS; i++ ) { 
      pixels.setPixelColor(i, pixels.Color( 255 , 0 , 0) );  
      pixels.show(); 
    }
    Serial.println("     LED ON");
  }
  else {  
    for ( int i = 0; i < NUMPIXELS; i++ ) { 
      pixels.setPixelColor(i, pixels.Color( 0 , 0 , 0) );  
      pixels.show(); 
    }
    Serial.println("     LED OFF");
  }
  delay(200);
}
