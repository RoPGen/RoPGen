
#include<stdio.h>
#include<malloc.h>
void displayarr(int arr[],int len);
int main()
    {
    int *arr,temp,n,i,j,pos,item;
    printf("Enter how many numbers you want to store into array");
    scanf("%d",&n);
    
    printf("Enter the position where you want to insert an item");
    scanf("%d",&pos);
    
    printf("Enter the item to be inserted");
    scanf("%d",&item);
    
    arr=(int *)malloc((n)*sizeof(int *));   
    
    printf("Enter %d elements",n);
    for(i=0;i<n;i++)
    scanf("%d",&arr[i]);                    
    
    for(i=n-1;i>=pos-1;i--)
        arr[i+1]=arr[i];        
    arr[pos-1]=item;            
    
    displaymatrix(arr,n+1);
    
    return 0;
    }
void displayarr(int arr[],int len)
    {
    int i;
    for(i=0;i<len;i++)
        printf("%d ",arr[i]);
    }
    
    
