#include <stdio.h>


void printb(unsigned short x);

int main(void) {
    unsigned short a, b, x;
    
    a = 60; 
    b = 90; 
    
    
    printf("    a: %5u %04X ... ", a, a);
    printb(a);
    printf("\n");
    printf("    b: %5u %04X ... ", b, b);
    printb(b);
    printf("\n");
    
    
    x = a & b;
    printf("a & b: %5u %04X ... ", x, x);
    printb(x);
    printf("\n");

        
    x = a | b;
    printf("a | b: %5u %04X ... ", x, x);
    printb(x);
    printf("\n");

    
    x = a ^ b;
    printf("a ^ b: %5u %04X ... ", x, x);
    printb(x);
    printf("\n");

    
    x = ~a;
    printf("   ~a: %5u %04X ... ", x, x);
    printb(x);
    printf("\n");

    return 0; 

}

void printb(unsigned short x) {
    unsigned short n = 32768;
    int i;
    
    for(i = 0; i < 16; i++) {
        if(x / n != 0) {
            x = x % n;
            printf("1");
        } else 
            printf("0");
        if (i % 4 == 3)
            printf(" ");
        n /= 2;
    }
}
