#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define NR_ELEMENTS 20
#define LITERS_TO_STORE 150

int main(void){
    int input[NR_ELEMENTS] = {50, 44, 11, 49, 42, 46, 18, 32, 26, 40, 21, 7, 18, 43, 10, 47, 36, 24, 22, 40};
    int multiplier[NR_ELEMENTS] = {0};
    int nr_combinations = 0, result = 0;

    
    
    
    
    for(int i = 0; i < pow(2, NR_ELEMENTS); i++){
        for(int j = 0; j < NR_ELEMENTS; j++){
            multiplier[NR_ELEMENTS - 1 - j] = (i >> (NR_ELEMENTS - 1 -j)) & 1;
        }

        
        for(int k = 0; k < NR_ELEMENTS; k++){
            result += input[k] * multiplier[k];
        }

        
        if(result == LITERS_TO_STORE){
            nr_combinations++;
        }

        result = 0;
    }

    printf("answer=%d\n", nr_combinations);

    return EXIT_SUCCESS;
}